<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Util\Utils;
use Hash;
use Illuminate\Support\Facades\Auth;

class AppController extends Controller
{

    public function index()
    {
    }


    public function login(Request $request)
    {

    }

    public function user() {
    }
}
