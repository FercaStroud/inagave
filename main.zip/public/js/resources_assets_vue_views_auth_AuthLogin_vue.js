(self["webpackChunklaravel_vue_boilerplate"] = self["webpackChunklaravel_vue_boilerplate"] || []).push([["resources_assets_vue_views_auth_AuthLogin_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/icons/icons.js");
/* harmony import */ var _utils_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/dialog */ "./resources/assets/vue/utils/dialog.ts");
/* harmony import */ var _utils_formValidation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils/formValidation */ "./resources/assets/vue/utils/formValidation.ts");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};






var aStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('auth');

var AuthLogin =
/** @class */
function (_super) {
  __extends(AuthLogin, _super);

  function AuthLogin() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.form = {
      rememberMe: false,
      email: '',
      password: ''
    };
    _this.authError = false;
    _this.isSending = false;
    return _this;
  }

  AuthLogin.prototype.doLogin = function () {
    return __awaiter(this, void 0, void 0, function () {
      var user, path;

      var _this = this;

      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , this.axios.create({
              baseURL: '/'
            }).get('/sanctum/csrf-cookie')];

          case 1:
            _a.sent();

            return [4
            /*yield*/
            , this.axios.post('/login', this.form)];

          case 2:
            user = _a.sent().data;

            if (!user.id) {
              if (user.error && user.message) {
                (0,_utils_dialog__WEBPACK_IMPORTED_MODULE_2__.default)(user.message, false);
                return [2
                /*return*/
                ];
              }

              (0,_utils_dialog__WEBPACK_IMPORTED_MODULE_2__.default)('auth.failed', false);
              return [2
              /*return*/
              ];
            }

            localStorage.setItem('default_auth_token', user.token);
            delete user.token;
            this.setUser(user);
            this.loadData();
            path = user.home_path;

            if (path !== 'public.home') {
              setTimeout(function () {
                _this.$router.push({
                  name: path
                });
              }, 500);
            }

            return [2
            /*return*/
            ];
        }
      });
    });
  };

  AuthLogin.prototype.login = function (evt) {
    return __awaiter(this, void 0, void 0, function () {
      var _a;

      return __generator(this, function (_b) {
        switch (_b.label) {
          case 0:
            if (!(0,_utils_formValidation__WEBPACK_IMPORTED_MODULE_3__.default)(evt)) return [2
            /*return*/
            ];
            this.isSending = true;
            _b.label = 1;

          case 1:
            _b.trys.push([1, 3,, 4]);

            return [4
            /*yield*/
            , this.doLogin()];

          case 2:
            _b.sent();

            return [3
            /*break*/
            , 4];

          case 3:
            _a = _b.sent();
            this.setDialogMessage('errors.generic_error');
            return [3
            /*break*/
            , 4];

          case 4:
            this.isSending = false;
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], AuthLogin.prototype, "loadData", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], AuthLogin.prototype, "setDialogMessage", void 0);

  __decorate([aStore.Action], AuthLogin.prototype, "setUser", void 0);

  AuthLogin = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      BIconQuestionCircleFill: bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__.BIconQuestionCircleFill
    }
  })], AuthLogin);
  return AuthLogin;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthLogin);

/***/ }),

/***/ "./resources/assets/vue/utils/formValidation.ts":
/*!******************************************************!*\
  !*** ./resources/assets/vue/utils/formValidation.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var formValidation = function formValidation(evt) {
  var form = evt.target;

  if (!form.checkValidity()) {
    return false;
  }

  evt.preventDefault();
  return true;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (formValidation);

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n#login[data-v-642cea08] {\r\n  margin-top: 150px;\n}\r\n", "",{"version":3,"sources":["webpack://./resources/assets/vue/views/auth/AuthLogin.vue"],"names":[],"mappings":";AAsIA;EACA,iBAAA;AACA","sourcesContent":["<script lang=\"ts\">\r\nimport { Component, Vue } from 'vue-property-decorator';\r\nimport { Action, namespace } from 'vuex-class';\r\nimport { BIconQuestionCircleFill } from 'bootstrap-vue';\r\n\r\nimport dialog from '@/utils/dialog';\r\nimport formValidation from '@/utils/formValidation';\r\n\r\nconst aStore = namespace('auth');\r\n\r\n@Component({\r\n  components: {\r\n    BIconQuestionCircleFill,\r\n  },\r\n})\r\nexport default class AuthLogin extends Vue {\r\n  @Action loadData;\r\n  @Action setDialogMessage;\r\n  @aStore.Action setUser;\r\n\r\n  form = {\r\n    rememberMe: false,\r\n    email:'',\r\n    password:'',\r\n  };\r\n  authError = false;\r\n  isSending = false;\r\n\r\n  async doLogin() {\r\n    await this.axios.create({\r\n      baseURL: '/',\r\n    }).get('/sanctum/csrf-cookie')\r\n\r\n    const { data: user }: any = await this.axios.post('/login', this.form);\r\n\r\n    if (!user.id) {\r\n      if (user.error && user.message) {\r\n        dialog(user.message, false);\r\n        return;\r\n      }\r\n\r\n      dialog('auth.failed', false);\r\n      return;\r\n    }\r\n\r\n    localStorage.setItem('default_auth_token', user.token)\r\n\r\n    delete user.token;\r\n\r\n    this.setUser(user);\r\n    this.loadData();\r\n\r\n    const path = user.home_path;\r\n\r\n    if (path !== 'public.home') {\r\n      setTimeout(() => {\r\n        this.$router.push({ name: path });\r\n      }, 500);\r\n    }\r\n  }\r\n\r\n  async login(evt: Event) {\r\n    if (!formValidation(evt)) return;\r\n\r\n    this.isSending = true;\r\n\r\n    try {\r\n      await this.doLogin();\r\n    } catch {\r\n      this.setDialogMessage('errors.generic_error');\r\n    }\r\n\r\n    this.isSending = false;\r\n  }\r\n}\r\n</script>\r\n\r\n<template lang=\"pug\">\r\nb-form(@submit='login')\r\n  b-container(fluid)\r\n    b-row\r\n      b-col(md=\"12\")\r\n        b-form-group.montserrat.text-primary(\r\n          :label='$t(\"strings.email\")'\r\n          label-for='email',\r\n        )\r\n          b-form-input(\r\n            type='email',\r\n            v-model='form.email',\r\n            name='email',\r\n            maxlength='191',\r\n            required,\r\n            autofocus,\r\n          )\r\n          span.help-block(v-if='authError')\r\n            strong {{ $t('auth.failed') }}\r\n      b-col(md=\"12\")\r\n        b-form-group.montserrat.text-primary(\r\n          :label='$t(\"strings.password\")'\r\n          label-for='password',\r\n        )\r\n          b-form-input(\r\n            type='password',\r\n            v-model='form.password',\r\n            required,\r\n          )\r\n      b-col(md=\"12\")\r\n        b-form-group#boxes\r\n          .d-flex.justify-content-between.align-items-center\r\n            b-form-checkbox.montserrat.text-primary(\r\n              v-model='form.rememberMe',\r\n              checked-value=true,\r\n              unchecked-value=false,\r\n            ) {{ $t('login.keep_connected') }}\r\n\r\n            b-button.content-vertical.text-secondary(variant='link', :to='{ name: \"auth.reset\" }')\r\n              b-icon-question-circle-fill\r\n              | &nbsp;{{ $t('login.forgot_password') }}\r\n\r\n      b-col.mb-4(md=\"12\")\r\n        .d-flex.justify-content-between\r\n          b-button(\r\n            type='submit',\r\n            variant='primary',\r\n            :class='{ disabled: isSending }',\r\n          ) {{ $t('login.login') }}\r\n\r\n          b-button(\r\n            variant='primary',\r\n            :to='{ name: \"auth.register\" }',\r\n          ) {{ $t('login.register') }}\r\n</template>\r\n\r\n<style scoped>\r\n#login {\r\n  margin-top: 150px;\r\n}\r\n</style>\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./resources/assets/vue/views/auth/AuthLogin.vue":
/*!*******************************************************!*\
  !*** ./resources/assets/vue/views/auth/AuthLogin.vue ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug& */ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug&");
/* harmony import */ var _AuthLogin_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AuthLogin.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts&");
/* harmony import */ var _AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& */ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__.default)(
  _AuthLogin_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "642cea08",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/auth/AuthLogin.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts&":
/*!********************************************************************************!*\
  !*** ./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AuthLogin.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug&":
/*!***********************************************************************************************************!*\
  !*** ./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug& ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_template_id_642cea08_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/pug-plain-loader/index.js!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&":
/*!****************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader/index.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthLogin_vue_vue_type_style_index_0_id_642cea08_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=template&id=642cea08&scoped=true&lang=pug& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-form",
    { on: { submit: _vm.login } },
    [
      _c(
        "b-container",
        { attrs: { fluid: "" } },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    {
                      staticClass: "montserrat text-primary",
                      attrs: {
                        label: _vm.$t("strings.email"),
                        "label-for": "email"
                      }
                    },
                    [
                      _c("b-form-input", {
                        attrs: {
                          type: "email",
                          name: "email",
                          maxlength: "191",
                          required: "",
                          autofocus: ""
                        },
                        model: {
                          value: _vm.form.email,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "email", $$v)
                          },
                          expression: "form.email"
                        }
                      }),
                      _vm.authError
                        ? _c("span", { staticClass: "help-block" }, [
                            _c("strong", [
                              _vm._v(_vm._s(_vm.$t("auth.failed")))
                            ])
                          ])
                        : _vm._e()
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c(
                    "b-form-group",
                    {
                      staticClass: "montserrat text-primary",
                      attrs: {
                        label: _vm.$t("strings.password"),
                        "label-for": "password"
                      }
                    },
                    [
                      _c("b-form-input", {
                        attrs: { type: "password", required: "" },
                        model: {
                          value: _vm.form.password,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "password", $$v)
                          },
                          expression: "form.password"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "b-col",
                { attrs: { md: "12" } },
                [
                  _c("b-form-group", { attrs: { id: "boxes" } }, [
                    _c(
                      "div",
                      {
                        staticClass:
                          "d-flex justify-content-between align-items-center"
                      },
                      [
                        _c(
                          "b-form-checkbox",
                          {
                            staticClass: "montserrat text-primary",
                            attrs: { "checked-value": "" },
                            model: {
                              value: _vm.form.rememberMe,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "rememberMe", $$v)
                              },
                              expression: "form.rememberMe"
                            }
                          },
                          [_vm._v(_vm._s(_vm.$t("login.keep_connected")))]
                        ),
                        _c(
                          "b-button",
                          {
                            staticClass: "content-vertical text-secondary",
                            attrs: {
                              variant: "link",
                              to: { name: "auth.reset" }
                            }
                          },
                          [
                            _c("b-icon-question-circle-fill"),
                            _vm._v(
                              " " + _vm._s(_vm.$t("login.forgot_password"))
                            )
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              ),
              _c("b-col", { staticClass: "mb-4", attrs: { md: "12" } }, [
                _c(
                  "div",
                  { staticClass: "d-flex justify-content-between" },
                  [
                    _c(
                      "b-button",
                      {
                        class: { disabled: _vm.isSending },
                        attrs: { type: "submit", variant: "primary" }
                      },
                      [_vm._v(_vm._s(_vm.$t("login.login")))]
                    ),
                    _c(
                      "b-button",
                      {
                        attrs: {
                          variant: "primary",
                          to: { name: "auth.register" }
                        }
                      },
                      [_vm._v(_vm._s(_vm.$t("login.register")))]
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/auth/AuthLogin.vue?vue&type=style&index=0&id=642cea08&scoped=true&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! !../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4ab0e1df", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvYXV0aC9BdXRoTG9naW4udnVlP2Q4ZWEiLCJzb3VyY2VzOi8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS91dGlscy9mb3JtVmFsaWRhdGlvbi50cyIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvYXV0aC9BdXRoTG9naW4udnVlPzhlNzQiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL2F1dGgvQXV0aExvZ2luLnZ1ZT9jYmE4Iiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9hdXRoL0F1dGhMb2dpbi52dWU/MTE0MCIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvYXV0aC9BdXRoTG9naW4udnVlP2VkZjQiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL2F1dGgvQXV0aExvZ2luLnZ1ZT8zY2I2Il0sIm5hbWVzIjpbIl9fZXh0ZW5kcyIsImV4dGVuZFN0YXRpY3MiLCJkIiwiYiIsIk9iamVjdCIsInNldFByb3RvdHlwZU9mIiwiX19wcm90b19fIiwiQXJyYXkiLCJwIiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiX18iLCJjb25zdHJ1Y3RvciIsImNyZWF0ZSIsIl9fZGVjb3JhdGUiLCJkZWNvcmF0b3JzIiwidGFyZ2V0Iiwia2V5IiwiZGVzYyIsImMiLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJyIiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwiUmVmbGVjdCIsImRlY29yYXRlIiwiaSIsImRlZmluZVByb3BlcnR5IiwiX19hd2FpdGVyIiwidGhpc0FyZyIsIl9hcmd1bWVudHMiLCJQIiwiZ2VuZXJhdG9yIiwiYWRvcHQiLCJ2YWx1ZSIsInJlc29sdmUiLCJQcm9taXNlIiwicmVqZWN0IiwiZnVsZmlsbGVkIiwic3RlcCIsIm5leHQiLCJlIiwicmVqZWN0ZWQiLCJyZXN1bHQiLCJkb25lIiwidGhlbiIsImFwcGx5IiwiX19nZW5lcmF0b3IiLCJib2R5IiwiXyIsImxhYmVsIiwic2VudCIsInQiLCJ0cnlzIiwib3BzIiwiZiIsInkiLCJnIiwidmVyYiIsIlN5bWJvbCIsIml0ZXJhdG9yIiwibiIsInYiLCJvcCIsInBvcCIsInB1c2giLCJhU3RvcmUiLCJuYW1lc3BhY2UiLCJBdXRoTG9naW4iLCJfc3VwZXIiLCJfdGhpcyIsImZvcm0iLCJyZW1lbWJlck1lIiwiZW1haWwiLCJwYXNzd29yZCIsImF1dGhFcnJvciIsImlzU2VuZGluZyIsImRvTG9naW4iLCJ1c2VyIiwicGF0aCIsIl9hIiwiYXhpb3MiLCJiYXNlVVJMIiwiZ2V0IiwicG9zdCIsImRhdGEiLCJpZCIsImVycm9yIiwibWVzc2FnZSIsImRpYWxvZyIsImxvY2FsU3RvcmFnZSIsInNldEl0ZW0iLCJ0b2tlbiIsInNldFVzZXIiLCJsb2FkRGF0YSIsImhvbWVfcGF0aCIsInNldFRpbWVvdXQiLCIkcm91dGVyIiwibmFtZSIsImxvZ2luIiwiZXZ0IiwiX2IiLCJmb3JtVmFsaWRhdGlvbiIsInNldERpYWxvZ01lc3NhZ2UiLCJBY3Rpb24iLCJDb21wb25lbnQiLCJjb21wb25lbnRzIiwiQkljb25RdWVzdGlvbkNpcmNsZUZpbGwiLCJWdWUiLCJjaGVja1ZhbGlkaXR5IiwicHJldmVudERlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNkIsWUFBWTtBQUNyRCxNQUFJQyxjQUFhLEdBQUcsdUJBQVVDLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNoQ0Ysa0JBQWEsR0FBR0csTUFBTSxDQUFDQyxjQUFQLElBQ1g7QUFBRUMsZUFBUyxFQUFFO0FBQWIsaUJBQTZCQyxLQUE3QixJQUFzQyxVQUFVTCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFBRUQsT0FBQyxDQUFDSSxTQUFGLEdBQWNILENBQWQ7QUFBa0IsS0FEL0QsSUFFWixVQUFVRCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFBRSxXQUFLLElBQUlLLENBQVQsSUFBY0wsQ0FBZDtBQUFpQixZQUFJQyxNQUFNLENBQUNLLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQ1IsQ0FBckMsRUFBd0NLLENBQXhDLENBQUosRUFBZ0ROLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU9MLENBQUMsQ0FBQ0ssQ0FBRCxDQUFSO0FBQWpFO0FBQStFLEtBRnJHOztBQUdBLFdBQU9QLGNBQWEsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLENBQXBCO0FBQ0gsR0FMRDs7QUFNQSxTQUFPLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNuQixRQUFJLE9BQU9BLENBQVAsS0FBYSxVQUFiLElBQTJCQSxDQUFDLEtBQUssSUFBckMsRUFDSSxNQUFNLElBQUlTLFNBQUosQ0FBYyx5QkFBeUJDLE1BQU0sQ0FBQ1YsQ0FBRCxDQUEvQixHQUFxQywrQkFBbkQsQ0FBTjs7QUFDSkYsa0JBQWEsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLENBQWI7O0FBQ0EsYUFBU1csRUFBVCxHQUFjO0FBQUUsV0FBS0MsV0FBTCxHQUFtQmIsQ0FBbkI7QUFBdUI7O0FBQ3ZDQSxLQUFDLENBQUNPLFNBQUYsR0FBY04sQ0FBQyxLQUFLLElBQU4sR0FBYUMsTUFBTSxDQUFDWSxNQUFQLENBQWNiLENBQWQsQ0FBYixJQUFpQ1csRUFBRSxDQUFDTCxTQUFILEdBQWVOLENBQUMsQ0FBQ00sU0FBakIsRUFBNEIsSUFBSUssRUFBSixFQUE3RCxDQUFkO0FBQ0gsR0FORDtBQU9ILENBZDJDLEVBQTVDOztBQWVBLElBQUlHLFVBQVUsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxVQUFkLElBQTZCLFVBQVVDLFVBQVYsRUFBc0JDLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0MsSUFBbkMsRUFBeUM7QUFDbkYsTUFBSUMsQ0FBQyxHQUFHQyxTQUFTLENBQUNDLE1BQWxCO0FBQUEsTUFBMEJDLENBQUMsR0FBR0gsQ0FBQyxHQUFHLENBQUosR0FBUUgsTUFBUixHQUFpQkUsSUFBSSxLQUFLLElBQVQsR0FBZ0JBLElBQUksR0FBR2pCLE1BQU0sQ0FBQ3NCLHdCQUFQLENBQWdDUCxNQUFoQyxFQUF3Q0MsR0FBeEMsQ0FBdkIsR0FBc0VDLElBQXJIO0FBQUEsTUFBMkhuQixDQUEzSDtBQUNBLE1BQUksUUFBT3lCLE9BQVAseUNBQU9BLE9BQVAsT0FBbUIsUUFBbkIsSUFBK0IsT0FBT0EsT0FBTyxDQUFDQyxRQUFmLEtBQTRCLFVBQS9ELEVBQTJFSCxDQUFDLEdBQUdFLE9BQU8sQ0FBQ0MsUUFBUixDQUFpQlYsVUFBakIsRUFBNkJDLE1BQTdCLEVBQXFDQyxHQUFyQyxFQUEwQ0MsSUFBMUMsQ0FBSixDQUEzRSxLQUNLLEtBQUssSUFBSVEsQ0FBQyxHQUFHWCxVQUFVLENBQUNNLE1BQVgsR0FBb0IsQ0FBakMsRUFBb0NLLENBQUMsSUFBSSxDQUF6QyxFQUE0Q0EsQ0FBQyxFQUE3QztBQUFpRCxRQUFJM0IsQ0FBQyxHQUFHZ0IsVUFBVSxDQUFDVyxDQUFELENBQWxCLEVBQXVCSixDQUFDLEdBQUcsQ0FBQ0gsQ0FBQyxHQUFHLENBQUosR0FBUXBCLENBQUMsQ0FBQ3VCLENBQUQsQ0FBVCxHQUFlSCxDQUFDLEdBQUcsQ0FBSixHQUFRcEIsQ0FBQyxDQUFDaUIsTUFBRCxFQUFTQyxHQUFULEVBQWNLLENBQWQsQ0FBVCxHQUE0QnZCLENBQUMsQ0FBQ2lCLE1BQUQsRUFBU0MsR0FBVCxDQUE3QyxLQUErREssQ0FBbkU7QUFBeEU7QUFDTCxTQUFPSCxDQUFDLEdBQUcsQ0FBSixJQUFTRyxDQUFULElBQWNyQixNQUFNLENBQUMwQixjQUFQLENBQXNCWCxNQUF0QixFQUE4QkMsR0FBOUIsRUFBbUNLLENBQW5DLENBQWQsRUFBcURBLENBQTVEO0FBQ0gsQ0FMRDs7QUFNQSxJQUFJTSxTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE0QixVQUFVQyxPQUFWLEVBQW1CQyxVQUFuQixFQUErQkMsQ0FBL0IsRUFBa0NDLFNBQWxDLEVBQTZDO0FBQ3JGLFdBQVNDLEtBQVQsQ0FBZUMsS0FBZixFQUFzQjtBQUFFLFdBQU9BLEtBQUssWUFBWUgsQ0FBakIsR0FBcUJHLEtBQXJCLEdBQTZCLElBQUlILENBQUosQ0FBTSxVQUFVSSxPQUFWLEVBQW1CO0FBQUVBLGFBQU8sQ0FBQ0QsS0FBRCxDQUFQO0FBQWlCLEtBQTVDLENBQXBDO0FBQW9GOztBQUM1RyxTQUFPLEtBQUtILENBQUMsS0FBS0EsQ0FBQyxHQUFHSyxPQUFULENBQU4sRUFBeUIsVUFBVUQsT0FBVixFQUFtQkUsTUFBbkIsRUFBMkI7QUFDdkQsYUFBU0MsU0FBVCxDQUFtQkosS0FBbkIsRUFBMEI7QUFBRSxVQUFJO0FBQUVLLFlBQUksQ0FBQ1AsU0FBUyxDQUFDUSxJQUFWLENBQWVOLEtBQWYsQ0FBRCxDQUFKO0FBQThCLE9BQXBDLENBQXFDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixjQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzNGLGFBQVNDLFFBQVQsQ0FBa0JSLEtBQWxCLEVBQXlCO0FBQUUsVUFBSTtBQUFFSyxZQUFJLENBQUNQLFNBQVMsQ0FBQyxPQUFELENBQVQsQ0FBbUJFLEtBQW5CLENBQUQsQ0FBSjtBQUFrQyxPQUF4QyxDQUF5QyxPQUFPTyxDQUFQLEVBQVU7QUFBRUosY0FBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUM5RixhQUFTRixJQUFULENBQWNJLE1BQWQsRUFBc0I7QUFBRUEsWUFBTSxDQUFDQyxJQUFQLEdBQWNULE9BQU8sQ0FBQ1EsTUFBTSxDQUFDVCxLQUFSLENBQXJCLEdBQXNDRCxLQUFLLENBQUNVLE1BQU0sQ0FBQ1QsS0FBUixDQUFMLENBQW9CVyxJQUFwQixDQUF5QlAsU0FBekIsRUFBb0NJLFFBQXBDLENBQXRDO0FBQXNGOztBQUM5R0gsUUFBSSxDQUFDLENBQUNQLFNBQVMsR0FBR0EsU0FBUyxDQUFDYyxLQUFWLENBQWdCakIsT0FBaEIsRUFBeUJDLFVBQVUsSUFBSSxFQUF2QyxDQUFiLEVBQXlEVSxJQUF6RCxFQUFELENBQUo7QUFDSCxHQUxNLENBQVA7QUFNSCxDQVJEOztBQVNBLElBQUlPLFdBQVcsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxXQUFkLElBQThCLFVBQVVsQixPQUFWLEVBQW1CbUIsSUFBbkIsRUFBeUI7QUFDckUsTUFBSUMsQ0FBQyxHQUFHO0FBQUVDLFNBQUssRUFBRSxDQUFUO0FBQVlDLFFBQUksRUFBRSxnQkFBVztBQUFFLFVBQUlDLENBQUMsQ0FBQyxDQUFELENBQUQsR0FBTyxDQUFYLEVBQWMsTUFBTUEsQ0FBQyxDQUFDLENBQUQsQ0FBUDtBQUFZLGFBQU9BLENBQUMsQ0FBQyxDQUFELENBQVI7QUFBYyxLQUF2RTtBQUF5RUMsUUFBSSxFQUFFLEVBQS9FO0FBQW1GQyxPQUFHLEVBQUU7QUFBeEYsR0FBUjtBQUFBLE1BQXNHQyxDQUF0RztBQUFBLE1BQXlHQyxDQUF6RztBQUFBLE1BQTRHSixDQUE1RztBQUFBLE1BQStHSyxDQUEvRztBQUNBLFNBQU9BLENBQUMsR0FBRztBQUFFakIsUUFBSSxFQUFFa0IsSUFBSSxDQUFDLENBQUQsQ0FBWjtBQUFpQixhQUFTQSxJQUFJLENBQUMsQ0FBRCxDQUE5QjtBQUFtQyxjQUFVQSxJQUFJLENBQUMsQ0FBRDtBQUFqRCxHQUFKLEVBQTRELE9BQU9DLE1BQVAsS0FBa0IsVUFBbEIsS0FBaUNGLENBQUMsQ0FBQ0UsTUFBTSxDQUFDQyxRQUFSLENBQUQsR0FBcUIsWUFBVztBQUFFLFdBQU8sSUFBUDtBQUFjLEdBQWpGLENBQTVELEVBQWdKSCxDQUF2Sjs7QUFDQSxXQUFTQyxJQUFULENBQWNHLENBQWQsRUFBaUI7QUFBRSxXQUFPLFVBQVVDLENBQVYsRUFBYTtBQUFFLGFBQU92QixJQUFJLENBQUMsQ0FBQ3NCLENBQUQsRUFBSUMsQ0FBSixDQUFELENBQVg7QUFBc0IsS0FBNUM7QUFBK0M7O0FBQ2xFLFdBQVN2QixJQUFULENBQWN3QixFQUFkLEVBQWtCO0FBQ2QsUUFBSVIsQ0FBSixFQUFPLE1BQU0sSUFBSTlDLFNBQUosQ0FBYyxpQ0FBZCxDQUFOOztBQUNQLFdBQU93QyxDQUFQO0FBQVUsVUFBSTtBQUNWLFlBQUlNLENBQUMsR0FBRyxDQUFKLEVBQU9DLENBQUMsS0FBS0osQ0FBQyxHQUFHVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBUixHQUFZUCxDQUFDLENBQUMsUUFBRCxDQUFiLEdBQTBCTyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFQLENBQUMsQ0FBQyxPQUFELENBQUQsS0FBZSxDQUFDSixDQUFDLEdBQUdJLENBQUMsQ0FBQyxRQUFELENBQU4sS0FBcUJKLENBQUMsQ0FBQzVDLElBQUYsQ0FBT2dELENBQVAsQ0FBckIsRUFBZ0MsQ0FBL0MsQ0FBUixHQUE0REEsQ0FBQyxDQUFDaEIsSUFBakcsQ0FBRCxJQUEyRyxDQUFDLENBQUNZLENBQUMsR0FBR0EsQ0FBQyxDQUFDNUMsSUFBRixDQUFPZ0QsQ0FBUCxFQUFVTyxFQUFFLENBQUMsQ0FBRCxDQUFaLENBQUwsRUFBdUJuQixJQUE5SSxFQUFvSixPQUFPUSxDQUFQO0FBQ3BKLFlBQUlJLENBQUMsR0FBRyxDQUFKLEVBQU9KLENBQVgsRUFBY1csRUFBRSxHQUFHLENBQUNBLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFULEVBQVlYLENBQUMsQ0FBQ2xCLEtBQWQsQ0FBTDs7QUFDZCxnQkFBUTZCLEVBQUUsQ0FBQyxDQUFELENBQVY7QUFDSSxlQUFLLENBQUw7QUFBUSxlQUFLLENBQUw7QUFBUVgsYUFBQyxHQUFHVyxFQUFKO0FBQVE7O0FBQ3hCLGVBQUssQ0FBTDtBQUFRZCxhQUFDLENBQUNDLEtBQUY7QUFBVyxtQkFBTztBQUFFaEIsbUJBQUssRUFBRTZCLEVBQUUsQ0FBQyxDQUFELENBQVg7QUFBZ0JuQixrQkFBSSxFQUFFO0FBQXRCLGFBQVA7O0FBQ25CLGVBQUssQ0FBTDtBQUFRSyxhQUFDLENBQUNDLEtBQUY7QUFBV00sYUFBQyxHQUFHTyxFQUFFLENBQUMsQ0FBRCxDQUFOO0FBQVdBLGNBQUUsR0FBRyxDQUFDLENBQUQsQ0FBTDtBQUFVOztBQUN4QyxlQUFLLENBQUw7QUFBUUEsY0FBRSxHQUFHZCxDQUFDLENBQUNLLEdBQUYsQ0FBTVUsR0FBTixFQUFMOztBQUFrQmYsYUFBQyxDQUFDSSxJQUFGLENBQU9XLEdBQVA7O0FBQWM7O0FBQ3hDO0FBQ0ksZ0JBQUksRUFBRVosQ0FBQyxHQUFHSCxDQUFDLENBQUNJLElBQU4sRUFBWUQsQ0FBQyxHQUFHQSxDQUFDLENBQUMvQixNQUFGLEdBQVcsQ0FBWCxJQUFnQitCLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDL0IsTUFBRixHQUFXLENBQVosQ0FBbkMsTUFBdUQwQyxFQUFFLENBQUMsQ0FBRCxDQUFGLEtBQVUsQ0FBVixJQUFlQSxFQUFFLENBQUMsQ0FBRCxDQUFGLEtBQVUsQ0FBaEYsQ0FBSixFQUF3RjtBQUFFZCxlQUFDLEdBQUcsQ0FBSjtBQUFPO0FBQVc7O0FBQzVHLGdCQUFJYyxFQUFFLENBQUMsQ0FBRCxDQUFGLEtBQVUsQ0FBVixLQUFnQixDQUFDWCxDQUFELElBQU9XLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUVgsQ0FBQyxDQUFDLENBQUQsQ0FBVCxJQUFnQlcsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRWCxDQUFDLENBQUMsQ0FBRCxDQUFoRCxDQUFKLEVBQTJEO0FBQUVILGVBQUMsQ0FBQ0MsS0FBRixHQUFVYSxFQUFFLENBQUMsQ0FBRCxDQUFaO0FBQWlCO0FBQVE7O0FBQ3RGLGdCQUFJQSxFQUFFLENBQUMsQ0FBRCxDQUFGLEtBQVUsQ0FBVixJQUFlZCxDQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBOUIsRUFBbUM7QUFBRUgsZUFBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQVg7QUFBZ0JBLGVBQUMsR0FBR1csRUFBSjtBQUFRO0FBQVE7O0FBQ3JFLGdCQUFJWCxDQUFDLElBQUlILENBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUFwQixFQUF5QjtBQUFFSCxlQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBWDs7QUFBZ0JILGVBQUMsQ0FBQ0ssR0FBRixDQUFNVyxJQUFOLENBQVdGLEVBQVg7O0FBQWdCO0FBQVE7O0FBQ25FLGdCQUFJWCxDQUFDLENBQUMsQ0FBRCxDQUFMLEVBQVVILENBQUMsQ0FBQ0ssR0FBRixDQUFNVSxHQUFOOztBQUNWZixhQUFDLENBQUNJLElBQUYsQ0FBT1csR0FBUDs7QUFBYztBQVh0Qjs7QUFhQUQsVUFBRSxHQUFHZixJQUFJLENBQUN4QyxJQUFMLENBQVVxQixPQUFWLEVBQW1Cb0IsQ0FBbkIsQ0FBTDtBQUNILE9BakJTLENBaUJSLE9BQU9SLENBQVAsRUFBVTtBQUFFc0IsVUFBRSxHQUFHLENBQUMsQ0FBRCxFQUFJdEIsQ0FBSixDQUFMO0FBQWFlLFNBQUMsR0FBRyxDQUFKO0FBQVEsT0FqQnpCLFNBaUJrQztBQUFFRCxTQUFDLEdBQUdILENBQUMsR0FBRyxDQUFSO0FBQVk7QUFqQjFEOztBQWtCQSxRQUFJVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBWixFQUFlLE1BQU1BLEVBQUUsQ0FBQyxDQUFELENBQVI7QUFBYSxXQUFPO0FBQUU3QixXQUFLLEVBQUU2QixFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFBLEVBQUUsQ0FBQyxDQUFELENBQVYsR0FBZ0IsS0FBSyxDQUE5QjtBQUFpQ25CLFVBQUksRUFBRTtBQUF2QyxLQUFQO0FBQy9CO0FBQ0osQ0ExQkQ7O0FBMkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJc0IsTUFBTSxHQUFHQyxxREFBUyxDQUFDLE1BQUQsQ0FBdEI7O0FBQ0EsSUFBSUMsU0FBUztBQUFHO0FBQWUsVUFBVUMsTUFBVixFQUFrQjtBQUM3Q3hFLFdBQVMsQ0FBQ3VFLFNBQUQsRUFBWUMsTUFBWixDQUFUOztBQUNBLFdBQVNELFNBQVQsR0FBcUI7QUFDakIsUUFBSUUsS0FBSyxHQUFHRCxNQUFNLEtBQUssSUFBWCxJQUFtQkEsTUFBTSxDQUFDdkIsS0FBUCxDQUFhLElBQWIsRUFBbUIxQixTQUFuQixDQUFuQixJQUFvRCxJQUFoRTs7QUFDQWtELFNBQUssQ0FBQ0MsSUFBTixHQUFhO0FBQ1RDLGdCQUFVLEVBQUUsS0FESDtBQUVUQyxXQUFLLEVBQUUsRUFGRTtBQUdUQyxjQUFRLEVBQUU7QUFIRCxLQUFiO0FBS0FKLFNBQUssQ0FBQ0ssU0FBTixHQUFrQixLQUFsQjtBQUNBTCxTQUFLLENBQUNNLFNBQU4sR0FBa0IsS0FBbEI7QUFDQSxXQUFPTixLQUFQO0FBQ0g7O0FBQ0RGLFdBQVMsQ0FBQzlELFNBQVYsQ0FBb0J1RSxPQUFwQixHQUE4QixZQUFZO0FBQ3RDLFdBQU9qRCxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxVQUFJa0QsSUFBSixFQUFVQyxJQUFWOztBQUNBLFVBQUlULEtBQUssR0FBRyxJQUFaOztBQUNBLGFBQU92QixXQUFXLENBQUMsSUFBRCxFQUFPLFVBQVVpQyxFQUFWLEVBQWM7QUFDbkMsZ0JBQVFBLEVBQUUsQ0FBQzlCLEtBQVg7QUFDSSxlQUFLLENBQUw7QUFBUSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLEtBQUsrQixLQUFMLENBQVdwRSxNQUFYLENBQWtCO0FBQ3ZDcUUscUJBQU8sRUFBRTtBQUQ4QixhQUFsQixFQUV0QkMsR0FGc0IsQ0FFbEIsc0JBRmtCLENBQWQsQ0FBUDs7QUFHUixlQUFLLENBQUw7QUFDSUgsY0FBRSxDQUFDN0IsSUFBSDs7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLEtBQUs4QixLQUFMLENBQVdHLElBQVgsQ0FBZ0IsUUFBaEIsRUFBMEIsS0FBS2IsSUFBL0IsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJTyxnQkFBSSxHQUFJRSxFQUFFLENBQUM3QixJQUFILEVBQUQsQ0FBWWtDLElBQW5COztBQUNBLGdCQUFJLENBQUNQLElBQUksQ0FBQ1EsRUFBVixFQUFjO0FBQ1Ysa0JBQUlSLElBQUksQ0FBQ1MsS0FBTCxJQUFjVCxJQUFJLENBQUNVLE9BQXZCLEVBQWdDO0FBQzVCQyxzRUFBTSxDQUFDWCxJQUFJLENBQUNVLE9BQU4sRUFBZSxLQUFmLENBQU47QUFDQSx1QkFBTyxDQUFDO0FBQUU7QUFBSCxpQkFBUDtBQUNIOztBQUNEQyxvRUFBTSxDQUFDLGFBQUQsRUFBZ0IsS0FBaEIsQ0FBTjtBQUNBLHFCQUFPLENBQUM7QUFBRTtBQUFILGVBQVA7QUFDSDs7QUFDREMsd0JBQVksQ0FBQ0MsT0FBYixDQUFxQixvQkFBckIsRUFBMkNiLElBQUksQ0FBQ2MsS0FBaEQ7QUFDQSxtQkFBT2QsSUFBSSxDQUFDYyxLQUFaO0FBQ0EsaUJBQUtDLE9BQUwsQ0FBYWYsSUFBYjtBQUNBLGlCQUFLZ0IsUUFBTDtBQUNBZixnQkFBSSxHQUFHRCxJQUFJLENBQUNpQixTQUFaOztBQUNBLGdCQUFJaEIsSUFBSSxLQUFLLGFBQWIsRUFBNEI7QUFDeEJpQix3QkFBVSxDQUFDLFlBQVk7QUFDbkIxQixxQkFBSyxDQUFDMkIsT0FBTixDQUFjaEMsSUFBZCxDQUFtQjtBQUFFaUMsc0JBQUksRUFBRW5CO0FBQVIsaUJBQW5CO0FBQ0gsZUFGUyxFQUVQLEdBRk8sQ0FBVjtBQUdIOztBQUNELG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7QUEzQlI7QUE2QkgsT0E5QmlCLENBQWxCO0FBK0JILEtBbENlLENBQWhCO0FBbUNILEdBcENEOztBQXFDQVgsV0FBUyxDQUFDOUQsU0FBVixDQUFvQjZGLEtBQXBCLEdBQTRCLFVBQVVDLEdBQVYsRUFBZTtBQUN2QyxXQUFPeEUsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsVUFBSW9ELEVBQUo7O0FBQ0EsYUFBT2pDLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVXNELEVBQVYsRUFBYztBQUNuQyxnQkFBUUEsRUFBRSxDQUFDbkQsS0FBWDtBQUNJLGVBQUssQ0FBTDtBQUNJLGdCQUFJLENBQUNvRCw4REFBYyxDQUFDRixHQUFELENBQW5CLEVBQ0ksT0FBTyxDQUFDO0FBQUU7QUFBSCxhQUFQO0FBQ0osaUJBQUt4QixTQUFMLEdBQWlCLElBQWpCO0FBQ0F5QixjQUFFLENBQUNuRCxLQUFILEdBQVcsQ0FBWDs7QUFDSixlQUFLLENBQUw7QUFDSW1ELGNBQUUsQ0FBQ2hELElBQUgsQ0FBUVksSUFBUixDQUFhLENBQUMsQ0FBRCxFQUFJLENBQUosR0FBUyxDQUFULENBQWI7O0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxLQUFLWSxPQUFMLEVBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSXdCLGNBQUUsQ0FBQ2xELElBQUg7O0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7O0FBQ0osZUFBSyxDQUFMO0FBQ0k2QixjQUFFLEdBQUdxQixFQUFFLENBQUNsRCxJQUFILEVBQUw7QUFDQSxpQkFBS29ELGdCQUFMLENBQXNCLHNCQUF0QjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLM0IsU0FBTCxHQUFpQixLQUFqQjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7QUFsQlI7QUFvQkgsT0FyQmlCLENBQWxCO0FBc0JILEtBeEJlLENBQWhCO0FBeUJILEdBMUJEOztBQTJCQTlELFlBQVUsQ0FBQyxDQUNQMEYsOENBRE8sQ0FBRCxFQUVQcEMsU0FBUyxDQUFDOUQsU0FGSCxFQUVjLFVBRmQsRUFFMEIsS0FBSyxDQUYvQixDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUDBGLDhDQURPLENBQUQsRUFFUHBDLFNBQVMsQ0FBQzlELFNBRkgsRUFFYyxrQkFGZCxFQUVrQyxLQUFLLENBRnZDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDc0MsTUFEQSxDQUFELEVBRVBwQyxTQUFTLENBQUM5RCxTQUZILEVBRWMsU0FGZCxFQUV5QixLQUFLLENBRjlCLENBQVY7O0FBR0E4RCxXQUFTLEdBQUd0RCxVQUFVLENBQUMsQ0FDbkIyRixpRUFBUyxDQUFDO0FBQ05DLGNBQVUsRUFBRTtBQUNSQyw2QkFBdUIsRUFBRUEsa0VBQXVCQTtBQUR4QztBQUROLEdBQUQsQ0FEVSxDQUFELEVBTW5CdkMsU0FObUIsQ0FBdEI7QUFPQSxTQUFPQSxTQUFQO0FBQ0gsQ0E5RjhCLENBOEY3QndDLHVEQTlGNkIsQ0FBL0I7O0FBK0ZBLGlFQUFleEMsU0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7QUM5SkEsSUFBSWtDLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBVUYsR0FBVixFQUFlO0FBQ2hDLE1BQUk3QixJQUFJLEdBQUc2QixHQUFHLENBQUNwRixNQUFmOztBQUNBLE1BQUksQ0FBQ3VELElBQUksQ0FBQ3NDLGFBQUwsRUFBTCxFQUEyQjtBQUN2QixXQUFPLEtBQVA7QUFDSDs7QUFDRFQsS0FBRyxDQUFDVSxjQUFKO0FBQ0EsU0FBTyxJQUFQO0FBQ0gsQ0FQRDs7QUFRQSxpRUFBZVIsY0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkE7QUFDa0k7QUFDN0I7QUFDckcsOEJBQThCLG1GQUEyQixDQUFDLHdHQUFxQztBQUMvRjtBQUNBLHFFQUFxRSx3QkFBd0IsR0FBRyxXQUFXLDRHQUE0RyxNQUFNLFdBQVcseURBQXlELGlCQUFpQiwrQkFBK0IsWUFBWSxvQkFBb0IsbUJBQW1CLFlBQVksMEJBQTBCLHNCQUFzQiw0Q0FBNEMsd0RBQXdELHlDQUF5QyxvQkFBb0IsbUJBQW1CLHVDQUF1QyxNQUFNLGlEQUFpRCx1QkFBdUIsK0JBQStCLDZCQUE2QixrQkFBa0IsdUVBQXVFLHdCQUF3Qix3QkFBd0IsMkJBQTJCLGlDQUFpQyxnQ0FBZ0MsZ0RBQWdELGFBQWEsbURBQW1ELDJCQUEyQiwyQ0FBMkMsd0NBQXdDLG1CQUFtQixXQUFXLDJDQUEyQyxpQkFBaUIsU0FBUyxnR0FBZ0csK0JBQStCLHdCQUF3Qix3Q0FBd0MseUNBQXlDLDRCQUE0QiwrQkFBK0IsYUFBYSxFQUFFLFdBQVcsT0FBTyxTQUFTLE9BQU8sbUNBQW1DLHlDQUF5QyxrQ0FBa0MsaUJBQWlCLCtCQUErQixTQUFTLFFBQVEsd0RBQXdELFNBQVMsbUNBQW1DLE9BQU8sS0FBSyxvakJBQW9qQixxQkFBcUIsa25CQUFrbkIsOEJBQThCLG1GQUFtRix1QkFBdUIsMkVBQTJFLCtCQUErQiw4TEFBOEwsc0JBQXNCLG9CQUFvQixxQkFBcUIsbUZBQW1GLDBCQUEwQixvQkFBb0Isd0JBQXdCLGlEQUFpRCx3QkFBd0IsS0FBSyxtQ0FBbUM7QUFDbDNIO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHNFO0FBQ2hEO0FBQ0w7QUFDeEQsQ0FBNkY7OztBQUc3RjtBQUNtRztBQUNuRyxnQkFBZ0Isb0dBQVU7QUFDMUIsRUFBRSw0RUFBTTtBQUNSLEVBQUUsc0dBQU07QUFDUixFQUFFLCtHQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsSUFBSSxLQUFVLEVBQUUsWUFpQmY7QUFDRDtBQUNBLGlFQUFlLGlCOzs7Ozs7Ozs7Ozs7Ozs7O0FDdkM2UixDQUFDLGlFQUFlLHNRQUFHLEVBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBaFU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxNQUFNLG9CQUFvQixFQUFFO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBLFNBQVMsU0FBUyxZQUFZLEVBQUU7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVMsV0FBVyxFQUFFO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQSxzQ0FBc0MsNEJBQTRCO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVMsV0FBVyxFQUFFO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsZ0NBQWdDLGlDQUFpQztBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUyxXQUFXLEVBQUU7QUFDdkM7QUFDQSxzQ0FBc0MsU0FBUyxjQUFjLEVBQUU7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHNCQUFzQjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUM7QUFDbkM7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLDhCQUE4QixXQUFXLEVBQUU7QUFDdEU7QUFDQTtBQUNBLG1CQUFtQixnREFBZ0Q7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsMEJBQTBCO0FBQzFELGdDQUFnQztBQUNoQyx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNqTEE7O0FBRUE7QUFDQSxjQUFjLG1CQUFPLENBQUMsd3dCQUE0WTtBQUNsYTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsaUtBQXVGO0FBQ2pHLCtDQUErQztBQUMvQztBQUNBLEdBQUcsS0FBVSxFQUFFLEUiLCJmaWxlIjoianMvcmVzb3VyY2VzX2Fzc2V0c192dWVfdmlld3NfYXV0aF9BdXRoTG9naW5fdnVlLmpzIiwic291cmNlc0NvbnRlbnQiOlsidmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2RlY29yYXRlID0gKHRoaXMgJiYgdGhpcy5fX2RlY29yYXRlKSB8fCBmdW5jdGlvbiAoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn07XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBBY3Rpb24sIG5hbWVzcGFjZSB9IGZyb20gJ3Z1ZXgtY2xhc3MnO1xyXG5pbXBvcnQgeyBCSWNvblF1ZXN0aW9uQ2lyY2xlRmlsbCB9IGZyb20gJ2Jvb3RzdHJhcC12dWUnO1xyXG5pbXBvcnQgZGlhbG9nIGZyb20gJ0AvdXRpbHMvZGlhbG9nJztcclxuaW1wb3J0IGZvcm1WYWxpZGF0aW9uIGZyb20gJ0AvdXRpbHMvZm9ybVZhbGlkYXRpb24nO1xyXG52YXIgYVN0b3JlID0gbmFtZXNwYWNlKCdhdXRoJyk7XHJcbnZhciBBdXRoTG9naW4gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XHJcbiAgICBfX2V4dGVuZHMoQXV0aExvZ2luLCBfc3VwZXIpO1xyXG4gICAgZnVuY3Rpb24gQXV0aExvZ2luKCkge1xyXG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xyXG4gICAgICAgIF90aGlzLmZvcm0gPSB7XHJcbiAgICAgICAgICAgIHJlbWVtYmVyTWU6IGZhbHNlLFxyXG4gICAgICAgICAgICBlbWFpbDogJycsXHJcbiAgICAgICAgICAgIHBhc3N3b3JkOiAnJyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIF90aGlzLmF1dGhFcnJvciA9IGZhbHNlO1xyXG4gICAgICAgIF90aGlzLmlzU2VuZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIHJldHVybiBfdGhpcztcclxuICAgIH1cclxuICAgIEF1dGhMb2dpbi5wcm90b3R5cGUuZG9Mb2dpbiA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHZhciB1c2VyLCBwYXRoO1xyXG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCB0aGlzLmF4aW9zLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlVVJMOiAnLycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLmdldCgnL3NhbmN0dW0vY3NyZi1jb29raWUnKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHRoaXMuYXhpb3MucG9zdCgnL2xvZ2luJywgdGhpcy5mb3JtKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyID0gKF9hLnNlbnQoKSkuZGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF1c2VyLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlci5lcnJvciAmJiB1c2VyLm1lc3NhZ2UpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaWFsb2codXNlci5tZXNzYWdlLCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlhbG9nKCdhdXRoLmZhaWxlZCcsIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZGVmYXVsdF9hdXRoX3Rva2VuJywgdXNlci50b2tlbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB1c2VyLnRva2VuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNldFVzZXIodXNlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aCA9IHVzZXIuaG9tZV9wYXRoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocGF0aCAhPT0gJ3B1YmxpYy5ob21lJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJHJvdXRlci5wdXNoKHsgbmFtZTogcGF0aCB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBBdXRoTG9naW4ucHJvdG90eXBlLmxvZ2luID0gZnVuY3Rpb24gKGV2dCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgdmFyIF9hO1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9iKSB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9iLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWZvcm1WYWxpZGF0aW9uKGV2dCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTZW5kaW5nID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IubGFiZWwgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IudHJ5cy5wdXNoKFsxLCAzLCAsIDRdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5kb0xvZ2luKCldO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA0XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hID0gX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNldERpYWxvZ01lc3NhZ2UoJ2Vycm9ycy5nZW5lcmljX2Vycm9yJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDRdO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgNDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc1NlbmRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBBY3Rpb25cclxuICAgIF0sIEF1dGhMb2dpbi5wcm90b3R5cGUsIFwibG9hZERhdGFcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgQXV0aExvZ2luLnByb3RvdHlwZSwgXCJzZXREaWFsb2dNZXNzYWdlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBhU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBBdXRoTG9naW4ucHJvdG90eXBlLCBcInNldFVzZXJcIiwgdm9pZCAwKTtcclxuICAgIEF1dGhMb2dpbiA9IF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIENvbXBvbmVudCh7XHJcbiAgICAgICAgICAgIGNvbXBvbmVudHM6IHtcclxuICAgICAgICAgICAgICAgIEJJY29uUXVlc3Rpb25DaXJjbGVGaWxsOiBCSWNvblF1ZXN0aW9uQ2lyY2xlRmlsbCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgXSwgQXV0aExvZ2luKTtcclxuICAgIHJldHVybiBBdXRoTG9naW47XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IEF1dGhMb2dpbjtcclxuIiwidmFyIGZvcm1WYWxpZGF0aW9uID0gZnVuY3Rpb24gKGV2dCkge1xyXG4gICAgdmFyIGZvcm0gPSBldnQudGFyZ2V0O1xyXG4gICAgaWYgKCFmb3JtLmNoZWNrVmFsaWRpdHkoKSkge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGV2dC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IGZvcm1WYWxpZGF0aW9uO1xyXG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2Nzc1dpdGhNYXBwaW5nVG9TdHJpbmcuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIlxcbiNsb2dpbltkYXRhLXYtNjQyY2VhMDhdIHtcXHJcXG4gIG1hcmdpbi10b3A6IDE1MHB4O1xcbn1cXHJcXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9hdXRoL0F1dGhMb2dpbi52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIjtBQXNJQTtFQUNBLGlCQUFBO0FBQ0FcIixcInNvdXJjZXNDb250ZW50XCI6W1wiPHNjcmlwdCBsYW5nPVxcXCJ0c1xcXCI+XFxyXFxuaW1wb3J0IHsgQ29tcG9uZW50LCBWdWUgfSBmcm9tICd2dWUtcHJvcGVydHktZGVjb3JhdG9yJztcXHJcXG5pbXBvcnQgeyBBY3Rpb24sIG5hbWVzcGFjZSB9IGZyb20gJ3Z1ZXgtY2xhc3MnO1xcclxcbmltcG9ydCB7IEJJY29uUXVlc3Rpb25DaXJjbGVGaWxsIH0gZnJvbSAnYm9vdHN0cmFwLXZ1ZSc7XFxyXFxuXFxyXFxuaW1wb3J0IGRpYWxvZyBmcm9tICdAL3V0aWxzL2RpYWxvZyc7XFxyXFxuaW1wb3J0IGZvcm1WYWxpZGF0aW9uIGZyb20gJ0AvdXRpbHMvZm9ybVZhbGlkYXRpb24nO1xcclxcblxcclxcbmNvbnN0IGFTdG9yZSA9IG5hbWVzcGFjZSgnYXV0aCcpO1xcclxcblxcclxcbkBDb21wb25lbnQoe1xcclxcbiAgY29tcG9uZW50czoge1xcclxcbiAgICBCSWNvblF1ZXN0aW9uQ2lyY2xlRmlsbCxcXHJcXG4gIH0sXFxyXFxufSlcXHJcXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBBdXRoTG9naW4gZXh0ZW5kcyBWdWUge1xcclxcbiAgQEFjdGlvbiBsb2FkRGF0YTtcXHJcXG4gIEBBY3Rpb24gc2V0RGlhbG9nTWVzc2FnZTtcXHJcXG4gIEBhU3RvcmUuQWN0aW9uIHNldFVzZXI7XFxyXFxuXFxyXFxuICBmb3JtID0ge1xcclxcbiAgICByZW1lbWJlck1lOiBmYWxzZSxcXHJcXG4gICAgZW1haWw6JycsXFxyXFxuICAgIHBhc3N3b3JkOicnLFxcclxcbiAgfTtcXHJcXG4gIGF1dGhFcnJvciA9IGZhbHNlO1xcclxcbiAgaXNTZW5kaW5nID0gZmFsc2U7XFxyXFxuXFxyXFxuICBhc3luYyBkb0xvZ2luKCkge1xcclxcbiAgICBhd2FpdCB0aGlzLmF4aW9zLmNyZWF0ZSh7XFxyXFxuICAgICAgYmFzZVVSTDogJy8nLFxcclxcbiAgICB9KS5nZXQoJy9zYW5jdHVtL2NzcmYtY29va2llJylcXHJcXG5cXHJcXG4gICAgY29uc3QgeyBkYXRhOiB1c2VyIH06IGFueSA9IGF3YWl0IHRoaXMuYXhpb3MucG9zdCgnL2xvZ2luJywgdGhpcy5mb3JtKTtcXHJcXG5cXHJcXG4gICAgaWYgKCF1c2VyLmlkKSB7XFxyXFxuICAgICAgaWYgKHVzZXIuZXJyb3IgJiYgdXNlci5tZXNzYWdlKSB7XFxyXFxuICAgICAgICBkaWFsb2codXNlci5tZXNzYWdlLCBmYWxzZSk7XFxyXFxuICAgICAgICByZXR1cm47XFxyXFxuICAgICAgfVxcclxcblxcclxcbiAgICAgIGRpYWxvZygnYXV0aC5mYWlsZWQnLCBmYWxzZSk7XFxyXFxuICAgICAgcmV0dXJuO1xcclxcbiAgICB9XFxyXFxuXFxyXFxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdkZWZhdWx0X2F1dGhfdG9rZW4nLCB1c2VyLnRva2VuKVxcclxcblxcclxcbiAgICBkZWxldGUgdXNlci50b2tlbjtcXHJcXG5cXHJcXG4gICAgdGhpcy5zZXRVc2VyKHVzZXIpO1xcclxcbiAgICB0aGlzLmxvYWREYXRhKCk7XFxyXFxuXFxyXFxuICAgIGNvbnN0IHBhdGggPSB1c2VyLmhvbWVfcGF0aDtcXHJcXG5cXHJcXG4gICAgaWYgKHBhdGggIT09ICdwdWJsaWMuaG9tZScpIHtcXHJcXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcXHJcXG4gICAgICAgIHRoaXMuJHJvdXRlci5wdXNoKHsgbmFtZTogcGF0aCB9KTtcXHJcXG4gICAgICB9LCA1MDApO1xcclxcbiAgICB9XFxyXFxuICB9XFxyXFxuXFxyXFxuICBhc3luYyBsb2dpbihldnQ6IEV2ZW50KSB7XFxyXFxuICAgIGlmICghZm9ybVZhbGlkYXRpb24oZXZ0KSkgcmV0dXJuO1xcclxcblxcclxcbiAgICB0aGlzLmlzU2VuZGluZyA9IHRydWU7XFxyXFxuXFxyXFxuICAgIHRyeSB7XFxyXFxuICAgICAgYXdhaXQgdGhpcy5kb0xvZ2luKCk7XFxyXFxuICAgIH0gY2F0Y2gge1xcclxcbiAgICAgIHRoaXMuc2V0RGlhbG9nTWVzc2FnZSgnZXJyb3JzLmdlbmVyaWNfZXJyb3InKTtcXHJcXG4gICAgfVxcclxcblxcclxcbiAgICB0aGlzLmlzU2VuZGluZyA9IGZhbHNlO1xcclxcbiAgfVxcclxcbn1cXHJcXG48L3NjcmlwdD5cXHJcXG5cXHJcXG48dGVtcGxhdGUgbGFuZz1cXFwicHVnXFxcIj5cXHJcXG5iLWZvcm0oQHN1Ym1pdD0nbG9naW4nKVxcclxcbiAgYi1jb250YWluZXIoZmx1aWQpXFxyXFxuICAgIGItcm93XFxyXFxuICAgICAgYi1jb2wobWQ9XFxcIjEyXFxcIilcXHJcXG4gICAgICAgIGItZm9ybS1ncm91cC5tb250c2VycmF0LnRleHQtcHJpbWFyeShcXHJcXG4gICAgICAgICAgOmxhYmVsPSckdChcXFwic3RyaW5ncy5lbWFpbFxcXCIpJ1xcclxcbiAgICAgICAgICBsYWJlbC1mb3I9J2VtYWlsJyxcXHJcXG4gICAgICAgIClcXHJcXG4gICAgICAgICAgYi1mb3JtLWlucHV0KFxcclxcbiAgICAgICAgICAgIHR5cGU9J2VtYWlsJyxcXHJcXG4gICAgICAgICAgICB2LW1vZGVsPSdmb3JtLmVtYWlsJyxcXHJcXG4gICAgICAgICAgICBuYW1lPSdlbWFpbCcsXFxyXFxuICAgICAgICAgICAgbWF4bGVuZ3RoPScxOTEnLFxcclxcbiAgICAgICAgICAgIHJlcXVpcmVkLFxcclxcbiAgICAgICAgICAgIGF1dG9mb2N1cyxcXHJcXG4gICAgICAgICAgKVxcclxcbiAgICAgICAgICBzcGFuLmhlbHAtYmxvY2sodi1pZj0nYXV0aEVycm9yJylcXHJcXG4gICAgICAgICAgICBzdHJvbmcge3sgJHQoJ2F1dGguZmFpbGVkJykgfX1cXHJcXG4gICAgICBiLWNvbChtZD1cXFwiMTJcXFwiKVxcclxcbiAgICAgICAgYi1mb3JtLWdyb3VwLm1vbnRzZXJyYXQudGV4dC1wcmltYXJ5KFxcclxcbiAgICAgICAgICA6bGFiZWw9JyR0KFxcXCJzdHJpbmdzLnBhc3N3b3JkXFxcIiknXFxyXFxuICAgICAgICAgIGxhYmVsLWZvcj0ncGFzc3dvcmQnLFxcclxcbiAgICAgICAgKVxcclxcbiAgICAgICAgICBiLWZvcm0taW5wdXQoXFxyXFxuICAgICAgICAgICAgdHlwZT0ncGFzc3dvcmQnLFxcclxcbiAgICAgICAgICAgIHYtbW9kZWw9J2Zvcm0ucGFzc3dvcmQnLFxcclxcbiAgICAgICAgICAgIHJlcXVpcmVkLFxcclxcbiAgICAgICAgICApXFxyXFxuICAgICAgYi1jb2wobWQ9XFxcIjEyXFxcIilcXHJcXG4gICAgICAgIGItZm9ybS1ncm91cCNib3hlc1xcclxcbiAgICAgICAgICAuZC1mbGV4Lmp1c3RpZnktY29udGVudC1iZXR3ZWVuLmFsaWduLWl0ZW1zLWNlbnRlclxcclxcbiAgICAgICAgICAgIGItZm9ybS1jaGVja2JveC5tb250c2VycmF0LnRleHQtcHJpbWFyeShcXHJcXG4gICAgICAgICAgICAgIHYtbW9kZWw9J2Zvcm0ucmVtZW1iZXJNZScsXFxyXFxuICAgICAgICAgICAgICBjaGVja2VkLXZhbHVlPXRydWUsXFxyXFxuICAgICAgICAgICAgICB1bmNoZWNrZWQtdmFsdWU9ZmFsc2UsXFxyXFxuICAgICAgICAgICAgKSB7eyAkdCgnbG9naW4ua2VlcF9jb25uZWN0ZWQnKSB9fVxcclxcblxcclxcbiAgICAgICAgICAgIGItYnV0dG9uLmNvbnRlbnQtdmVydGljYWwudGV4dC1zZWNvbmRhcnkodmFyaWFudD0nbGluaycsIDp0bz0neyBuYW1lOiBcXFwiYXV0aC5yZXNldFxcXCIgfScpXFxyXFxuICAgICAgICAgICAgICBiLWljb24tcXVlc3Rpb24tY2lyY2xlLWZpbGxcXHJcXG4gICAgICAgICAgICAgIHwgJm5ic3A7e3sgJHQoJ2xvZ2luLmZvcmdvdF9wYXNzd29yZCcpIH19XFxyXFxuXFxyXFxuICAgICAgYi1jb2wubWItNChtZD1cXFwiMTJcXFwiKVxcclxcbiAgICAgICAgLmQtZmxleC5qdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblxcclxcbiAgICAgICAgICBiLWJ1dHRvbihcXHJcXG4gICAgICAgICAgICB0eXBlPSdzdWJtaXQnLFxcclxcbiAgICAgICAgICAgIHZhcmlhbnQ9J3ByaW1hcnknLFxcclxcbiAgICAgICAgICAgIDpjbGFzcz0neyBkaXNhYmxlZDogaXNTZW5kaW5nIH0nLFxcclxcbiAgICAgICAgICApIHt7ICR0KCdsb2dpbi5sb2dpbicpIH19XFxyXFxuXFxyXFxuICAgICAgICAgIGItYnV0dG9uKFxcclxcbiAgICAgICAgICAgIHZhcmlhbnQ9J3ByaW1hcnknLFxcclxcbiAgICAgICAgICAgIDp0bz0neyBuYW1lOiBcXFwiYXV0aC5yZWdpc3RlclxcXCIgfScsXFxyXFxuICAgICAgICAgICkge3sgJHQoJ2xvZ2luLnJlZ2lzdGVyJykgfX1cXHJcXG48L3RlbXBsYXRlPlxcclxcblxcclxcbjxzdHlsZSBzY29wZWQ+XFxyXFxuI2xvZ2luIHtcXHJcXG4gIG1hcmdpbi10b3A6IDE1MHB4O1xcclxcbn1cXHJcXG48L3N0eWxlPlxcclxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL0F1dGhMb2dpbi52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NjQyY2VhMDgmc2NvcGVkPXRydWUmbGFuZz1wdWcmXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuZXhwb3J0ICogZnJvbSBcIi4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuaW1wb3J0IHN0eWxlMCBmcm9tIFwiLi9BdXRoTG9naW4udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NjQyY2VhMDgmc2NvcGVkPXRydWUmbGFuZz1jc3MmXCJcblxuXG4vKiBub3JtYWxpemUgY29tcG9uZW50ICovXG5pbXBvcnQgbm9ybWFsaXplciBmcm9tIFwiIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanNcIlxudmFyIGNvbXBvbmVudCA9IG5vcm1hbGl6ZXIoXG4gIHNjcmlwdCxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZhbHNlLFxuICBudWxsLFxuICBcIjY0MmNlYTA4XCIsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcY2FyZGVcXFxcUHJvamVjdHNcXFxcaW5hZ2F2ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCc2NDJjZWEwOCcpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCc2NDJjZWEwOCcsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCc2NDJjZWEwOCcsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD02NDJjZWEwOCZzY29wZWQ9dHJ1ZSZsYW5nPXB1ZyZcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgYXBpLnJlcmVuZGVyKCc2NDJjZWEwOCcsIHtcbiAgICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICAgIHN0YXRpY1JlbmRlckZuczogc3RhdGljUmVuZGVyRm5zXG4gICAgICB9KVxuICAgIH0pXG4gIH1cbn1cbmNvbXBvbmVudC5vcHRpb25zLl9fZmlsZSA9IFwicmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvYXV0aC9BdXRoTG9naW4udnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIjsgZXhwb3J0IGRlZmF1bHQgbW9kOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIiIsInZhciByZW5kZXIgPSBmdW5jdGlvbigpIHtcbiAgdmFyIF92bSA9IHRoaXNcbiAgdmFyIF9oID0gX3ZtLiRjcmVhdGVFbGVtZW50XG4gIHZhciBfYyA9IF92bS5fc2VsZi5fYyB8fCBfaFxuICByZXR1cm4gX2MoXG4gICAgXCJiLWZvcm1cIixcbiAgICB7IG9uOiB7IHN1Ym1pdDogX3ZtLmxvZ2luIH0gfSxcbiAgICBbXG4gICAgICBfYyhcbiAgICAgICAgXCJiLWNvbnRhaW5lclwiLFxuICAgICAgICB7IGF0dHJzOiB7IGZsdWlkOiBcIlwiIH0gfSxcbiAgICAgICAgW1xuICAgICAgICAgIF9jKFxuICAgICAgICAgICAgXCJiLXJvd1wiLFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICAgICAgeyBhdHRyczogeyBtZDogXCIxMlwiIH0gfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWZvcm0tZ3JvdXBcIixcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOiBcIm1vbnRzZXJyYXQgdGV4dC1wcmltYXJ5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBfdm0uJHQoXCJzdHJpbmdzLmVtYWlsXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJlbWFpbFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBcImVtYWlsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGxlbmd0aDogXCIxOTFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9mb2N1czogXCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZGVsOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBfdm0uZm9ybS5lbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF92bS4kc2V0KF92bS5mb3JtLCBcImVtYWlsXCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLmVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICBfdm0uYXV0aEVycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICA/IF9jKFwic3BhblwiLCB7IHN0YXRpY0NsYXNzOiBcImhlbHAtYmxvY2tcIiB9LCBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX2MoXCJzdHJvbmdcIiwgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJhdXRoLmZhaWxlZFwiKSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogX3ZtLl9lKClcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICAgICAgeyBhdHRyczogeyBtZDogXCIxMlwiIH0gfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWZvcm0tZ3JvdXBcIixcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOiBcIm1vbnRzZXJyYXQgdGV4dC1wcmltYXJ5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBfdm0uJHQoXCJzdHJpbmdzLnBhc3N3b3JkXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgdHlwZTogXCJwYXNzd29yZFwiLCByZXF1aXJlZDogXCJcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnBhc3N3b3JkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjazogZnVuY3Rpb24oJCR2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoX3ZtLmZvcm0sIFwicGFzc3dvcmRcIiwgJCR2KVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0ucGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJiLWNvbFwiLFxuICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgbWQ6IFwiMTJcIiB9IH0sXG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgX2MoXCJiLWZvcm0tZ3JvdXBcIiwgeyBhdHRyczogeyBpZDogXCJib3hlc1wiIH0gfSwgW1xuICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiYi1mb3JtLWNoZWNrYm94XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJtb250c2VycmF0IHRleHQtcHJpbWFyeVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IFwiY2hlY2tlZC12YWx1ZVwiOiBcIlwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBfdm0uZm9ybS5yZW1lbWJlck1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJyZW1lbWJlck1lXCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0ucmVtZW1iZXJNZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJsb2dpbi5rZWVwX2Nvbm5lY3RlZFwiKSkpXVxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczogXCJjb250ZW50LXZlcnRpY2FsIHRleHQtc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6IFwibGlua1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG86IHsgbmFtZTogXCJhdXRoLnJlc2V0XCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiYi1pY29uLXF1ZXN0aW9uLWNpcmNsZS1maWxsXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiwqBcIiArIF92bS5fcyhfdm0uJHQoXCJsb2dpbi5mb3Jnb3RfcGFzc3dvcmRcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIF0pXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFwiYi1jb2xcIiwgeyBzdGF0aWNDbGFzczogXCJtYi00XCIsIGF0dHJzOiB7IG1kOiBcIjEyXCIgfSB9LCBbXG4gICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgeyBzdGF0aWNDbGFzczogXCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIiB9LFxuICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M6IHsgZGlzYWJsZWQ6IF92bS5pc1NlbmRpbmcgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHR5cGU6IFwic3VibWl0XCIsIHZhcmlhbnQ6IFwicHJpbWFyeVwiIH1cbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcImxvZ2luLmxvZ2luXCIpKSldXG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiBcInByaW1hcnlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG86IHsgbmFtZTogXCJhdXRoLnJlZ2lzdGVyXCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwibG9naW4ucmVnaXN0ZXJcIikpKV1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIF0pXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgIClcbiAgICAgICAgXSxcbiAgICAgICAgMVxuICAgICAgKVxuICAgIF0sXG4gICAgMVxuICApXG59XG52YXIgc3RhdGljUmVuZGVyRm5zID0gW11cbnJlbmRlci5fd2l0aFN0cmlwcGVkID0gdHJ1ZVxuXG5leHBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IiwiLy8gc3R5bGUtbG9hZGVyOiBBZGRzIHNvbWUgY3NzIHRvIHRoZSBET00gYnkgYWRkaW5nIGEgPHN0eWxlPiB0YWdcblxuLy8gbG9hZCB0aGUgc3R5bGVzXG52YXIgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTlbMF0ucnVsZXNbMF0udXNlWzFdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9sb2FkZXJzL3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcG9zdGNzcy1sb2FkZXIvZGlzdC9janMuanM/P2Nsb25lZFJ1bGVTZXQtOVswXS5ydWxlc1swXS51c2VbMl0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9BdXRoTG9naW4udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NjQyY2VhMDgmc2NvcGVkPXRydWUmbGFuZz1jc3MmXCIpO1xuaWYoY29udGVudC5fX2VzTW9kdWxlKSBjb250ZW50ID0gY29udGVudC5kZWZhdWx0O1xuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2Fscztcbi8vIGFkZCB0aGUgc3R5bGVzIHRvIHRoZSBET01cbnZhciBhZGQgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtc3R5bGUtbG9hZGVyL2xpYi9hZGRTdHlsZXNDbGllbnQuanNcIikuZGVmYXVsdFxudmFyIHVwZGF0ZSA9IGFkZChcIjRhYjBlMWRmXCIsIGNvbnRlbnQsIGZhbHNlLCB7fSk7XG4vLyBIb3QgTW9kdWxlIFJlcGxhY2VtZW50XG5pZihtb2R1bGUuaG90KSB7XG4gLy8gV2hlbiB0aGUgc3R5bGVzIGNoYW5nZSwgdXBkYXRlIHRoZSA8c3R5bGU+IHRhZ3NcbiBpZighY29udGVudC5sb2NhbHMpIHtcbiAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiISEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC05WzBdLnJ1bGVzWzBdLnVzZVsxXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvbG9hZGVycy9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Bvc3Rjc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTlbMF0ucnVsZXNbMF0udXNlWzJdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTY0MmNlYTA4JnNjb3BlZD10cnVlJmxhbmc9Y3NzJlwiLCBmdW5jdGlvbigpIHtcbiAgICAgdmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC05WzBdLnJ1bGVzWzBdLnVzZVsxXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvbG9hZGVycy9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Bvc3Rjc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTlbMF0ucnVsZXNbMF0udXNlWzJdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vQXV0aExvZ2luLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTY0MmNlYTA4JnNjb3BlZD10cnVlJmxhbmc9Y3NzJlwiKTtcbiAgICAgaWYobmV3Q29udGVudC5fX2VzTW9kdWxlKSBuZXdDb250ZW50ID0gbmV3Q29udGVudC5kZWZhdWx0O1xuICAgICBpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcbiAgICAgdXBkYXRlKG5ld0NvbnRlbnQpO1xuICAgfSk7XG4gfVxuIC8vIFdoZW4gdGhlIG1vZHVsZSBpcyBkaXNwb3NlZCwgcmVtb3ZlIHRoZSA8c3R5bGU+IHRhZ3NcbiBtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iXSwic291cmNlUm9vdCI6IiJ9