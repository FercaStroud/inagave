(self["webpackChunklaravel_vue_boilerplate"] = self["webpackChunklaravel_vue_boilerplate"] || []).push([["resources_assets_vue_views_prices_Prices_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var _components_PricesList_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/PricesList.vue */ "./resources/assets/vue/views/prices/components/PricesList.vue");
/* harmony import */ var _components_PricesModal_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/PricesModal.vue */ "./resources/assets/vue/views/prices/components/PricesModal.vue");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};





var pStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('prices');

var Prices =
/** @class */
function (_super) {
  __extends(Prices, _super);

  function Prices() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.isModalAdd = true;
    _this.price = {};
    return _this;
  }

  Prices.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.setBackUrl('/');
        this.setMenu([{
          key: 'add_price',
          text: 'prices.add_price',
          handler: this.addPrice
        }]);
        return [2
        /*return*/
        ];
      });
    });
  };

  Prices.prototype.addPrice = function () {
    this.setModalAdd(true);
    this.setForm(this.price);
    this.setModalVisible(true);
  };

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Prices.prototype, "setBackUrl", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Prices.prototype, "setMenu", void 0);

  __decorate([pStore.State], Prices.prototype, "isLoading", void 0);

  __decorate([pStore.State], Prices.prototype, "form", void 0);

  __decorate([pStore.State], Prices.prototype, "isModalVisible", void 0);

  __decorate([pStore.Action], Prices.prototype, "setModalVisible", void 0);

  __decorate([pStore.Action], Prices.prototype, "setModalAdd", void 0);

  __decorate([pStore.Action], Prices.prototype, "setForm", void 0);

  Prices = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      PricesList: _components_PricesList_vue__WEBPACK_IMPORTED_MODULE_2__.default,
      PricesModal: _components_PricesModal_vue__WEBPACK_IMPORTED_MODULE_3__.default
    }
  })], Prices);
  return Prices;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Prices);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var _utils_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/dialog */ "./resources/assets/vue/utils/dialog.ts");
/* harmony import */ var _PricesModal_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./PricesModal.vue */ "./resources/assets/vue/views/prices/components/PricesModal.vue");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};





var pStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('prices');

var PricesList =
/** @class */
function (_super) {
  __extends(PricesList, _super);

  function PricesList() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.search = '';
    return _this;
  }

  PricesList.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            if (!(this.prices.length == 0)) return [3
            /*break*/
            , 2];
            return [4
            /*yield*/
            , this.getPrices()];

          case 1:
            _a.sent();

            _a.label = 2;

          case 2:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  Object.defineProperty(PricesList.prototype, "actualUser", {
    get: function get() {
      return this.$store.state.auth.user;
    },
    enumerable: false,
    configurable: true
  });

  PricesList.prototype.editPrice = function (price) {
    this.setModalAdd(false);
    this.setForm(price);
    this.setModalVisible(true);
  };

  PricesList.prototype.deletePriceConfirm = function (price) {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , (0,_utils_dialog__WEBPACK_IMPORTED_MODULE_2__.default)('front.delete_price_confirmation', true)];

          case 1:
            if (!_a.sent()) {
              return [2
              /*return*/
              ];
            }

            this.deletePrice(price);
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  PricesList.prototype.getPrices = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadPrices();
        return [2
        /*return*/
        ];
      });
    });
  };

  __decorate([pStore.State], PricesList.prototype, "form", void 0);

  __decorate([pStore.State], PricesList.prototype, "prices", void 0);

  __decorate([pStore.State], PricesList.prototype, "fields", void 0);

  __decorate([pStore.State], PricesList.prototype, "isLoading", void 0);

  __decorate([pStore.State], PricesList.prototype, "isModalVisible", void 0);

  __decorate([pStore.State], PricesList.prototype, "isModalAdd", void 0);

  __decorate([pStore.Action], PricesList.prototype, "loadPrices", void 0);

  __decorate([pStore.Action], PricesList.prototype, "deletePrice", void 0);

  __decorate([pStore.Action], PricesList.prototype, "setModalVisible", void 0);

  __decorate([pStore.Action], PricesList.prototype, "setModalAdd", void 0);

  __decorate([pStore.Action], PricesList.prototype, "setForm", void 0);

  PricesList = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      PricesModal: _PricesModal_vue__WEBPACK_IMPORTED_MODULE_3__.default
    }
  })], PricesList);
  return PricesList;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PricesList);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var pStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('prices');

var PricesModal =
/** @class */
function (_super) {
  __extends(PricesModal, _super);

  function PricesModal() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  PricesModal.prototype.handleOk = function () {
    if (this.isModalAdd) {
      this.addPrice(this.form);
    } else {
      this.editPrice(this.form);
    }
  };

  PricesModal.prototype.handleClose = function () {
    this.setModalVisible(false);
  };

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], PricesModal.prototype, "form", void 0);

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], PricesModal.prototype, "isAdd", void 0);

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], PricesModal.prototype, "isVisible", void 0);

  __decorate([pStore.Action], PricesModal.prototype, "addPrice", void 0);

  __decorate([pStore.Action], PricesModal.prototype, "editPrice", void 0);

  __decorate([pStore.Action], PricesModal.prototype, "setModalVisible", void 0);

  __decorate([pStore.State], PricesModal.prototype, "isModalLoading", void 0);

  __decorate([pStore.State], PricesModal.prototype, "isModalAdd", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], PricesModal.prototype, "setDialogMessage", void 0);

  PricesModal = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({})], PricesModal);
  return PricesModal;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PricesModal);

/***/ }),

/***/ "./resources/assets/vue/views/prices/Prices.vue":
/*!******************************************************!*\
  !*** ./resources/assets/vue/views/prices/Prices.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Prices.vue?vue&type=template&id=242516de&lang=pug& */ "./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug&");
/* harmony import */ var _Prices_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Prices.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _Prices_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/prices/Prices.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesList.vue":
/*!*********************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesList.vue ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug& */ "./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug&");
/* harmony import */ var _PricesList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PricesList.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _PricesList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "22453f2c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/prices/components/PricesList.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesModal.vue":
/*!**********************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesModal.vue ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug& */ "./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug&");
/* harmony import */ var _PricesModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PricesModal.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _PricesModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/prices/components/PricesModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts&":
/*!*******************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Prices_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Prices.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Prices_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts&":
/*!**********************************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PricesList.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts&":
/*!***********************************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PricesModal.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug&":
/*!**********************************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Prices_vue_vue_type_template_id_242516de_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/pug-plain-loader/index.js!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Prices.vue?vue&type=template&id=242516de&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug& ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesList_vue_vue_type_template_id_22453f2c_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug&":
/*!**************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug& ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_PricesModal_vue_vue_type_template_id_8c8ccdde_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug&":
/*!******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/Prices.vue?vue&type=template&id=242516de&lang=pug& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-container",
    { attrs: { tag: "main", fluid: "" } },
    [
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { staticClass: "mt-3" },
            [
              _c("h2", [_vm._v(_vm._s(_vm.$t("prices.title")))]),
              _c("PricesList")
            ],
            1
          )
        ],
        1
      ),
      _c("prices-modal", {
        ref: "prices_modal",
        attrs: {
          form: _vm.form,
          "is-add": _vm.isModalAdd,
          "is-visible": _vm.isModalVisible
        }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesList.vue?vue&type=template&id=22453f2c&scoped=true&lang=pug& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("b-form-input", {
        staticClass: "mb-2",
        staticStyle: { width: "230px", float: "right" },
        attrs: {
          id: "search",
          type: "search",
          placeholder: _vm.$t("strings.search")
        },
        model: {
          value: _vm.search,
          callback: function($$v) {
            _vm.search = $$v
          },
          expression: "search"
        }
      }),
      _c(
        "b-button",
        {
          staticStyle: { "margin-bottom": "5px" },
          attrs: { size: "sm", variant: "outline-primary" },
          on: { click: _vm.getPrices }
        },
        [_vm._v(_vm._s(_vm.$t("strings.update_table")))]
      ),
      _c("b-table", {
        staticClass: "btable",
        staticStyle: {
          "max-height": "calc(100vh - 191px)",
          "font-size": ".75em"
        },
        attrs: {
          striped: "",
          hover: "",
          responsive: "",
          "sticky-header": "",
          "no-border-collapse": "",
          bordered: "",
          outlined: "",
          "head-variant": "dark",
          busy: _vm.isLoading,
          items: _vm.prices,
          fields: _vm.fields,
          "select-mode": "single",
          small: "",
          filter: _vm.search
        },
        scopedSlots: _vm._u([
          {
            key: "table-busy",
            fn: function() {
              return [
                _c(
                  "div",
                  { staticClass: "text-center text-danger" },
                  [_c("b-spinner", { staticClass: "align-middle" })],
                  1
                )
              ]
            },
            proxy: true
          },
          {
            key: "head(price)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("prices.price")))])]
            }
          },
          {
            key: "head(year)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("prices.year")))])]
            }
          },
          {
            key: "head(created_at)",
            fn: function(data) {
              return [
                _c("span", [_vm._v(_vm._s(_vm.$t("strings.created_at")))])
              ]
            }
          },
          {
            key: "head(updated_at)",
            fn: function(data) {
              return [
                _c("span", [_vm._v(_vm._s(_vm.$t("strings.updated_at")))])
              ]
            }
          },
          {
            key: "head(actions)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("strings.actions")))])]
            }
          },
          {
            key: "cell(price)",
            fn: function(data) {
              return [
                _c("span", [_vm._v("$" + _vm._s(data.item.price) + " (MXN)")])
              ]
            }
          },
          {
            key: "cell(year)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(data.item.year))])]
            }
          },
          {
            key: "cell(created_at)",
            fn: function(data) {
              return [
                _c("span", [
                  _vm._v(
                    _vm._s(
                      _vm._f("moment")(data.item.created_at, "D, MMMM YYYY")
                    )
                  )
                ])
              ]
            }
          },
          {
            key: "cell(updated_at)",
            fn: function(data) {
              return [
                _c("span", [
                  _vm._v(
                    _vm._s(
                      _vm._f("moment")(data.item.updated_at, "D, MMMM YYYY")
                    )
                  )
                ])
              ]
            }
          },
          {
            key: "cell(actions)",
            fn: function(data) {
              return [
                _c(
                  "b-button-group",
                  { attrs: { size: "sm" } },
                  [
                    _c(
                      "b-button",
                      {
                        staticStyle: { "font-size": ".8em" },
                        attrs: {
                          title: _vm.$t("strings.edit"),
                          variant: "info"
                        },
                        on: {
                          click: function($event) {
                            return _vm.editPrice(data.item)
                          }
                        }
                      },
                      [_vm._v(_vm._s(_vm.$t("strings.edit")))]
                    ),
                    _c(
                      "b-button",
                      {
                        staticStyle: { "font-size": ".8em" },
                        attrs: {
                          title: _vm.$t("strings.delete"),
                          variant: "danger"
                        },
                        on: {
                          click: function($event) {
                            return _vm.deletePriceConfirm(data.item)
                          }
                        }
                      },
                      [_vm._v(_vm._s(_vm.$t("strings.delete")))]
                    )
                  ],
                  1
                )
              ]
            }
          },
          {
            key: "cell(index)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(data.index + 1))])]
            }
          }
        ])
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/prices/components/PricesModal.vue?vue&type=template&id=8c8ccdde&lang=pug& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-modal",
    {
      attrs: {
        "hide-header-close": "",
        visible: _vm.isVisible,
        size: "md",
        scrollable: "",
        centered: "",
        "cancel-title": _vm.$t("buttons.cancel"),
        "ok-disabled": _vm.isModalLoading,
        "ok-title": _vm.isModalLoading
          ? _vm.$t("buttons.sending")
          : _vm.isModalAdd
          ? _vm.$t("buttons.add")
          : _vm.$t("buttons.update"),
        title: _vm.isModalAdd
          ? _vm.$t("prices.add_price")
          : _vm.$t("prices.edit_price")
      },
      on: {
        hide: _vm.handleClose,
        ok: function($event) {
          $event.preventDefault()
          return _vm.handleOk($event)
        }
      }
    },
    [
      _c(
        "b-form",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    {
                      attrs: {
                        label: _vm.$t("prices.form_price"),
                        description: _vm.$t("prices.form_price_description"),
                        "label-for": "price"
                      }
                    },
                    [
                      _c("b-form-input", {
                        attrs: {
                          id: "price",
                          type: "numeric",
                          min: "0",
                          step: "0.1",
                          required: ""
                        },
                        model: {
                          value: _vm.form.price,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "price", $$v)
                          },
                          expression: "form.price"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c(
                    "b-form-group",
                    {
                      attrs: {
                        label: _vm.$t("prices.form_year"),
                        description: _vm.$t("prices.form_year_description"),
                        "label-for": "year"
                      }
                    },
                    [
                      _c("b-form-input", {
                        attrs: {
                          id: "year",
                          type: "numeric",
                          min: "0",
                          required: ""
                        },
                        model: {
                          value: _vm.form.year,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "year", $$v)
                          },
                          expression: "form.year"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL1ByaWNlcy52dWU/ODViMyIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL2NvbXBvbmVudHMvUHJpY2VzTGlzdC52dWU/ZGY5MSIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL2NvbXBvbmVudHMvUHJpY2VzTW9kYWwudnVlPzk0N2QiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3ByaWNlcy9QcmljZXMudnVlPzgzY2QiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3ByaWNlcy9jb21wb25lbnRzL1ByaWNlc0xpc3QudnVlPzEyNzIiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3ByaWNlcy9jb21wb25lbnRzL1ByaWNlc01vZGFsLnZ1ZT85NzVjIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9wcmljZXMvUHJpY2VzLnZ1ZT8xYTM4Iiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9wcmljZXMvY29tcG9uZW50cy9QcmljZXNMaXN0LnZ1ZT9iZTYxIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9wcmljZXMvY29tcG9uZW50cy9QcmljZXNNb2RhbC52dWU/M2VlYSIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL1ByaWNlcy52dWU/ZjU0ZSIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL2NvbXBvbmVudHMvUHJpY2VzTGlzdC52dWU/N2ExZSIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL2NvbXBvbmVudHMvUHJpY2VzTW9kYWwudnVlP2U1MDEiXSwibmFtZXMiOlsiX19leHRlbmRzIiwiZXh0ZW5kU3RhdGljcyIsImQiLCJiIiwiT2JqZWN0Iiwic2V0UHJvdG90eXBlT2YiLCJfX3Byb3RvX18iLCJBcnJheSIsInAiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJfXyIsImNvbnN0cnVjdG9yIiwiY3JlYXRlIiwiX19kZWNvcmF0ZSIsImRlY29yYXRvcnMiLCJ0YXJnZXQiLCJrZXkiLCJkZXNjIiwiYyIsImFyZ3VtZW50cyIsImxlbmd0aCIsInIiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJSZWZsZWN0IiwiZGVjb3JhdGUiLCJpIiwiZGVmaW5lUHJvcGVydHkiLCJfX2F3YWl0ZXIiLCJ0aGlzQXJnIiwiX2FyZ3VtZW50cyIsIlAiLCJnZW5lcmF0b3IiLCJhZG9wdCIsInZhbHVlIiwicmVzb2x2ZSIsIlByb21pc2UiLCJyZWplY3QiLCJmdWxmaWxsZWQiLCJzdGVwIiwibmV4dCIsImUiLCJyZWplY3RlZCIsInJlc3VsdCIsImRvbmUiLCJ0aGVuIiwiYXBwbHkiLCJfX2dlbmVyYXRvciIsImJvZHkiLCJfIiwibGFiZWwiLCJzZW50IiwidCIsInRyeXMiLCJvcHMiLCJmIiwieSIsImciLCJ2ZXJiIiwiU3ltYm9sIiwiaXRlcmF0b3IiLCJuIiwidiIsIm9wIiwicG9wIiwicHVzaCIsInBTdG9yZSIsIm5hbWVzcGFjZSIsIlByaWNlcyIsIl9zdXBlciIsIl90aGlzIiwiaXNNb2RhbEFkZCIsInByaWNlIiwiY3JlYXRlZCIsIl9hIiwic2V0QmFja1VybCIsInNldE1lbnUiLCJ0ZXh0IiwiaGFuZGxlciIsImFkZFByaWNlIiwic2V0TW9kYWxBZGQiLCJzZXRGb3JtIiwic2V0TW9kYWxWaXNpYmxlIiwiQWN0aW9uIiwiU3RhdGUiLCJDb21wb25lbnQiLCJjb21wb25lbnRzIiwiUHJpY2VzTGlzdCIsIlByaWNlc01vZGFsIiwiVnVlIiwic2VhcmNoIiwicHJpY2VzIiwiZ2V0UHJpY2VzIiwiZ2V0IiwiJHN0b3JlIiwic3RhdGUiLCJhdXRoIiwidXNlciIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJlZGl0UHJpY2UiLCJkZWxldGVQcmljZUNvbmZpcm0iLCJkaWFsb2ciLCJkZWxldGVQcmljZSIsImxvYWRQcmljZXMiLCJoYW5kbGVPayIsImZvcm0iLCJoYW5kbGVDbG9zZSIsIlByb3AiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE2QixZQUFZO0FBQ3JELE1BQUlDLGNBQWEsR0FBRyx1QkFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ2hDRixrQkFBYSxHQUFHRyxNQUFNLENBQUNDLGNBQVAsSUFDWDtBQUFFQyxlQUFTLEVBQUU7QUFBYixpQkFBNkJDLEtBQTdCLElBQXNDLFVBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFRCxPQUFDLENBQUNJLFNBQUYsR0FBY0gsQ0FBZDtBQUFrQixLQUQvRCxJQUVaLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFLFdBQUssSUFBSUssQ0FBVCxJQUFjTCxDQUFkO0FBQWlCLFlBQUlDLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUixDQUFyQyxFQUF3Q0ssQ0FBeEMsQ0FBSixFQUFnRE4sQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBT0wsQ0FBQyxDQUFDSyxDQUFELENBQVI7QUFBakU7QUFBK0UsS0FGckc7O0FBR0EsV0FBT1AsY0FBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBcEI7QUFDSCxHQUxEOztBQU1BLFNBQU8sVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ25CLFFBQUksT0FBT0EsQ0FBUCxLQUFhLFVBQWIsSUFBMkJBLENBQUMsS0FBSyxJQUFyQyxFQUNJLE1BQU0sSUFBSVMsU0FBSixDQUFjLHlCQUF5QkMsTUFBTSxDQUFDVixDQUFELENBQS9CLEdBQXFDLCtCQUFuRCxDQUFOOztBQUNKRixrQkFBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBYjs7QUFDQSxhQUFTVyxFQUFULEdBQWM7QUFBRSxXQUFLQyxXQUFMLEdBQW1CYixDQUFuQjtBQUF1Qjs7QUFDdkNBLEtBQUMsQ0FBQ08sU0FBRixHQUFjTixDQUFDLEtBQUssSUFBTixHQUFhQyxNQUFNLENBQUNZLE1BQVAsQ0FBY2IsQ0FBZCxDQUFiLElBQWlDVyxFQUFFLENBQUNMLFNBQUgsR0FBZU4sQ0FBQyxDQUFDTSxTQUFqQixFQUE0QixJQUFJSyxFQUFKLEVBQTdELENBQWQ7QUFDSCxHQU5EO0FBT0gsQ0FkMkMsRUFBNUM7O0FBZUEsSUFBSUcsVUFBVSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFVBQWQsSUFBNkIsVUFBVUMsVUFBVixFQUFzQkMsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DQyxJQUFuQyxFQUF5QztBQUNuRixNQUFJQyxDQUFDLEdBQUdDLFNBQVMsQ0FBQ0MsTUFBbEI7QUFBQSxNQUEwQkMsQ0FBQyxHQUFHSCxDQUFDLEdBQUcsQ0FBSixHQUFRSCxNQUFSLEdBQWlCRSxJQUFJLEtBQUssSUFBVCxHQUFnQkEsSUFBSSxHQUFHakIsTUFBTSxDQUFDc0Isd0JBQVAsQ0FBZ0NQLE1BQWhDLEVBQXdDQyxHQUF4QyxDQUF2QixHQUFzRUMsSUFBckg7QUFBQSxNQUEySG5CLENBQTNIO0FBQ0EsTUFBSSxRQUFPeUIsT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUFuQixJQUErQixPQUFPQSxPQUFPLENBQUNDLFFBQWYsS0FBNEIsVUFBL0QsRUFBMkVILENBQUMsR0FBR0UsT0FBTyxDQUFDQyxRQUFSLENBQWlCVixVQUFqQixFQUE2QkMsTUFBN0IsRUFBcUNDLEdBQXJDLEVBQTBDQyxJQUExQyxDQUFKLENBQTNFLEtBQ0ssS0FBSyxJQUFJUSxDQUFDLEdBQUdYLFVBQVUsQ0FBQ00sTUFBWCxHQUFvQixDQUFqQyxFQUFvQ0ssQ0FBQyxJQUFJLENBQXpDLEVBQTRDQSxDQUFDLEVBQTdDO0FBQWlELFFBQUkzQixDQUFDLEdBQUdnQixVQUFVLENBQUNXLENBQUQsQ0FBbEIsRUFBdUJKLENBQUMsR0FBRyxDQUFDSCxDQUFDLEdBQUcsQ0FBSixHQUFRcEIsQ0FBQyxDQUFDdUIsQ0FBRCxDQUFULEdBQWVILENBQUMsR0FBRyxDQUFKLEdBQVFwQixDQUFDLENBQUNpQixNQUFELEVBQVNDLEdBQVQsRUFBY0ssQ0FBZCxDQUFULEdBQTRCdkIsQ0FBQyxDQUFDaUIsTUFBRCxFQUFTQyxHQUFULENBQTdDLEtBQStESyxDQUFuRTtBQUF4RTtBQUNMLFNBQU9ILENBQUMsR0FBRyxDQUFKLElBQVNHLENBQVQsSUFBY3JCLE1BQU0sQ0FBQzBCLGNBQVAsQ0FBc0JYLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0ssQ0FBbkMsQ0FBZCxFQUFxREEsQ0FBNUQ7QUFDSCxDQUxEOztBQU1BLElBQUlNLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsYUFBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFlBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixjQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxZQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxRQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNjLEtBQVYsQ0FBZ0JqQixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSU8sV0FBVyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFdBQWQsSUFBOEIsVUFBVWxCLE9BQVYsRUFBbUJtQixJQUFuQixFQUF5QjtBQUNyRSxNQUFJQyxDQUFDLEdBQUc7QUFBRUMsU0FBSyxFQUFFLENBQVQ7QUFBWUMsUUFBSSxFQUFFLGdCQUFXO0FBQUUsVUFBSUMsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQVgsRUFBYyxNQUFNQSxDQUFDLENBQUMsQ0FBRCxDQUFQO0FBQVksYUFBT0EsQ0FBQyxDQUFDLENBQUQsQ0FBUjtBQUFjLEtBQXZFO0FBQXlFQyxRQUFJLEVBQUUsRUFBL0U7QUFBbUZDLE9BQUcsRUFBRTtBQUF4RixHQUFSO0FBQUEsTUFBc0dDLENBQXRHO0FBQUEsTUFBeUdDLENBQXpHO0FBQUEsTUFBNEdKLENBQTVHO0FBQUEsTUFBK0dLLENBQS9HO0FBQ0EsU0FBT0EsQ0FBQyxHQUFHO0FBQUVqQixRQUFJLEVBQUVrQixJQUFJLENBQUMsQ0FBRCxDQUFaO0FBQWlCLGFBQVNBLElBQUksQ0FBQyxDQUFELENBQTlCO0FBQW1DLGNBQVVBLElBQUksQ0FBQyxDQUFEO0FBQWpELEdBQUosRUFBNEQsT0FBT0MsTUFBUCxLQUFrQixVQUFsQixLQUFpQ0YsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLFFBQVIsQ0FBRCxHQUFxQixZQUFXO0FBQUUsV0FBTyxJQUFQO0FBQWMsR0FBakYsQ0FBNUQsRUFBZ0pILENBQXZKOztBQUNBLFdBQVNDLElBQVQsQ0FBY0csQ0FBZCxFQUFpQjtBQUFFLFdBQU8sVUFBVUMsQ0FBVixFQUFhO0FBQUUsYUFBT3ZCLElBQUksQ0FBQyxDQUFDc0IsQ0FBRCxFQUFJQyxDQUFKLENBQUQsQ0FBWDtBQUFzQixLQUE1QztBQUErQzs7QUFDbEUsV0FBU3ZCLElBQVQsQ0FBY3dCLEVBQWQsRUFBa0I7QUFDZCxRQUFJUixDQUFKLEVBQU8sTUFBTSxJQUFJOUMsU0FBSixDQUFjLGlDQUFkLENBQU47O0FBQ1AsV0FBT3dDLENBQVA7QUFBVSxVQUFJO0FBQ1YsWUFBSU0sQ0FBQyxHQUFHLENBQUosRUFBT0MsQ0FBQyxLQUFLSixDQUFDLEdBQUdXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFSLEdBQVlQLENBQUMsQ0FBQyxRQUFELENBQWIsR0FBMEJPLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUVAsQ0FBQyxDQUFDLE9BQUQsQ0FBRCxLQUFlLENBQUNKLENBQUMsR0FBR0ksQ0FBQyxDQUFDLFFBQUQsQ0FBTixLQUFxQkosQ0FBQyxDQUFDNUMsSUFBRixDQUFPZ0QsQ0FBUCxDQUFyQixFQUFnQyxDQUEvQyxDQUFSLEdBQTREQSxDQUFDLENBQUNoQixJQUFqRyxDQUFELElBQTJHLENBQUMsQ0FBQ1ksQ0FBQyxHQUFHQSxDQUFDLENBQUM1QyxJQUFGLENBQU9nRCxDQUFQLEVBQVVPLEVBQUUsQ0FBQyxDQUFELENBQVosQ0FBTCxFQUF1Qm5CLElBQTlJLEVBQW9KLE9BQU9RLENBQVA7QUFDcEosWUFBSUksQ0FBQyxHQUFHLENBQUosRUFBT0osQ0FBWCxFQUFjVyxFQUFFLEdBQUcsQ0FBQ0EsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVQsRUFBWVgsQ0FBQyxDQUFDbEIsS0FBZCxDQUFMOztBQUNkLGdCQUFRNkIsRUFBRSxDQUFDLENBQUQsQ0FBVjtBQUNJLGVBQUssQ0FBTDtBQUFRLGVBQUssQ0FBTDtBQUFRWCxhQUFDLEdBQUdXLEVBQUo7QUFBUTs7QUFDeEIsZUFBSyxDQUFMO0FBQVFkLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXLG1CQUFPO0FBQUVoQixtQkFBSyxFQUFFNkIsRUFBRSxDQUFDLENBQUQsQ0FBWDtBQUFnQm5CLGtCQUFJLEVBQUU7QUFBdEIsYUFBUDs7QUFDbkIsZUFBSyxDQUFMO0FBQVFLLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXTSxhQUFDLEdBQUdPLEVBQUUsQ0FBQyxDQUFELENBQU47QUFBV0EsY0FBRSxHQUFHLENBQUMsQ0FBRCxDQUFMO0FBQVU7O0FBQ3hDLGVBQUssQ0FBTDtBQUFRQSxjQUFFLEdBQUdkLENBQUMsQ0FBQ0ssR0FBRixDQUFNVSxHQUFOLEVBQUw7O0FBQWtCZixhQUFDLENBQUNJLElBQUYsQ0FBT1csR0FBUDs7QUFBYzs7QUFDeEM7QUFDSSxnQkFBSSxFQUFFWixDQUFDLEdBQUdILENBQUMsQ0FBQ0ksSUFBTixFQUFZRCxDQUFDLEdBQUdBLENBQUMsQ0FBQy9CLE1BQUYsR0FBVyxDQUFYLElBQWdCK0IsQ0FBQyxDQUFDQSxDQUFDLENBQUMvQixNQUFGLEdBQVcsQ0FBWixDQUFuQyxNQUF1RDBDLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFoRixDQUFKLEVBQXdGO0FBQUVkLGVBQUMsR0FBRyxDQUFKO0FBQU87QUFBVzs7QUFDNUcsZ0JBQUljLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLEtBQWdCLENBQUNYLENBQUQsSUFBT1csRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRWCxDQUFDLENBQUMsQ0FBRCxDQUFULElBQWdCVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFYLENBQUMsQ0FBQyxDQUFELENBQWhELENBQUosRUFBMkQ7QUFBRUgsZUFBQyxDQUFDQyxLQUFGLEdBQVVhLEVBQUUsQ0FBQyxDQUFELENBQVo7QUFBaUI7QUFBUTs7QUFDdEYsZ0JBQUlBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVkLENBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUE5QixFQUFtQztBQUFFSCxlQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBWDtBQUFnQkEsZUFBQyxHQUFHVyxFQUFKO0FBQVE7QUFBUTs7QUFDckUsZ0JBQUlYLENBQUMsSUFBSUgsQ0FBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQXBCLEVBQXlCO0FBQUVILGVBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUFYOztBQUFnQkgsZUFBQyxDQUFDSyxHQUFGLENBQU1XLElBQU4sQ0FBV0YsRUFBWDs7QUFBZ0I7QUFBUTs7QUFDbkUsZ0JBQUlYLENBQUMsQ0FBQyxDQUFELENBQUwsRUFBVUgsQ0FBQyxDQUFDSyxHQUFGLENBQU1VLEdBQU47O0FBQ1ZmLGFBQUMsQ0FBQ0ksSUFBRixDQUFPVyxHQUFQOztBQUFjO0FBWHRCOztBQWFBRCxVQUFFLEdBQUdmLElBQUksQ0FBQ3hDLElBQUwsQ0FBVXFCLE9BQVYsRUFBbUJvQixDQUFuQixDQUFMO0FBQ0gsT0FqQlMsQ0FpQlIsT0FBT1IsQ0FBUCxFQUFVO0FBQUVzQixVQUFFLEdBQUcsQ0FBQyxDQUFELEVBQUl0QixDQUFKLENBQUw7QUFBYWUsU0FBQyxHQUFHLENBQUo7QUFBUSxPQWpCekIsU0FpQmtDO0FBQUVELFNBQUMsR0FBR0gsQ0FBQyxHQUFHLENBQVI7QUFBWTtBQWpCMUQ7O0FBa0JBLFFBQUlXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFaLEVBQWUsTUFBTUEsRUFBRSxDQUFDLENBQUQsQ0FBUjtBQUFhLFdBQU87QUFBRTdCLFdBQUssRUFBRTZCLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUUEsRUFBRSxDQUFDLENBQUQsQ0FBVixHQUFnQixLQUFLLENBQTlCO0FBQWlDbkIsVUFBSSxFQUFFO0FBQXZDLEtBQVA7QUFDL0I7QUFDSixDQTFCRDs7QUEyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJc0IsTUFBTSxHQUFHQyxxREFBUyxDQUFDLFFBQUQsQ0FBdEI7O0FBQ0EsSUFBSUMsTUFBTTtBQUFHO0FBQWUsVUFBVUMsTUFBVixFQUFrQjtBQUMxQ3hFLFdBQVMsQ0FBQ3VFLE1BQUQsRUFBU0MsTUFBVCxDQUFUOztBQUNBLFdBQVNELE1BQVQsR0FBa0I7QUFDZCxRQUFJRSxLQUFLLEdBQUdELE1BQU0sS0FBSyxJQUFYLElBQW1CQSxNQUFNLENBQUN2QixLQUFQLENBQWEsSUFBYixFQUFtQjFCLFNBQW5CLENBQW5CLElBQW9ELElBQWhFOztBQUNBa0QsU0FBSyxDQUFDQyxVQUFOLEdBQW1CLElBQW5CO0FBQ0FELFNBQUssQ0FBQ0UsS0FBTixHQUFjLEVBQWQ7QUFDQSxXQUFPRixLQUFQO0FBQ0g7O0FBQ0RGLFFBQU0sQ0FBQzlELFNBQVAsQ0FBaUJtRSxPQUFqQixHQUEyQixZQUFZO0FBQ25DLFdBQU83QyxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxhQUFPbUIsV0FBVyxDQUFDLElBQUQsRUFBTyxVQUFVMkIsRUFBVixFQUFjO0FBQ25DLGFBQUtDLFVBQUwsQ0FBZ0IsR0FBaEI7QUFDQSxhQUFLQyxPQUFMLENBQWEsQ0FDVDtBQUNJM0QsYUFBRyxFQUFFLFdBRFQ7QUFFSTRELGNBQUksRUFBRSxrQkFGVjtBQUdJQyxpQkFBTyxFQUFFLEtBQUtDO0FBSGxCLFNBRFMsQ0FBYjtBQU9BLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BVmlCLENBQWxCO0FBV0gsS0FaZSxDQUFoQjtBQWFILEdBZEQ7O0FBZUFYLFFBQU0sQ0FBQzlELFNBQVAsQ0FBaUJ5RSxRQUFqQixHQUE0QixZQUFZO0FBQ3BDLFNBQUtDLFdBQUwsQ0FBaUIsSUFBakI7QUFDQSxTQUFLQyxPQUFMLENBQWEsS0FBS1QsS0FBbEI7QUFDQSxTQUFLVSxlQUFMLENBQXFCLElBQXJCO0FBQ0gsR0FKRDs7QUFLQXBFLFlBQVUsQ0FBQyxDQUNQcUUsOENBRE8sQ0FBRCxFQUVQZixNQUFNLENBQUM5RCxTQUZBLEVBRVcsWUFGWCxFQUV5QixLQUFLLENBRjlCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQcUUsOENBRE8sQ0FBRCxFQUVQZixNQUFNLENBQUM5RCxTQUZBLEVBRVcsU0FGWCxFQUVzQixLQUFLLENBRjNCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDa0IsS0FEQSxDQUFELEVBRVBoQixNQUFNLENBQUM5RCxTQUZBLEVBRVcsV0FGWCxFQUV3QixLQUFLLENBRjdCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDa0IsS0FEQSxDQUFELEVBRVBoQixNQUFNLENBQUM5RCxTQUZBLEVBRVcsTUFGWCxFQUVtQixLQUFLLENBRnhCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDa0IsS0FEQSxDQUFELEVBRVBoQixNQUFNLENBQUM5RCxTQUZBLEVBRVcsZ0JBRlgsRUFFNkIsS0FBSyxDQUZsQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2lCLE1BREEsQ0FBRCxFQUVQZixNQUFNLENBQUM5RCxTQUZBLEVBRVcsaUJBRlgsRUFFOEIsS0FBSyxDQUZuQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2lCLE1BREEsQ0FBRCxFQUVQZixNQUFNLENBQUM5RCxTQUZBLEVBRVcsYUFGWCxFQUUwQixLQUFLLENBRi9CLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDaUIsTUFEQSxDQUFELEVBRVBmLE1BQU0sQ0FBQzlELFNBRkEsRUFFVyxTQUZYLEVBRXNCLEtBQUssQ0FGM0IsQ0FBVjs7QUFHQThELFFBQU0sR0FBR3RELFVBQVUsQ0FBQyxDQUNoQnVFLGlFQUFTLENBQUM7QUFDTkMsY0FBVSxFQUFFO0FBQ1JDLGdCQUFVLEVBQUVBLCtEQURKO0FBRVJDLGlCQUFXLEVBQUVBLGdFQUFXQTtBQUZoQjtBQUROLEdBQUQsQ0FETyxDQUFELEVBT2hCcEIsTUFQZ0IsQ0FBbkI7QUFRQSxTQUFPQSxNQUFQO0FBQ0gsQ0E3RDJCLENBNkQxQnFCLHVEQTdEMEIsQ0FBNUI7O0FBOERBLGlFQUFlckIsTUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1SEEsSUFBSXZFLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTZCLFlBQVk7QUFDckQsTUFBSUMsY0FBYSxHQUFHLHVCQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDaENGLGtCQUFhLEdBQUdHLE1BQU0sQ0FBQ0MsY0FBUCxJQUNYO0FBQUVDLGVBQVMsRUFBRTtBQUFiLGlCQUE2QkMsS0FBN0IsSUFBc0MsVUFBVUwsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUVELE9BQUMsQ0FBQ0ksU0FBRixHQUFjSCxDQUFkO0FBQWtCLEtBRC9ELElBRVosVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUUsV0FBSyxJQUFJSyxDQUFULElBQWNMLENBQWQ7QUFBaUIsWUFBSUMsTUFBTSxDQUFDSyxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNSLENBQXJDLEVBQXdDSyxDQUF4QyxDQUFKLEVBQWdETixDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPTCxDQUFDLENBQUNLLENBQUQsQ0FBUjtBQUFqRTtBQUErRSxLQUZyRzs7QUFHQSxXQUFPUCxjQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFwQjtBQUNILEdBTEQ7O0FBTUEsU0FBTyxVQUFVRCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDbkIsUUFBSSxPQUFPQSxDQUFQLEtBQWEsVUFBYixJQUEyQkEsQ0FBQyxLQUFLLElBQXJDLEVBQ0ksTUFBTSxJQUFJUyxTQUFKLENBQWMseUJBQXlCQyxNQUFNLENBQUNWLENBQUQsQ0FBL0IsR0FBcUMsK0JBQW5ELENBQU47O0FBQ0pGLGtCQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFiOztBQUNBLGFBQVNXLEVBQVQsR0FBYztBQUFFLFdBQUtDLFdBQUwsR0FBbUJiLENBQW5CO0FBQXVCOztBQUN2Q0EsS0FBQyxDQUFDTyxTQUFGLEdBQWNOLENBQUMsS0FBSyxJQUFOLEdBQWFDLE1BQU0sQ0FBQ1ksTUFBUCxDQUFjYixDQUFkLENBQWIsSUFBaUNXLEVBQUUsQ0FBQ0wsU0FBSCxHQUFlTixDQUFDLENBQUNNLFNBQWpCLEVBQTRCLElBQUlLLEVBQUosRUFBN0QsQ0FBZDtBQUNILEdBTkQ7QUFPSCxDQWQyQyxFQUE1Qzs7QUFlQSxJQUFJRyxVQUFVLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsVUFBZCxJQUE2QixVQUFVQyxVQUFWLEVBQXNCQyxNQUF0QixFQUE4QkMsR0FBOUIsRUFBbUNDLElBQW5DLEVBQXlDO0FBQ25GLE1BQUlDLENBQUMsR0FBR0MsU0FBUyxDQUFDQyxNQUFsQjtBQUFBLE1BQTBCQyxDQUFDLEdBQUdILENBQUMsR0FBRyxDQUFKLEdBQVFILE1BQVIsR0FBaUJFLElBQUksS0FBSyxJQUFULEdBQWdCQSxJQUFJLEdBQUdqQixNQUFNLENBQUNzQix3QkFBUCxDQUFnQ1AsTUFBaEMsRUFBd0NDLEdBQXhDLENBQXZCLEdBQXNFQyxJQUFySDtBQUFBLE1BQTJIbkIsQ0FBM0g7QUFDQSxNQUFJLFFBQU95QixPQUFQLHlDQUFPQSxPQUFQLE9BQW1CLFFBQW5CLElBQStCLE9BQU9BLE9BQU8sQ0FBQ0MsUUFBZixLQUE0QixVQUEvRCxFQUEyRUgsQ0FBQyxHQUFHRSxPQUFPLENBQUNDLFFBQVIsQ0FBaUJWLFVBQWpCLEVBQTZCQyxNQUE3QixFQUFxQ0MsR0FBckMsRUFBMENDLElBQTFDLENBQUosQ0FBM0UsS0FDSyxLQUFLLElBQUlRLENBQUMsR0FBR1gsVUFBVSxDQUFDTSxNQUFYLEdBQW9CLENBQWpDLEVBQW9DSyxDQUFDLElBQUksQ0FBekMsRUFBNENBLENBQUMsRUFBN0M7QUFBaUQsUUFBSTNCLENBQUMsR0FBR2dCLFVBQVUsQ0FBQ1csQ0FBRCxDQUFsQixFQUF1QkosQ0FBQyxHQUFHLENBQUNILENBQUMsR0FBRyxDQUFKLEdBQVFwQixDQUFDLENBQUN1QixDQUFELENBQVQsR0FBZUgsQ0FBQyxHQUFHLENBQUosR0FBUXBCLENBQUMsQ0FBQ2lCLE1BQUQsRUFBU0MsR0FBVCxFQUFjSyxDQUFkLENBQVQsR0FBNEJ2QixDQUFDLENBQUNpQixNQUFELEVBQVNDLEdBQVQsQ0FBN0MsS0FBK0RLLENBQW5FO0FBQXhFO0FBQ0wsU0FBT0gsQ0FBQyxHQUFHLENBQUosSUFBU0csQ0FBVCxJQUFjckIsTUFBTSxDQUFDMEIsY0FBUCxDQUFzQlgsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DSyxDQUFuQyxDQUFkLEVBQXFEQSxDQUE1RDtBQUNILENBTEQ7O0FBTUEsSUFBSU0sU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVDLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlILENBQWpCLEdBQXFCRyxLQUFyQixHQUE2QixJQUFJSCxDQUFKLENBQU0sVUFBVUksT0FBVixFQUFtQjtBQUFFQSxhQUFPLENBQUNELEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLSCxDQUFDLEtBQUtBLENBQUMsR0FBR0ssT0FBVCxDQUFOLEVBQXlCLFVBQVVELE9BQVYsRUFBbUJFLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNDLFNBQVQsQ0FBbUJKLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFSyxZQUFJLENBQUNQLFNBQVMsQ0FBQ1EsSUFBVixDQUFlTixLQUFmLENBQUQsQ0FBSjtBQUE4QixPQUFwQyxDQUFxQyxPQUFPTyxDQUFQLEVBQVU7QUFBRUosY0FBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCUixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CRSxLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDOUYsYUFBU0YsSUFBVCxDQUFjSSxNQUFkLEVBQXNCO0FBQUVBLFlBQU0sQ0FBQ0MsSUFBUCxHQUFjVCxPQUFPLENBQUNRLE1BQU0sQ0FBQ1QsS0FBUixDQUFyQixHQUFzQ0QsS0FBSyxDQUFDVSxNQUFNLENBQUNULEtBQVIsQ0FBTCxDQUFvQlcsSUFBcEIsQ0FBeUJQLFNBQXpCLEVBQW9DSSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdILFFBQUksQ0FBQyxDQUFDUCxTQUFTLEdBQUdBLFNBQVMsQ0FBQ2MsS0FBVixDQUFnQmpCLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RFUsSUFBekQsRUFBRCxDQUFKO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FSRDs7QUFTQSxJQUFJTyxXQUFXLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsV0FBZCxJQUE4QixVQUFVbEIsT0FBVixFQUFtQm1CLElBQW5CLEVBQXlCO0FBQ3JFLE1BQUlDLENBQUMsR0FBRztBQUFFQyxTQUFLLEVBQUUsQ0FBVDtBQUFZQyxRQUFJLEVBQUUsZ0JBQVc7QUFBRSxVQUFJQyxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sQ0FBWCxFQUFjLE1BQU1BLENBQUMsQ0FBQyxDQUFELENBQVA7QUFBWSxhQUFPQSxDQUFDLENBQUMsQ0FBRCxDQUFSO0FBQWMsS0FBdkU7QUFBeUVDLFFBQUksRUFBRSxFQUEvRTtBQUFtRkMsT0FBRyxFQUFFO0FBQXhGLEdBQVI7QUFBQSxNQUFzR0MsQ0FBdEc7QUFBQSxNQUF5R0MsQ0FBekc7QUFBQSxNQUE0R0osQ0FBNUc7QUFBQSxNQUErR0ssQ0FBL0c7QUFDQSxTQUFPQSxDQUFDLEdBQUc7QUFBRWpCLFFBQUksRUFBRWtCLElBQUksQ0FBQyxDQUFELENBQVo7QUFBaUIsYUFBU0EsSUFBSSxDQUFDLENBQUQsQ0FBOUI7QUFBbUMsY0FBVUEsSUFBSSxDQUFDLENBQUQ7QUFBakQsR0FBSixFQUE0RCxPQUFPQyxNQUFQLEtBQWtCLFVBQWxCLEtBQWlDRixDQUFDLENBQUNFLE1BQU0sQ0FBQ0MsUUFBUixDQUFELEdBQXFCLFlBQVc7QUFBRSxXQUFPLElBQVA7QUFBYyxHQUFqRixDQUE1RCxFQUFnSkgsQ0FBdko7O0FBQ0EsV0FBU0MsSUFBVCxDQUFjRyxDQUFkLEVBQWlCO0FBQUUsV0FBTyxVQUFVQyxDQUFWLEVBQWE7QUFBRSxhQUFPdkIsSUFBSSxDQUFDLENBQUNzQixDQUFELEVBQUlDLENBQUosQ0FBRCxDQUFYO0FBQXNCLEtBQTVDO0FBQStDOztBQUNsRSxXQUFTdkIsSUFBVCxDQUFjd0IsRUFBZCxFQUFrQjtBQUNkLFFBQUlSLENBQUosRUFBTyxNQUFNLElBQUk5QyxTQUFKLENBQWMsaUNBQWQsQ0FBTjs7QUFDUCxXQUFPd0MsQ0FBUDtBQUFVLFVBQUk7QUFDVixZQUFJTSxDQUFDLEdBQUcsQ0FBSixFQUFPQyxDQUFDLEtBQUtKLENBQUMsR0FBR1csRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVIsR0FBWVAsQ0FBQyxDQUFDLFFBQUQsQ0FBYixHQUEwQk8sRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRUCxDQUFDLENBQUMsT0FBRCxDQUFELEtBQWUsQ0FBQ0osQ0FBQyxHQUFHSSxDQUFDLENBQUMsUUFBRCxDQUFOLEtBQXFCSixDQUFDLENBQUM1QyxJQUFGLENBQU9nRCxDQUFQLENBQXJCLEVBQWdDLENBQS9DLENBQVIsR0FBNERBLENBQUMsQ0FBQ2hCLElBQWpHLENBQUQsSUFBMkcsQ0FBQyxDQUFDWSxDQUFDLEdBQUdBLENBQUMsQ0FBQzVDLElBQUYsQ0FBT2dELENBQVAsRUFBVU8sRUFBRSxDQUFDLENBQUQsQ0FBWixDQUFMLEVBQXVCbkIsSUFBOUksRUFBb0osT0FBT1EsQ0FBUDtBQUNwSixZQUFJSSxDQUFDLEdBQUcsQ0FBSixFQUFPSixDQUFYLEVBQWNXLEVBQUUsR0FBRyxDQUFDQSxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBVCxFQUFZWCxDQUFDLENBQUNsQixLQUFkLENBQUw7O0FBQ2QsZ0JBQVE2QixFQUFFLENBQUMsQ0FBRCxDQUFWO0FBQ0ksZUFBSyxDQUFMO0FBQVEsZUFBSyxDQUFMO0FBQVFYLGFBQUMsR0FBR1csRUFBSjtBQUFROztBQUN4QixlQUFLLENBQUw7QUFBUWQsYUFBQyxDQUFDQyxLQUFGO0FBQVcsbUJBQU87QUFBRWhCLG1CQUFLLEVBQUU2QixFQUFFLENBQUMsQ0FBRCxDQUFYO0FBQWdCbkIsa0JBQUksRUFBRTtBQUF0QixhQUFQOztBQUNuQixlQUFLLENBQUw7QUFBUUssYUFBQyxDQUFDQyxLQUFGO0FBQVdNLGFBQUMsR0FBR08sRUFBRSxDQUFDLENBQUQsQ0FBTjtBQUFXQSxjQUFFLEdBQUcsQ0FBQyxDQUFELENBQUw7QUFBVTs7QUFDeEMsZUFBSyxDQUFMO0FBQVFBLGNBQUUsR0FBR2QsQ0FBQyxDQUFDSyxHQUFGLENBQU1VLEdBQU4sRUFBTDs7QUFBa0JmLGFBQUMsQ0FBQ0ksSUFBRixDQUFPVyxHQUFQOztBQUFjOztBQUN4QztBQUNJLGdCQUFJLEVBQUVaLENBQUMsR0FBR0gsQ0FBQyxDQUFDSSxJQUFOLEVBQVlELENBQUMsR0FBR0EsQ0FBQyxDQUFDL0IsTUFBRixHQUFXLENBQVgsSUFBZ0IrQixDQUFDLENBQUNBLENBQUMsQ0FBQy9CLE1BQUYsR0FBVyxDQUFaLENBQW5DLE1BQXVEMEMsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQWhGLENBQUosRUFBd0Y7QUFBRWQsZUFBQyxHQUFHLENBQUo7QUFBTztBQUFXOztBQUM1RyxnQkFBSWMsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsS0FBZ0IsQ0FBQ1gsQ0FBRCxJQUFPVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFYLENBQUMsQ0FBQyxDQUFELENBQVQsSUFBZ0JXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUVgsQ0FBQyxDQUFDLENBQUQsQ0FBaEQsQ0FBSixFQUEyRDtBQUFFSCxlQUFDLENBQUNDLEtBQUYsR0FBVWEsRUFBRSxDQUFDLENBQUQsQ0FBWjtBQUFpQjtBQUFROztBQUN0RixnQkFBSUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZWQsQ0FBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQTlCLEVBQW1DO0FBQUVILGVBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUFYO0FBQWdCQSxlQUFDLEdBQUdXLEVBQUo7QUFBUTtBQUFROztBQUNyRSxnQkFBSVgsQ0FBQyxJQUFJSCxDQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBcEIsRUFBeUI7QUFBRUgsZUFBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQVg7O0FBQWdCSCxlQUFDLENBQUNLLEdBQUYsQ0FBTVcsSUFBTixDQUFXRixFQUFYOztBQUFnQjtBQUFROztBQUNuRSxnQkFBSVgsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVSCxDQUFDLENBQUNLLEdBQUYsQ0FBTVUsR0FBTjs7QUFDVmYsYUFBQyxDQUFDSSxJQUFGLENBQU9XLEdBQVA7O0FBQWM7QUFYdEI7O0FBYUFELFVBQUUsR0FBR2YsSUFBSSxDQUFDeEMsSUFBTCxDQUFVcUIsT0FBVixFQUFtQm9CLENBQW5CLENBQUw7QUFDSCxPQWpCUyxDQWlCUixPQUFPUixDQUFQLEVBQVU7QUFBRXNCLFVBQUUsR0FBRyxDQUFDLENBQUQsRUFBSXRCLENBQUosQ0FBTDtBQUFhZSxTQUFDLEdBQUcsQ0FBSjtBQUFRLE9BakJ6QixTQWlCa0M7QUFBRUQsU0FBQyxHQUFHSCxDQUFDLEdBQUcsQ0FBUjtBQUFZO0FBakIxRDs7QUFrQkEsUUFBSVcsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVosRUFBZSxNQUFNQSxFQUFFLENBQUMsQ0FBRCxDQUFSO0FBQWEsV0FBTztBQUFFN0IsV0FBSyxFQUFFNkIsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRQSxFQUFFLENBQUMsQ0FBRCxDQUFWLEdBQWdCLEtBQUssQ0FBOUI7QUFBaUNuQixVQUFJLEVBQUU7QUFBdkMsS0FBUDtBQUMvQjtBQUNKLENBMUJEOztBQTJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlzQixNQUFNLEdBQUdDLHFEQUFTLENBQUMsUUFBRCxDQUF0Qjs7QUFDQSxJQUFJb0IsVUFBVTtBQUFHO0FBQWUsVUFBVWxCLE1BQVYsRUFBa0I7QUFDOUN4RSxXQUFTLENBQUMwRixVQUFELEVBQWFsQixNQUFiLENBQVQ7O0FBQ0EsV0FBU2tCLFVBQVQsR0FBc0I7QUFDbEIsUUFBSWpCLEtBQUssR0FBR0QsTUFBTSxLQUFLLElBQVgsSUFBbUJBLE1BQU0sQ0FBQ3ZCLEtBQVAsQ0FBYSxJQUFiLEVBQW1CMUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBaEU7O0FBQ0FrRCxTQUFLLENBQUNvQixNQUFOLEdBQWUsRUFBZjtBQUNBLFdBQU9wQixLQUFQO0FBQ0g7O0FBQ0RpQixZQUFVLENBQUNqRixTQUFYLENBQXFCbUUsT0FBckIsR0FBK0IsWUFBWTtBQUN2QyxXQUFPN0MsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT21CLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVTJCLEVBQVYsRUFBYztBQUNuQyxnQkFBUUEsRUFBRSxDQUFDeEIsS0FBWDtBQUNJLGVBQUssQ0FBTDtBQUNJLGdCQUFJLEVBQUUsS0FBS3lDLE1BQUwsQ0FBWXRFLE1BQVosSUFBc0IsQ0FBeEIsQ0FBSixFQUFnQyxPQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsQ0FBZCxDQUFQO0FBQ2hDLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsS0FBS3VFLFNBQUwsRUFBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJbEIsY0FBRSxDQUFDdkIsSUFBSDs7QUFDQXVCLGNBQUUsQ0FBQ3hCLEtBQUgsR0FBVyxDQUFYOztBQUNKLGVBQUssQ0FBTDtBQUFRLG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7QUFQWjtBQVNILE9BVmlCLENBQWxCO0FBV0gsS0FaZSxDQUFoQjtBQWFILEdBZEQ7O0FBZUFqRCxRQUFNLENBQUMwQixjQUFQLENBQXNCNEQsVUFBVSxDQUFDakYsU0FBakMsRUFBNEMsWUFBNUMsRUFBMEQ7QUFDdER1RixPQUFHLEVBQUUsZUFBWTtBQUNiLGFBQU8sS0FBS0MsTUFBTCxDQUFZQyxLQUFaLENBQWtCQyxJQUFsQixDQUF1QkMsSUFBOUI7QUFDSCxLQUhxRDtBQUl0REMsY0FBVSxFQUFFLEtBSjBDO0FBS3REQyxnQkFBWSxFQUFFO0FBTHdDLEdBQTFEOztBQU9BWixZQUFVLENBQUNqRixTQUFYLENBQXFCOEYsU0FBckIsR0FBaUMsVUFBVTVCLEtBQVYsRUFBaUI7QUFDOUMsU0FBS1EsV0FBTCxDQUFpQixLQUFqQjtBQUNBLFNBQUtDLE9BQUwsQ0FBYVQsS0FBYjtBQUNBLFNBQUtVLGVBQUwsQ0FBcUIsSUFBckI7QUFDSCxHQUpEOztBQUtBSyxZQUFVLENBQUNqRixTQUFYLENBQXFCK0Ysa0JBQXJCLEdBQTBDLFVBQVU3QixLQUFWLEVBQWlCO0FBQ3ZELFdBQU81QyxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxhQUFPbUIsV0FBVyxDQUFDLElBQUQsRUFBTyxVQUFVMkIsRUFBVixFQUFjO0FBQ25DLGdCQUFRQSxFQUFFLENBQUN4QixLQUFYO0FBQ0ksZUFBSyxDQUFMO0FBQVEsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBY29ELHNEQUFNLENBQUMsaUNBQUQsRUFBb0MsSUFBcEMsQ0FBcEIsQ0FBUDs7QUFDUixlQUFLLENBQUw7QUFDSSxnQkFBSSxDQUFFNUIsRUFBRSxDQUFDdkIsSUFBSCxFQUFOLEVBQWtCO0FBQ2QscUJBQU8sQ0FBQztBQUFFO0FBQUgsZUFBUDtBQUNIOztBQUNELGlCQUFLb0QsV0FBTCxDQUFpQi9CLEtBQWpCO0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsYUFBUDtBQVBSO0FBU0gsT0FWaUIsQ0FBbEI7QUFXSCxLQVplLENBQWhCO0FBYUgsR0FkRDs7QUFlQWUsWUFBVSxDQUFDakYsU0FBWCxDQUFxQnNGLFNBQXJCLEdBQWlDLFlBQVk7QUFDekMsV0FBT2hFLFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixZQUFZO0FBQy9DLGFBQU9tQixXQUFXLENBQUMsSUFBRCxFQUFPLFVBQVUyQixFQUFWLEVBQWM7QUFDbkMsYUFBSzhCLFVBQUw7QUFDQSxlQUFPLENBQUM7QUFBRTtBQUFILFNBQVA7QUFDSCxPQUhpQixDQUFsQjtBQUlILEtBTGUsQ0FBaEI7QUFNSCxHQVBEOztBQVFBMUYsWUFBVSxDQUFDLENBQ1BvRCxNQUFNLENBQUNrQixLQURBLENBQUQsRUFFUEcsVUFBVSxDQUFDakYsU0FGSixFQUVlLE1BRmYsRUFFdUIsS0FBSyxDQUY1QixDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2tCLEtBREEsQ0FBRCxFQUVQRyxVQUFVLENBQUNqRixTQUZKLEVBRWUsUUFGZixFQUV5QixLQUFLLENBRjlCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDa0IsS0FEQSxDQUFELEVBRVBHLFVBQVUsQ0FBQ2pGLFNBRkosRUFFZSxRQUZmLEVBRXlCLEtBQUssQ0FGOUIsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1BvRCxNQUFNLENBQUNrQixLQURBLENBQUQsRUFFUEcsVUFBVSxDQUFDakYsU0FGSixFQUVlLFdBRmYsRUFFNEIsS0FBSyxDQUZqQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2tCLEtBREEsQ0FBRCxFQUVQRyxVQUFVLENBQUNqRixTQUZKLEVBRWUsZ0JBRmYsRUFFaUMsS0FBSyxDQUZ0QyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2tCLEtBREEsQ0FBRCxFQUVQRyxVQUFVLENBQUNqRixTQUZKLEVBRWUsWUFGZixFQUU2QixLQUFLLENBRmxDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDaUIsTUFEQSxDQUFELEVBRVBJLFVBQVUsQ0FBQ2pGLFNBRkosRUFFZSxZQUZmLEVBRTZCLEtBQUssQ0FGbEMsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1BvRCxNQUFNLENBQUNpQixNQURBLENBQUQsRUFFUEksVUFBVSxDQUFDakYsU0FGSixFQUVlLGFBRmYsRUFFOEIsS0FBSyxDQUZuQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2lCLE1BREEsQ0FBRCxFQUVQSSxVQUFVLENBQUNqRixTQUZKLEVBRWUsaUJBRmYsRUFFa0MsS0FBSyxDQUZ2QyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2lCLE1BREEsQ0FBRCxFQUVQSSxVQUFVLENBQUNqRixTQUZKLEVBRWUsYUFGZixFQUU4QixLQUFLLENBRm5DLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDaUIsTUFEQSxDQUFELEVBRVBJLFVBQVUsQ0FBQ2pGLFNBRkosRUFFZSxTQUZmLEVBRTBCLEtBQUssQ0FGL0IsQ0FBVjs7QUFHQWlGLFlBQVUsR0FBR3pFLFVBQVUsQ0FBQyxDQUNwQnVFLGlFQUFTLENBQUM7QUFDTkMsY0FBVSxFQUFFO0FBQ1JFLGlCQUFXLEVBQUVBLHFEQUFXQTtBQURoQjtBQUROLEdBQUQsQ0FEVyxDQUFELEVBTXBCRCxVQU5vQixDQUF2QjtBQU9BLFNBQU9BLFVBQVA7QUFDSCxDQWxHK0IsQ0FrRzlCRSx1REFsRzhCLENBQWhDOztBQW1HQSxpRUFBZUYsVUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaktBLElBQUkxRixTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE2QixZQUFZO0FBQ3JELE1BQUlDLGNBQWEsR0FBRyx1QkFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ2hDRixrQkFBYSxHQUFHRyxNQUFNLENBQUNDLGNBQVAsSUFDWDtBQUFFQyxlQUFTLEVBQUU7QUFBYixpQkFBNkJDLEtBQTdCLElBQXNDLFVBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFRCxPQUFDLENBQUNJLFNBQUYsR0FBY0gsQ0FBZDtBQUFrQixLQUQvRCxJQUVaLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFLFdBQUssSUFBSUssQ0FBVCxJQUFjTCxDQUFkO0FBQWlCLFlBQUlDLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUixDQUFyQyxFQUF3Q0ssQ0FBeEMsQ0FBSixFQUFnRE4sQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBT0wsQ0FBQyxDQUFDSyxDQUFELENBQVI7QUFBakU7QUFBK0UsS0FGckc7O0FBR0EsV0FBT1AsY0FBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBcEI7QUFDSCxHQUxEOztBQU1BLFNBQU8sVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ25CLFFBQUksT0FBT0EsQ0FBUCxLQUFhLFVBQWIsSUFBMkJBLENBQUMsS0FBSyxJQUFyQyxFQUNJLE1BQU0sSUFBSVMsU0FBSixDQUFjLHlCQUF5QkMsTUFBTSxDQUFDVixDQUFELENBQS9CLEdBQXFDLCtCQUFuRCxDQUFOOztBQUNKRixrQkFBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBYjs7QUFDQSxhQUFTVyxFQUFULEdBQWM7QUFBRSxXQUFLQyxXQUFMLEdBQW1CYixDQUFuQjtBQUF1Qjs7QUFDdkNBLEtBQUMsQ0FBQ08sU0FBRixHQUFjTixDQUFDLEtBQUssSUFBTixHQUFhQyxNQUFNLENBQUNZLE1BQVAsQ0FBY2IsQ0FBZCxDQUFiLElBQWlDVyxFQUFFLENBQUNMLFNBQUgsR0FBZU4sQ0FBQyxDQUFDTSxTQUFqQixFQUE0QixJQUFJSyxFQUFKLEVBQTdELENBQWQ7QUFDSCxHQU5EO0FBT0gsQ0FkMkMsRUFBNUM7O0FBZUEsSUFBSUcsVUFBVSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFVBQWQsSUFBNkIsVUFBVUMsVUFBVixFQUFzQkMsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DQyxJQUFuQyxFQUF5QztBQUNuRixNQUFJQyxDQUFDLEdBQUdDLFNBQVMsQ0FBQ0MsTUFBbEI7QUFBQSxNQUEwQkMsQ0FBQyxHQUFHSCxDQUFDLEdBQUcsQ0FBSixHQUFRSCxNQUFSLEdBQWlCRSxJQUFJLEtBQUssSUFBVCxHQUFnQkEsSUFBSSxHQUFHakIsTUFBTSxDQUFDc0Isd0JBQVAsQ0FBZ0NQLE1BQWhDLEVBQXdDQyxHQUF4QyxDQUF2QixHQUFzRUMsSUFBckg7QUFBQSxNQUEySG5CLENBQTNIO0FBQ0EsTUFBSSxRQUFPeUIsT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUFuQixJQUErQixPQUFPQSxPQUFPLENBQUNDLFFBQWYsS0FBNEIsVUFBL0QsRUFBMkVILENBQUMsR0FBR0UsT0FBTyxDQUFDQyxRQUFSLENBQWlCVixVQUFqQixFQUE2QkMsTUFBN0IsRUFBcUNDLEdBQXJDLEVBQTBDQyxJQUExQyxDQUFKLENBQTNFLEtBQ0ssS0FBSyxJQUFJUSxDQUFDLEdBQUdYLFVBQVUsQ0FBQ00sTUFBWCxHQUFvQixDQUFqQyxFQUFvQ0ssQ0FBQyxJQUFJLENBQXpDLEVBQTRDQSxDQUFDLEVBQTdDO0FBQWlELFFBQUkzQixDQUFDLEdBQUdnQixVQUFVLENBQUNXLENBQUQsQ0FBbEIsRUFBdUJKLENBQUMsR0FBRyxDQUFDSCxDQUFDLEdBQUcsQ0FBSixHQUFRcEIsQ0FBQyxDQUFDdUIsQ0FBRCxDQUFULEdBQWVILENBQUMsR0FBRyxDQUFKLEdBQVFwQixDQUFDLENBQUNpQixNQUFELEVBQVNDLEdBQVQsRUFBY0ssQ0FBZCxDQUFULEdBQTRCdkIsQ0FBQyxDQUFDaUIsTUFBRCxFQUFTQyxHQUFULENBQTdDLEtBQStESyxDQUFuRTtBQUF4RTtBQUNMLFNBQU9ILENBQUMsR0FBRyxDQUFKLElBQVNHLENBQVQsSUFBY3JCLE1BQU0sQ0FBQzBCLGNBQVAsQ0FBc0JYLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0ssQ0FBbkMsQ0FBZCxFQUFxREEsQ0FBNUQ7QUFDSCxDQUxEOztBQU1BO0FBQ0E7QUFDQSxJQUFJNEMsTUFBTSxHQUFHQyxxREFBUyxDQUFDLFFBQUQsQ0FBdEI7O0FBQ0EsSUFBSXFCLFdBQVc7QUFBRztBQUFlLFVBQVVuQixNQUFWLEVBQWtCO0FBQy9DeEUsV0FBUyxDQUFDMkYsV0FBRCxFQUFjbkIsTUFBZCxDQUFUOztBQUNBLFdBQVNtQixXQUFULEdBQXVCO0FBQ25CLFdBQU9uQixNQUFNLEtBQUssSUFBWCxJQUFtQkEsTUFBTSxDQUFDdkIsS0FBUCxDQUFhLElBQWIsRUFBbUIxQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIOztBQUNEb0UsYUFBVyxDQUFDbEYsU0FBWixDQUFzQm1HLFFBQXRCLEdBQWlDLFlBQVk7QUFDekMsUUFBSSxLQUFLbEMsVUFBVCxFQUFxQjtBQUNqQixXQUFLUSxRQUFMLENBQWMsS0FBSzJCLElBQW5CO0FBQ0gsS0FGRCxNQUdLO0FBQ0QsV0FBS04sU0FBTCxDQUFlLEtBQUtNLElBQXBCO0FBQ0g7QUFDSixHQVBEOztBQVFBbEIsYUFBVyxDQUFDbEYsU0FBWixDQUFzQnFHLFdBQXRCLEdBQW9DLFlBQVk7QUFDNUMsU0FBS3pCLGVBQUwsQ0FBcUIsS0FBckI7QUFDSCxHQUZEOztBQUdBcEUsWUFBVSxDQUFDLENBQ1A4Riw0REFBSSxFQURHLENBQUQsRUFFUHBCLFdBQVcsQ0FBQ2xGLFNBRkwsRUFFZ0IsTUFGaEIsRUFFd0IsS0FBSyxDQUY3QixDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUDhGLDREQUFJLEVBREcsQ0FBRCxFQUVQcEIsV0FBVyxDQUFDbEYsU0FGTCxFQUVnQixPQUZoQixFQUV5QixLQUFLLENBRjlCLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQOEYsNERBQUksRUFERyxDQUFELEVBRVBwQixXQUFXLENBQUNsRixTQUZMLEVBRWdCLFdBRmhCLEVBRTZCLEtBQUssQ0FGbEMsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1BvRCxNQUFNLENBQUNpQixNQURBLENBQUQsRUFFUEssV0FBVyxDQUFDbEYsU0FGTCxFQUVnQixVQUZoQixFQUU0QixLQUFLLENBRmpDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDaUIsTUFEQSxDQUFELEVBRVBLLFdBQVcsQ0FBQ2xGLFNBRkwsRUFFZ0IsV0FGaEIsRUFFNkIsS0FBSyxDQUZsQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUG9ELE1BQU0sQ0FBQ2lCLE1BREEsQ0FBRCxFQUVQSyxXQUFXLENBQUNsRixTQUZMLEVBRWdCLGlCQUZoQixFQUVtQyxLQUFLLENBRnhDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQb0QsTUFBTSxDQUFDa0IsS0FEQSxDQUFELEVBRVBJLFdBQVcsQ0FBQ2xGLFNBRkwsRUFFZ0IsZ0JBRmhCLEVBRWtDLEtBQUssQ0FGdkMsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1BvRCxNQUFNLENBQUNrQixLQURBLENBQUQsRUFFUEksV0FBVyxDQUFDbEYsU0FGTCxFQUVnQixZQUZoQixFQUU4QixLQUFLLENBRm5DLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQcUUsOENBRE8sQ0FBRCxFQUVQSyxXQUFXLENBQUNsRixTQUZMLEVBRWdCLGtCQUZoQixFQUVvQyxLQUFLLENBRnpDLENBQVY7O0FBR0FrRixhQUFXLEdBQUcxRSxVQUFVLENBQUMsQ0FDckJ1RSxpRUFBUyxDQUFDLEVBQUQsQ0FEWSxDQUFELEVBRXJCRyxXQUZxQixDQUF4QjtBQUdBLFNBQU9BLFdBQVA7QUFDSCxDQS9DZ0MsQ0ErQy9CQyx1REEvQytCLENBQWpDOztBQWdEQSxpRUFBZUQsV0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RThGO0FBQ3BDO0FBQ0w7OztBQUdyRDtBQUNBLENBQW1HO0FBQ25HLGdCQUFnQixvR0FBVTtBQUMxQixFQUFFLHlFQUFNO0FBQ1IsRUFBRSx1RkFBTTtBQUNSLEVBQUUsZ0dBQWU7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxJQUFJLEtBQVUsRUFBRSxZQWlCZjtBQUNEO0FBQ0EsaUVBQWUsaUI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RDK0Y7QUFDaEQ7QUFDTDs7O0FBR3pEO0FBQ0EsQ0FBc0c7QUFDdEcsZ0JBQWdCLG9HQUFVO0FBQzFCLEVBQUUsNkVBQU07QUFDUixFQUFFLHVHQUFNO0FBQ1IsRUFBRSxnSEFBZTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLElBQUksS0FBVSxFQUFFLFlBaUJmO0FBQ0Q7QUFDQSxpRUFBZSxpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdENvRjtBQUNwQztBQUNMOzs7QUFHMUQ7QUFDQSxDQUFzRztBQUN0RyxnQkFBZ0Isb0dBQVU7QUFDMUIsRUFBRSw4RUFBTTtBQUNSLEVBQUUsNEZBQU07QUFDUixFQUFFLHFHQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsSUFBSSxLQUFVLEVBQUUsWUFpQmY7QUFDRDtBQUNBLGlFQUFlLGlCOzs7Ozs7Ozs7Ozs7Ozs7O0FDdEMwUixDQUFDLGlFQUFlLG1RQUFHLEVBQUMsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ0FQLENBQUMsaUVBQWUsdVFBQUcsRUFBQyxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDQW5CLENBQUMsaUVBQWUsd1FBQUcsRUFBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTNVO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssU0FBUyx5QkFBeUIsRUFBRTtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLHNCQUFzQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsaUNBQWlDO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlCQUF5QjtBQUNqRCxrQkFBa0IseUNBQXlDO0FBQzNELGVBQWU7QUFDZixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHlDQUF5QztBQUM1RCxvQ0FBb0MsOEJBQThCO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixTQUFTLGFBQWEsRUFBRTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxzQkFBc0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxzQkFBc0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1TUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUyxVQUFVLEVBQUU7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVMsVUFBVSxFQUFFO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJqcy9yZXNvdXJjZXNfYXNzZXRzX3Z1ZV92aWV3c19wcmljZXNfUHJpY2VzX3Z1ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbInZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgKGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgICAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIH07XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2xhc3MgZXh0ZW5kcyB2YWx1ZSBcIiArIFN0cmluZyhiKSArIFwiIGlzIG5vdCBhIGNvbnN0cnVjdG9yIG9yIG51bGxcIik7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgICAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbiAgICB9O1xyXG59KSgpO1xyXG52YXIgX19kZWNvcmF0ZSA9ICh0aGlzICYmIHRoaXMuX19kZWNvcmF0ZSkgfHwgZnVuY3Rpb24gKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59O1xyXG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xyXG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcclxuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XHJcbiAgICAgICAgd2hpbGUgKF8pIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcclxuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cclxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcclxuICAgIH1cclxufTtcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBWdWUgfSBmcm9tICd2dWUtcHJvcGVydHktZGVjb3JhdG9yJztcclxuaW1wb3J0IHsgQWN0aW9uLCBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IFByaWNlc0xpc3QgZnJvbSAnLi9jb21wb25lbnRzL1ByaWNlc0xpc3QudnVlJztcclxuaW1wb3J0IFByaWNlc01vZGFsIGZyb20gJy4vY29tcG9uZW50cy9QcmljZXNNb2RhbC52dWUnO1xyXG52YXIgcFN0b3JlID0gbmFtZXNwYWNlKCdwcmljZXMnKTtcclxudmFyIFByaWNlcyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhQcmljZXMsIF9zdXBlcik7XHJcbiAgICBmdW5jdGlvbiBQcmljZXMoKSB7XHJcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XHJcbiAgICAgICAgX3RoaXMuaXNNb2RhbEFkZCA9IHRydWU7XHJcbiAgICAgICAgX3RoaXMucHJpY2UgPSB7fTtcclxuICAgICAgICByZXR1cm4gX3RoaXM7XHJcbiAgICB9XHJcbiAgICBQcmljZXMucHJvdG90eXBlLmNyZWF0ZWQgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldEJhY2tVcmwoJy8nKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0TWVudShbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICdhZGRfcHJpY2UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAncHJpY2VzLmFkZF9wcmljZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZXI6IHRoaXMuYWRkUHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBQcmljZXMucHJvdG90eXBlLmFkZFByaWNlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuc2V0TW9kYWxBZGQodHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5zZXRGb3JtKHRoaXMucHJpY2UpO1xyXG4gICAgICAgIHRoaXMuc2V0TW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gICAgfTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgUHJpY2VzLnByb3RvdHlwZSwgXCJzZXRCYWNrVXJsXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBBY3Rpb25cclxuICAgIF0sIFByaWNlcy5wcm90b3R5cGUsIFwic2V0TWVudVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXMucHJvdG90eXBlLCBcImlzTG9hZGluZ1wiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXMucHJvdG90eXBlLCBcImZvcm1cIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHBTdG9yZS5TdGF0ZVxyXG4gICAgXSwgUHJpY2VzLnByb3RvdHlwZSwgXCJpc01vZGFsVmlzaWJsZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLkFjdGlvblxyXG4gICAgXSwgUHJpY2VzLnByb3RvdHlwZSwgXCJzZXRNb2RhbFZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHBTdG9yZS5BY3Rpb25cclxuICAgIF0sIFByaWNlcy5wcm90b3R5cGUsIFwic2V0TW9kYWxBZGRcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHBTdG9yZS5BY3Rpb25cclxuICAgIF0sIFByaWNlcy5wcm90b3R5cGUsIFwic2V0Rm9ybVwiLCB2b2lkIDApO1xyXG4gICAgUHJpY2VzID0gX19kZWNvcmF0ZShbXHJcbiAgICAgICAgQ29tcG9uZW50KHtcclxuICAgICAgICAgICAgY29tcG9uZW50czoge1xyXG4gICAgICAgICAgICAgICAgUHJpY2VzTGlzdDogUHJpY2VzTGlzdCxcclxuICAgICAgICAgICAgICAgIFByaWNlc01vZGFsOiBQcmljZXNNb2RhbCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgXSwgUHJpY2VzKTtcclxuICAgIHJldHVybiBQcmljZXM7XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IFByaWNlcztcclxuIiwidmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2RlY29yYXRlID0gKHRoaXMgJiYgdGhpcy5fX2RlY29yYXRlKSB8fCBmdW5jdGlvbiAoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn07XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IGRpYWxvZyBmcm9tICdAL3V0aWxzL2RpYWxvZyc7XHJcbmltcG9ydCBQcmljZXNNb2RhbCBmcm9tICcuL1ByaWNlc01vZGFsLnZ1ZSc7XHJcbnZhciBwU3RvcmUgPSBuYW1lc3BhY2UoJ3ByaWNlcycpO1xyXG52YXIgUHJpY2VzTGlzdCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhQcmljZXNMaXN0LCBfc3VwZXIpO1xyXG4gICAgZnVuY3Rpb24gUHJpY2VzTGlzdCgpIHtcclxuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIgIT09IG51bGwgJiYgX3N1cGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgfHwgdGhpcztcclxuICAgICAgICBfdGhpcy5zZWFyY2ggPSAnJztcclxuICAgICAgICByZXR1cm4gX3RoaXM7XHJcbiAgICB9XHJcbiAgICBQcmljZXNMaXN0LnByb3RvdHlwZS5jcmVhdGVkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEodGhpcy5wcmljZXMubGVuZ3RoID09IDApKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRQcmljZXMoKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gMjtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6IHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFByaWNlc0xpc3QucHJvdG90eXBlLCBcImFjdHVhbFVzZXJcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy4kc3RvcmUuc3RhdGUuYXV0aC51c2VyO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIFByaWNlc0xpc3QucHJvdG90eXBlLmVkaXRQcmljZSA9IGZ1bmN0aW9uIChwcmljZSkge1xyXG4gICAgICAgIHRoaXMuc2V0TW9kYWxBZGQoZmFsc2UpO1xyXG4gICAgICAgIHRoaXMuc2V0Rm9ybShwcmljZSk7XHJcbiAgICAgICAgdGhpcy5zZXRNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICB9O1xyXG4gICAgUHJpY2VzTGlzdC5wcm90b3R5cGUuZGVsZXRlUHJpY2VDb25maXJtID0gZnVuY3Rpb24gKHByaWNlKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBkaWFsb2coJ2Zyb250LmRlbGV0ZV9wcmljZV9jb25maXJtYXRpb24nLCB0cnVlKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIShfYS5zZW50KCkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWxldGVQcmljZShwcmljZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgUHJpY2VzTGlzdC5wcm90b3R5cGUuZ2V0UHJpY2VzID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkUHJpY2VzKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHBTdG9yZS5TdGF0ZVxyXG4gICAgXSwgUHJpY2VzTGlzdC5wcm90b3R5cGUsIFwiZm9ybVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJwcmljZXNcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHBTdG9yZS5TdGF0ZVxyXG4gICAgXSwgUHJpY2VzTGlzdC5wcm90b3R5cGUsIFwiZmllbGRzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuU3RhdGVcclxuICAgIF0sIFByaWNlc0xpc3QucHJvdG90eXBlLCBcImlzTG9hZGluZ1wiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJpc01vZGFsVmlzaWJsZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJpc01vZGFsQWRkXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJsb2FkUHJpY2VzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJkZWxldGVQcmljZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLkFjdGlvblxyXG4gICAgXSwgUHJpY2VzTGlzdC5wcm90b3R5cGUsIFwic2V0TW9kYWxWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBQcmljZXNMaXN0LnByb3RvdHlwZSwgXCJzZXRNb2RhbEFkZFwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLkFjdGlvblxyXG4gICAgXSwgUHJpY2VzTGlzdC5wcm90b3R5cGUsIFwic2V0Rm9ybVwiLCB2b2lkIDApO1xyXG4gICAgUHJpY2VzTGlzdCA9IF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIENvbXBvbmVudCh7XHJcbiAgICAgICAgICAgIGNvbXBvbmVudHM6IHtcclxuICAgICAgICAgICAgICAgIFByaWNlc01vZGFsOiBQcmljZXNNb2RhbCxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICBdLCBQcmljZXNMaXN0KTtcclxuICAgIHJldHVybiBQcmljZXNMaXN0O1xyXG59KFZ1ZSkpO1xyXG5leHBvcnQgZGVmYXVsdCBQcmljZXNMaXN0O1xyXG4iLCJ2YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IChmdW5jdGlvbiAoKSB7XHJcbiAgICB2YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChiLCBwKSkgZFtwXSA9IGJbcF07IH07XHJcbiAgICAgICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBiICE9PSBcImZ1bmN0aW9uXCIgJiYgYiAhPT0gbnVsbClcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNsYXNzIGV4dGVuZHMgdmFsdWUgXCIgKyBTdHJpbmcoYikgKyBcIiBpcyBub3QgYSBjb25zdHJ1Y3RvciBvciBudWxsXCIpO1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICAgICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICAgICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xyXG4gICAgfTtcclxufSkoKTtcclxudmFyIF9fZGVjb3JhdGUgPSAodGhpcyAmJiB0aGlzLl9fZGVjb3JhdGUpIHx8IGZ1bmN0aW9uIChkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufTtcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBQcm9wLCBWdWUgfSBmcm9tICd2dWUtcHJvcGVydHktZGVjb3JhdG9yJztcclxuaW1wb3J0IHsgQWN0aW9uLCBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxudmFyIHBTdG9yZSA9IG5hbWVzcGFjZSgncHJpY2VzJyk7XHJcbnZhciBQcmljZXNNb2RhbCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhQcmljZXNNb2RhbCwgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIFByaWNlc01vZGFsKCkge1xyXG4gICAgICAgIHJldHVybiBfc3VwZXIgIT09IG51bGwgJiYgX3N1cGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgfHwgdGhpcztcclxuICAgIH1cclxuICAgIFByaWNlc01vZGFsLnByb3RvdHlwZS5oYW5kbGVPayA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5pc01vZGFsQWRkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWRkUHJpY2UodGhpcy5mb3JtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZWRpdFByaWNlKHRoaXMuZm9ybSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIFByaWNlc01vZGFsLnByb3RvdHlwZS5oYW5kbGVDbG9zZSA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLnNldE1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICB9O1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgUHJvcCgpXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwiZm9ybVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgUHJvcCgpXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwiaXNBZGRcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIFByb3AoKVxyXG4gICAgXSwgUHJpY2VzTW9kYWwucHJvdG90eXBlLCBcImlzVmlzaWJsZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLkFjdGlvblxyXG4gICAgXSwgUHJpY2VzTW9kYWwucHJvdG90eXBlLCBcImFkZFByaWNlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwiZWRpdFByaWNlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwic2V0TW9kYWxWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuU3RhdGVcclxuICAgIF0sIFByaWNlc01vZGFsLnByb3RvdHlwZSwgXCJpc01vZGFsTG9hZGluZ1wiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwiaXNNb2RhbEFkZFwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgQWN0aW9uXHJcbiAgICBdLCBQcmljZXNNb2RhbC5wcm90b3R5cGUsIFwic2V0RGlhbG9nTWVzc2FnZVwiLCB2b2lkIDApO1xyXG4gICAgUHJpY2VzTW9kYWwgPSBfX2RlY29yYXRlKFtcclxuICAgICAgICBDb21wb25lbnQoe30pXHJcbiAgICBdLCBQcmljZXNNb2RhbCk7XHJcbiAgICByZXR1cm4gUHJpY2VzTW9kYWw7XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IFByaWNlc01vZGFsO1xyXG4iLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1ByaWNlcy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MjQyNTE2ZGUmbGFuZz1wdWcmXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vUHJpY2VzLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuZXhwb3J0ICogZnJvbSBcIi4vUHJpY2VzLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcY2FyZGVcXFxcUHJvamVjdHNcXFxcaW5hZ2F2ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCcyNDI1MTZkZScpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCcyNDI1MTZkZScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCcyNDI1MTZkZScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vUHJpY2VzLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yNDI1MTZkZSZsYW5nPXB1ZyZcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgYXBpLnJlcmVuZGVyKCcyNDI1MTZkZScsIHtcbiAgICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICAgIHN0YXRpY1JlbmRlckZuczogc3RhdGljUmVuZGVyRm5zXG4gICAgICB9KVxuICAgIH0pXG4gIH1cbn1cbmNvbXBvbmVudC5vcHRpb25zLl9fZmlsZSA9IFwicmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL1ByaWNlcy52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1ByaWNlc0xpc3QudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTIyNDUzZjJjJnNjb3BlZD10cnVlJmxhbmc9cHVnJlwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL1ByaWNlc0xpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiXG5leHBvcnQgKiBmcm9tIFwiLi9QcmljZXNMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIFwiMjI0NTNmMmNcIixcbiAgbnVsbFxuICBcbilcblxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgdmFyIGFwaSA9IHJlcXVpcmUoXCJDOlxcXFxVc2Vyc1xcXFxjYXJkZVxcXFxQcm9qZWN0c1xcXFxpbmFnYXZlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtaG90LXJlbG9hZC1hcGlcXFxcZGlzdFxcXFxpbmRleC5qc1wiKVxuICBhcGkuaW5zdGFsbChyZXF1aXJlKCd2dWUnKSlcbiAgaWYgKGFwaS5jb21wYXRpYmxlKSB7XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICAgIGlmICghYXBpLmlzUmVjb3JkZWQoJzIyNDUzZjJjJykpIHtcbiAgICAgIGFwaS5jcmVhdGVSZWNvcmQoJzIyNDUzZjJjJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfSBlbHNlIHtcbiAgICAgIGFwaS5yZWxvYWQoJzIyNDUzZjJjJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfVxuICAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9QcmljZXNMaXN0LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yMjQ1M2YyYyZzY29wZWQ9dHJ1ZSZsYW5nPXB1ZyZcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgYXBpLnJlcmVuZGVyKCcyMjQ1M2YyYycsIHtcbiAgICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICAgIHN0YXRpY1JlbmRlckZuczogc3RhdGljUmVuZGVyRm5zXG4gICAgICB9KVxuICAgIH0pXG4gIH1cbn1cbmNvbXBvbmVudC5vcHRpb25zLl9fZmlsZSA9IFwicmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvcHJpY2VzL2NvbXBvbmVudHMvUHJpY2VzTGlzdC52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1ByaWNlc01vZGFsLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD04YzhjY2RkZSZsYW5nPXB1ZyZcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9QcmljZXNNb2RhbC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcbmV4cG9ydCAqIGZyb20gXCIuL1ByaWNlc01vZGFsLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcY2FyZGVcXFxcUHJvamVjdHNcXFxcaW5hZ2F2ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCc4YzhjY2RkZScpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCc4YzhjY2RkZScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCc4YzhjY2RkZScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vUHJpY2VzTW9kYWwudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPThjOGNjZGRlJmxhbmc9cHVnJlwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICBhcGkucmVyZW5kZXIoJzhjOGNjZGRlJywge1xuICAgICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgICAgc3RhdGljUmVuZGVyRm5zOiBzdGF0aWNSZW5kZXJGbnNcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuY29tcG9uZW50Lm9wdGlvbnMuX19maWxlID0gXCJyZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy9wcmljZXMvY29tcG9uZW50cy9QcmljZXNNb2RhbC52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgbW9kIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9QcmljZXMudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiOyBleHBvcnQgZGVmYXVsdCBtb2Q7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9QcmljZXMudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vUHJpY2VzTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1ByaWNlc0xpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vUHJpY2VzTW9kYWwudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiOyBleHBvcnQgZGVmYXVsdCBtb2Q7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9QcmljZXNNb2RhbC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCIiLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1jb250YWluZXJcIixcbiAgICB7IGF0dHJzOiB7IHRhZzogXCJtYWluXCIsIGZsdWlkOiBcIlwiIH0gfSxcbiAgICBbXG4gICAgICBfYyhcbiAgICAgICAgXCJiLXJvd1wiLFxuICAgICAgICBbXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcIm10LTNcIiB9LFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcImgyXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInByaWNlcy50aXRsZVwiKSkpXSksXG4gICAgICAgICAgICAgIF9jKFwiUHJpY2VzTGlzdFwiKVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApXG4gICAgICAgIF0sXG4gICAgICAgIDFcbiAgICAgICksXG4gICAgICBfYyhcInByaWNlcy1tb2RhbFwiLCB7XG4gICAgICAgIHJlZjogXCJwcmljZXNfbW9kYWxcIixcbiAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICBmb3JtOiBfdm0uZm9ybSxcbiAgICAgICAgICBcImlzLWFkZFwiOiBfdm0uaXNNb2RhbEFkZCxcbiAgICAgICAgICBcImlzLXZpc2libGVcIjogX3ZtLmlzTW9kYWxWaXNpYmxlXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiZGl2XCIsXG4gICAgW1xuICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICBzdGF0aWNDbGFzczogXCJtYi0yXCIsXG4gICAgICAgIHN0YXRpY1N0eWxlOiB7IHdpZHRoOiBcIjIzMHB4XCIsIGZsb2F0OiBcInJpZ2h0XCIgfSxcbiAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICBpZDogXCJzZWFyY2hcIixcbiAgICAgICAgICB0eXBlOiBcInNlYXJjaFwiLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiBfdm0uJHQoXCJzdHJpbmdzLnNlYXJjaFwiKVxuICAgICAgICB9LFxuICAgICAgICBtb2RlbDoge1xuICAgICAgICAgIHZhbHVlOiBfdm0uc2VhcmNoLFxuICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgIF92bS5zZWFyY2ggPSAkJHZcbiAgICAgICAgICB9LFxuICAgICAgICAgIGV4cHJlc3Npb246IFwic2VhcmNoXCJcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICBfYyhcbiAgICAgICAgXCJiLWJ1dHRvblwiLFxuICAgICAgICB7XG4gICAgICAgICAgc3RhdGljU3R5bGU6IHsgXCJtYXJnaW4tYm90dG9tXCI6IFwiNXB4XCIgfSxcbiAgICAgICAgICBhdHRyczogeyBzaXplOiBcInNtXCIsIHZhcmlhbnQ6IFwib3V0bGluZS1wcmltYXJ5XCIgfSxcbiAgICAgICAgICBvbjogeyBjbGljazogX3ZtLmdldFByaWNlcyB9XG4gICAgICAgIH0sXG4gICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MudXBkYXRlX3RhYmxlXCIpKSldXG4gICAgICApLFxuICAgICAgX2MoXCJiLXRhYmxlXCIsIHtcbiAgICAgICAgc3RhdGljQ2xhc3M6IFwiYnRhYmxlXCIsXG4gICAgICAgIHN0YXRpY1N0eWxlOiB7XG4gICAgICAgICAgXCJtYXgtaGVpZ2h0XCI6IFwiY2FsYygxMDB2aCAtIDE5MXB4KVwiLFxuICAgICAgICAgIFwiZm9udC1zaXplXCI6IFwiLjc1ZW1cIlxuICAgICAgICB9LFxuICAgICAgICBhdHRyczoge1xuICAgICAgICAgIHN0cmlwZWQ6IFwiXCIsXG4gICAgICAgICAgaG92ZXI6IFwiXCIsXG4gICAgICAgICAgcmVzcG9uc2l2ZTogXCJcIixcbiAgICAgICAgICBcInN0aWNreS1oZWFkZXJcIjogXCJcIixcbiAgICAgICAgICBcIm5vLWJvcmRlci1jb2xsYXBzZVwiOiBcIlwiLFxuICAgICAgICAgIGJvcmRlcmVkOiBcIlwiLFxuICAgICAgICAgIG91dGxpbmVkOiBcIlwiLFxuICAgICAgICAgIFwiaGVhZC12YXJpYW50XCI6IFwiZGFya1wiLFxuICAgICAgICAgIGJ1c3k6IF92bS5pc0xvYWRpbmcsXG4gICAgICAgICAgaXRlbXM6IF92bS5wcmljZXMsXG4gICAgICAgICAgZmllbGRzOiBfdm0uZmllbGRzLFxuICAgICAgICAgIFwic2VsZWN0LW1vZGVcIjogXCJzaW5nbGVcIixcbiAgICAgICAgICBzbWFsbDogXCJcIixcbiAgICAgICAgICBmaWx0ZXI6IF92bS5zZWFyY2hcbiAgICAgICAgfSxcbiAgICAgICAgc2NvcGVkU2xvdHM6IF92bS5fdShbXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcInRhYmxlLWJ1c3lcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcInRleHQtY2VudGVyIHRleHQtZGFuZ2VyXCIgfSxcbiAgICAgICAgICAgICAgICAgIFtfYyhcImItc3Bpbm5lclwiLCB7IHN0YXRpY0NsYXNzOiBcImFsaWduLW1pZGRsZVwiIH0pXSxcbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcm94eTogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQocHJpY2UpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW19jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJwcmljZXMucHJpY2VcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoeWVhcilcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbX2MoXCJzcGFuXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInByaWNlcy55ZWFyXCIpKSldKV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJoZWFkKGNyZWF0ZWRfYXQpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLmNyZWF0ZWRfYXRcIikpKV0pXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJoZWFkKHVwZGF0ZWRfYXQpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLnVwZGF0ZWRfYXRcIikpKV0pXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJoZWFkKGFjdGlvbnMpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW19jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLmFjdGlvbnNcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImNlbGwocHJpY2UpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFwic3BhblwiLCBbX3ZtLl92KFwiJFwiICsgX3ZtLl9zKGRhdGEuaXRlbS5wcmljZSkgKyBcIiAoTVhOKVwiKV0pXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJjZWxsKHllYXIpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW19jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhkYXRhLml0ZW0ueWVhcikpXSldXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBrZXk6IFwiY2VsbChjcmVhdGVkX2F0KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBfYyhcInNwYW5cIiwgW1xuICAgICAgICAgICAgICAgICAgX3ZtLl92KFxuICAgICAgICAgICAgICAgICAgICBfdm0uX3MoXG4gICAgICAgICAgICAgICAgICAgICAgX3ZtLl9mKFwibW9tZW50XCIpKGRhdGEuaXRlbS5jcmVhdGVkX2F0LCBcIkQsIE1NTU0gWVlZWVwiKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImNlbGwodXBkYXRlZF9hdClcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgX2MoXCJzcGFuXCIsIFtcbiAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgX3ZtLl9zKFxuICAgICAgICAgICAgICAgICAgICAgIF92bS5fZihcIm1vbWVudFwiKShkYXRhLml0ZW0udXBkYXRlZF9hdCwgXCJELCBNTU1NIFlZWVlcIilcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIF0pXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJjZWxsKGFjdGlvbnMpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgXCJiLWJ1dHRvbi1ncm91cFwiLFxuICAgICAgICAgICAgICAgICAgeyBhdHRyczogeyBzaXplOiBcInNtXCIgfSB9LFxuICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHsgXCJmb250LXNpemVcIjogXCIuOGVtXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBfdm0uJHQoXCJzdHJpbmdzLmVkaXRcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6IFwiaW5mb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpY2s6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdm0uZWRpdFByaWNlKGRhdGEuaXRlbSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy5lZGl0XCIpKSldXG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNTdHlsZTogeyBcImZvbnQtc2l6ZVwiOiBcIi44ZW1cIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IF92bS4kdChcInN0cmluZ3MuZGVsZXRlXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiBcImRhbmdlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpY2s6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdm0uZGVsZXRlUHJpY2VDb25maXJtKGRhdGEuaXRlbSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy5kZWxldGVcIikpKV1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJjZWxsKGluZGV4KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoZGF0YS5pbmRleCArIDEpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgXSlcbiAgICAgIH0pXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1tb2RhbFwiLFxuICAgIHtcbiAgICAgIGF0dHJzOiB7XG4gICAgICAgIFwiaGlkZS1oZWFkZXItY2xvc2VcIjogXCJcIixcbiAgICAgICAgdmlzaWJsZTogX3ZtLmlzVmlzaWJsZSxcbiAgICAgICAgc2l6ZTogXCJtZFwiLFxuICAgICAgICBzY3JvbGxhYmxlOiBcIlwiLFxuICAgICAgICBjZW50ZXJlZDogXCJcIixcbiAgICAgICAgXCJjYW5jZWwtdGl0bGVcIjogX3ZtLiR0KFwiYnV0dG9ucy5jYW5jZWxcIiksXG4gICAgICAgIFwib2stZGlzYWJsZWRcIjogX3ZtLmlzTW9kYWxMb2FkaW5nLFxuICAgICAgICBcIm9rLXRpdGxlXCI6IF92bS5pc01vZGFsTG9hZGluZ1xuICAgICAgICAgID8gX3ZtLiR0KFwiYnV0dG9ucy5zZW5kaW5nXCIpXG4gICAgICAgICAgOiBfdm0uaXNNb2RhbEFkZFxuICAgICAgICAgID8gX3ZtLiR0KFwiYnV0dG9ucy5hZGRcIilcbiAgICAgICAgICA6IF92bS4kdChcImJ1dHRvbnMudXBkYXRlXCIpLFxuICAgICAgICB0aXRsZTogX3ZtLmlzTW9kYWxBZGRcbiAgICAgICAgICA/IF92bS4kdChcInByaWNlcy5hZGRfcHJpY2VcIilcbiAgICAgICAgICA6IF92bS4kdChcInByaWNlcy5lZGl0X3ByaWNlXCIpXG4gICAgICB9LFxuICAgICAgb246IHtcbiAgICAgICAgaGlkZTogX3ZtLmhhbmRsZUNsb3NlLFxuICAgICAgICBvazogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgJGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgICByZXR1cm4gX3ZtLmhhbmRsZU9rKCRldmVudClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgW1xuICAgICAgX2MoXG4gICAgICAgIFwiYi1mb3JtXCIsXG4gICAgICAgIFtcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1yb3dcIixcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJiLWNvbFwiLFxuICAgICAgICAgICAgICAgIHsgYXR0cnM6IHsgbWQ6IFwiNlwiIH0gfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWZvcm0tZ3JvdXBcIixcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogX3ZtLiR0KFwicHJpY2VzLmZvcm1fcHJpY2VcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogX3ZtLiR0KFwicHJpY2VzLmZvcm1fcHJpY2VfZGVzY3JpcHRpb25cIiksXG4gICAgICAgICAgICAgICAgICAgICAgICBcImxhYmVsLWZvclwiOiBcInByaWNlXCJcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJwcmljZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIm51bWVyaWNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcDogXCIwLjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLmZvcm0ucHJpY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJwcmljZVwiLCAkJHYpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IFwiZm9ybS5wcmljZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICAgICAgeyBhdHRyczogeyBtZDogXCI2XCIgfSB9LFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICBcImItZm9ybS1ncm91cFwiLFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBfdm0uJHQoXCJwcmljZXMuZm9ybV95ZWFyXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IF92bS4kdChcInByaWNlcy5mb3JtX3llYXJfZGVzY3JpcHRpb25cIiksXG4gICAgICAgICAgICAgICAgICAgICAgICBcImxhYmVsLWZvclwiOiBcInllYXJcIlxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgIF9jKFwiYi1mb3JtLWlucHV0XCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBcInllYXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJudW1lcmljXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbjogXCIwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnllYXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJ5ZWFyXCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLnllYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApXG4gICAgICAgIF0sXG4gICAgICAgIDFcbiAgICAgIClcbiAgICBdLFxuICAgIDFcbiAgKVxufVxudmFyIHN0YXRpY1JlbmRlckZucyA9IFtdXG5yZW5kZXIuX3dpdGhTdHJpcHBlZCA9IHRydWVcblxuZXhwb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSJdLCJzb3VyY2VSb290IjoiIn0=