(self["webpackChunklaravel_vue_boilerplate"] = self["webpackChunklaravel_vue_boilerplate"] || []).push([["resources_assets_vue_views_users_Users_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var _utils_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/dialog */ "./resources/assets/vue/utils/dialog.ts");
/* harmony import */ var _components_UsersCard_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/UsersCard.vue */ "./resources/assets/vue/views/users/components/UsersCard.vue");
/* harmony import */ var _components_UsersModal_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/UsersModal.vue */ "./resources/assets/vue/views/users/components/UsersModal.vue");
/* harmony import */ var _views_users_components_AddProductToUser_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/views/users/components/AddProductToUser.vue */ "./resources/assets/vue/views/users/components/AddProductToUser.vue");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
    }

    return t;
  };

  return __assign.apply(this, arguments);
};

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};







var uStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('users');

var Users =
/** @class */
function (_super) {
  __extends(Users, _super);

  function Users() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentPage = 1;
    _this.form = {};
    _this.isModalAdd = true;
    return _this;
  }

  Users.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            this.setBackUrl('/');
            this.setMenu([{
              key: 'add_user',
              text: 'users.add_user',
              handler: this.addUser
            }]);
            this.currentPage = this.pagination.currentPage;
            if (!(this.users.length == 0)) return [3
            /*break*/
            , 2];
            return [4
            /*yield*/
            , this.getUsers(1)];

          case 1:
            _a.sent();

            _a.label = 2;

          case 2:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  Users.prototype.addUser = function () {
    this.isModalAdd = true;
    this.setModalVisible(true);
    this.form = {
      type_id: 2
    };
  };

  Users.prototype.editUser = function (user) {
    this.isModalAdd = false;
    this.setModalVisible(true);
    this.form = __assign({}, user);
  };

  Users.prototype.deleteUserConfirm = function (user) {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , (0,_utils_dialog__WEBPACK_IMPORTED_MODULE_2__.default)('front.delete_user_confirmation', true)];

          case 1:
            if (!_a.sent()) {
              return [2
              /*return*/
              ];
            }

            this.deleteUser(user);
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  Users.prototype.getUsers = function (page) {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadUsers({
          page: page
        });
        return [2
        /*return*/
        ];
      });
    });
  };

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Users.prototype, "setBackUrl", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Users.prototype, "setMenu", void 0);

  __decorate([uStore.State], Users.prototype, "users", void 0);

  __decorate([uStore.State], Users.prototype, "pagination", void 0);

  __decorate([uStore.State], Users.prototype, "isLoading", void 0);

  __decorate([uStore.State], Users.prototype, "isModalVisible", void 0);

  __decorate([uStore.State], Users.prototype, "isModalToAddProductVisible", void 0);

  __decorate([uStore.State], Users.prototype, "formProduct", void 0);

  __decorate([uStore.Action], Users.prototype, "deleteUser", void 0);

  __decorate([uStore.Action], Users.prototype, "loadUsers", void 0);

  __decorate([uStore.Action], Users.prototype, "setModalVisible", void 0);

  __decorate([uStore.Action], Users.prototype, "setFormProduct", void 0);

  __decorate([uStore.Action], Users.prototype, "setModalToAddProductToUserVisible", void 0);

  Users = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      AddProductToUser: _views_users_components_AddProductToUser_vue__WEBPACK_IMPORTED_MODULE_5__.default,
      UsersCard: _components_UsersCard_vue__WEBPACK_IMPORTED_MODULE_3__.default,
      UsersModal: _components_UsersModal_vue__WEBPACK_IMPORTED_MODULE_4__.default
    }
  })], Users);
  return Users;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Users);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_checkResponse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils/checkResponse */ "./resources/assets/vue/utils/checkResponse.ts");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};





var uStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('users');
var pStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('products');

var AddProductToUser =
/** @class */
function (_super) {
  __extends(AddProductToUser, _super);

  function AddProductToUser() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  AddProductToUser.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4
            /*yield*/
            , this.getProducts()];

          case 1:
            _a.sent();

            return [2
            /*return*/
            ];
        }
      });
    });
  };

  AddProductToUser.prototype.getProducts = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadProducts();
        return [2
        /*return*/
        ];
      });
    });
  };

  AddProductToUser.prototype.handleOk = function () {
    return __awaiter(this, void 0, void 0, function () {
      var response, checkErrors, _a;

      return __generator(this, function (_b) {
        switch (_b.label) {
          case 0:
            _b.trys.push([0, 2, 3, 4]);

            this.setLoading(true);
            return [4
            /*yield*/
            , axios__WEBPACK_IMPORTED_MODULE_2___default().post('user/add/product', this.form)];

          case 1:
            response = _b.sent();
            checkErrors = (0,_utils_checkResponse__WEBPACK_IMPORTED_MODULE_3__.default)(response);

            if (checkErrors) {
              this.$bvToast.toast('', {
                title: checkErrors.message,
                variant: 'danger',
                toaster: 'b-toaster-top-center',
                solid: true
              });
            } else {
              this.handleClose();
            }

            return [3
            /*break*/
            , 4];

          case 2:
            _a = _b.sent();
            this.$bvToast.toast('', {
              title: this.$t('errors.generic_error'),
              variant: 'danger',
              toaster: 'b-toaster-top-center',
              solid: true
            });
            return [3
            /*break*/
            , 4];

          case 3:
            this.setLoading(false);
            return [7
            /*endfinally*/
            ];

          case 4:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  AddProductToUser.prototype.handleClose = function () {
    this.setModalToAddProductToUserVisible(false);
  };

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], AddProductToUser.prototype, "form", void 0);

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], AddProductToUser.prototype, "isVisible", void 0);

  __decorate([uStore.Action], AddProductToUser.prototype, "setModalToAddProductToUserVisible", void 0);

  __decorate([uStore.Action], AddProductToUser.prototype, "addProductToUser", void 0);

  __decorate([uStore.State], AddProductToUser.prototype, "isModalLoading", void 0);

  __decorate([uStore.State], AddProductToUser.prototype, "isModalToAddProductVisible", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], AddProductToUser.prototype, "setDialogMessage", void 0);

  __decorate([pStore.State], AddProductToUser.prototype, "products", void 0);

  __decorate([pStore.Action], AddProductToUser.prototype, "loadProducts", void 0);

  __decorate([pStore.Action], AddProductToUser.prototype, "setLoading", void 0);

  __decorate([pStore.State], AddProductToUser.prototype, "isLoading", void 0);

  AddProductToUser = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({})], AddProductToUser);
  return AddProductToUser;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddProductToUser);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/icons/icons.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var uStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('users');

var UsersCard =
/** @class */
function (_super) {
  __extends(UsersCard, _super);

  function UsersCard() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  Object.defineProperty(UsersCard.prototype, "actualUser", {
    get: function get() {
      return this.$store.state.auth.user;
    },
    enumerable: false,
    configurable: true
  });

  UsersCard.prototype.handleAddProductToUser = function (user) {
    this.setFormProduct(user);
    this.setModalToAddProductToUserVisible(true);
  };

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], UsersCard.prototype, "user", void 0);

  __decorate([uStore.Action], UsersCard.prototype, "setModalToAddProductToUserVisible", void 0);

  __decorate([uStore.Action], UsersCard.prototype, "setFormProduct", void 0);

  __decorate([uStore.State], UsersCard.prototype, "isModalToAddProductVisible", void 0);

  __decorate([uStore.State], UsersCard.prototype, "formProduct", void 0);

  UsersCard = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      BIconPencilFill: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__.BIconPencilFill,
      BIconTrashFill: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__.BIconTrashFill
    }
  })], UsersCard);
  return UsersCard;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UsersCard);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var _utils_checkPassword__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/checkPassword */ "./resources/assets/vue/utils/checkPassword.ts");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var uStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('users');

var UsersModal =
/** @class */
function (_super) {
  __extends(UsersModal, _super);

  function UsersModal() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  UsersModal.prototype.handleOk = function () {
    if (!(0,_utils_checkPassword__WEBPACK_IMPORTED_MODULE_2__.default)(this.form)) {
      return;
    }

    if (this.isAdd) {
      this.addUser(this.form);
    } else {
      this.editUser(this.form);
    }
  };

  UsersModal.prototype.handleClose = function () {
    this.setModalVisible(false);
  };

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], UsersModal.prototype, "form", void 0);

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], UsersModal.prototype, "isAdd", void 0);

  __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Prop)()], UsersModal.prototype, "isVisible", void 0);

  __decorate([uStore.Action], UsersModal.prototype, "addUser", void 0);

  __decorate([uStore.Action], UsersModal.prototype, "editUser", void 0);

  __decorate([uStore.Action], UsersModal.prototype, "setModalVisible", void 0);

  __decorate([uStore.State], UsersModal.prototype, "isModalLoading", void 0);

  UsersModal = __decorate([vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component], UsersModal);
  return UsersModal;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UsersModal);

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".card-footer[data-v-20005f34] {\n  display: flex;\n  justify-content: flex-end;\n}\n.card-footer button[data-v-20005f34] {\n  display: flex;\n  align-items: center;\n}", "",{"version":3,"sources":["webpack://./resources/assets/vue/views/users/components/UsersCard.vue"],"names":[],"mappings":"AA2DA;EACE,aAAA;EACA,yBAAA;AA1DF;AA2DE;EACE,aAAA;EACA,mBAAA;AAzDJ","sourcesContent":["\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r\n.card-footer {\r\n  display: flex;\r\n  justify-content: flex-end;\r\n  button {\r\n    display: flex;\r\n    align-items: center;\r\n  }\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./resources/assets/vue/views/users/Users.vue":
/*!****************************************************!*\
  !*** ./resources/assets/vue/views/users/Users.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Users.vue?vue&type=template&id=3648e363&lang=pug& */ "./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug&");
/* harmony import */ var _Users_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Users.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _Users_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/users/Users.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/users/components/AddProductToUser.vue":
/*!**************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/AddProductToUser.vue ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug& */ "./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug&");
/* harmony import */ var _AddProductToUser_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AddProductToUser.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _AddProductToUser_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/users/components/AddProductToUser.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersCard.vue":
/*!*******************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersCard.vue ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug& */ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug&");
/* harmony import */ var _UsersCard_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UsersCard.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts&");
/* harmony import */ var _UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& */ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__.default)(
  _UsersCard_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "20005f34",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/users/components/UsersCard.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersModal.vue":
/*!********************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersModal.vue ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UsersModal.vue?vue&type=template&id=729b86b9&lang=pug& */ "./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug&");
/* harmony import */ var _UsersModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UsersModal.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _UsersModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/users/components/UsersModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts&":
/*!*****************************************************************************!*\
  !*** ./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Users_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Users.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Users_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts&":
/*!***************************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts& ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddProductToUser_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AddProductToUser.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddProductToUser_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts&":
/*!********************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersCard.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts&":
/*!*********************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts& ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersModal.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersModal_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug&":
/*!********************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Users_vue_vue_type_template_id_3648e363_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/pug-plain-loader/index.js!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Users.vue?vue&type=template&id=3648e363&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug&":
/*!******************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug& ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_AddProductToUser_vue_vue_type_template_id_b5162f70_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug& ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_template_id_20005f34_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug&":
/*!************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug& ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersModal_vue_vue_type_template_id_729b86b9_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersModal.vue?vue&type=template&id=729b86b9&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&":
/*!*****************************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& ***!
  \*****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_UsersCard_vue_vue_type_style_index_0_id_20005f34_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug&":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/Users.vue?vue&type=template&id=3648e363&lang=pug& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-container",
    { attrs: { tag: "main" } },
    [
      _vm.pagination.totalUsers > _vm.pagination.perPage
        ? _c("b-pagination", {
            attrs: {
              align: "center",
              "per-page": _vm.pagination.perPage,
              "total-rows": _vm.pagination.totalUsers
            },
            on: { change: _vm.getUsers },
            model: {
              value: _vm.currentPage,
              callback: function($$v) {
                _vm.currentPage = $$v
              },
              expression: "currentPage"
            }
          })
        : _vm._e(),
      _vm.users.length > 0
        ? _c(
            "div",
            { staticClass: "users" },
            _vm._l(_vm.users, function(user, i) {
              return _c("users-card", {
                key: user.id,
                attrs: { user: user },
                on: {
                  "edit-user": function($event) {
                    return _vm.editUser(user, i)
                  },
                  "delete-user": function($event) {
                    return _vm.deleteUserConfirm(user)
                  }
                }
              })
            }),
            1
          )
        : _vm.isLoading
        ? _c("div", [_vm._v(_vm._s(_vm.$t("strings.loading")) + "...")])
        : _c("div", [_vm._v(_vm._s(_vm.$t("users.no_users")))]),
      _vm.pagination.totalUsers > _vm.pagination.perPage
        ? _c("b-pagination", {
            attrs: {
              align: "center",
              "per-page": _vm.pagination.perPage,
              "total-rows": _vm.pagination.totalUsers
            },
            on: { change: _vm.getUsers },
            model: {
              value: _vm.currentPage,
              callback: function($$v) {
                _vm.currentPage = $$v
              },
              expression: "currentPage"
            }
          })
        : _vm._e(),
      _c("users-modal", {
        ref: "users_modal",
        attrs: {
          form: _vm.form,
          "is-add": _vm.isModalAdd,
          "is-visible": _vm.isModalVisible
        }
      }),
      _c("add-product-to-user", {
        ref: "add_product_to_user",
        attrs: {
          form: _vm.formProduct,
          "is-visible": _vm.isModalToAddProductVisible
        }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/AddProductToUser.vue?vue&type=template&id=b5162f70&lang=pug& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-modal",
    {
      attrs: {
        "hide-header-close": "",
        visible: _vm.isVisible,
        size: "xl",
        scrollable: "",
        centered: "",
        "cancel-title": _vm.$t("buttons.cancel"),
        "ok-disabled": _vm.isModalLoading,
        "ok-title": _vm.$t("buttons.add"),
        title: _vm.$t("products.add_product")
      },
      on: {
        hide: _vm.handleClose,
        ok: function($event) {
          $event.preventDefault()
          return _vm.handleOk($event)
        }
      }
    },
    [
      _c(
        "b-form",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  !_vm.isLoading
                    ? _c(
                        "b-form-group",
                        {
                          attrs: {
                            label: _vm.$t("products.form_estate"),
                            description: _vm.$t(
                              "products.form_estate_description"
                            ),
                            "label-for": "estate"
                          }
                        },
                        [
                          _c(
                            "b-form-select",
                            {
                              attrs: { "select-size": 7 },
                              model: {
                                value: _vm.form.product_id,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "product_id", $$v)
                                },
                                expression: "form.product_id"
                              }
                            },
                            _vm._l(_vm.products, function(product, i) {
                              return _c(
                                "b-form-select-option",
                                { key: i, attrs: { value: product.id } },
                                [_vm._v(_vm._s(product.estate))]
                              )
                            }),
                            1
                          )
                        ],
                        1
                      )
                    : _c(
                        "b-button",
                        {
                          attrs: { variant: "warning", disabled: "", block: "" }
                        },
                        [
                          _c("b-spinner", {
                            attrs: { small: "", variant: "light", type: "grow" }
                          })
                        ],
                        1
                      )
                ],
                1
              ),
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  !_vm.isLoading
                    ? _c(
                        "b-form-group",
                        {
                          attrs: {
                            label: _vm.$t("products.form_quantity_name"),
                            description: _vm.$t(
                              "products.form_quantity_description"
                            ),
                            "label-for": "quantity"
                          }
                        },
                        [
                          _c("b-form-input", {
                            attrs: {
                              id: "quantity",
                              type: "number",
                              min: "0",
                              required: ""
                            },
                            model: {
                              value: _vm.form.quantity,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "quantity", $$v)
                              },
                              expression: "form.quantity"
                            }
                          })
                        ],
                        1
                      )
                    : _c(
                        "b-button",
                        {
                          attrs: { variant: "warning", disabled: "", block: "" }
                        },
                        [
                          _c("b-spinner", {
                            attrs: { small: "", variant: "light", type: "grow" }
                          })
                        ],
                        1
                      )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=template&id=20005f34&scoped=true&lang=pug& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card",
    { staticClass: "users-card mb-3", attrs: { "no-body": "" } },
    [
      _c("h4", { attrs: { slot: "header" }, slot: "header" }, [
        _vm._v(
          _vm._s(_vm.user.name) +
            " " +
            _vm._s(_vm.user.lastname) +
            " " +
            _vm._s(_vm.user.second_lastname)
        )
      ]),
      _c("b-card-body", [
        _c("p", { staticClass: "card-text" }, [
          _c("span", { staticClass: "font-weight-bold" }, [
            _vm._v(_vm._s(_vm.$t("strings.email")) + ":")
          ]),
          _vm._v(" " + _vm._s(_vm.user.email)),
          _c("br"),
          _c("span", { staticClass: "font-weight-bold" }, [
            _vm._v(_vm._s(_vm.$t("users.user_type")) + ":")
          ]),
          _vm._v(
            " " +
              _vm._s(
                _vm.user.type_id === 1
                  ? _vm.$t("strings.admin")
                  : _vm.$t("strings.normal")
              )
          )
        ])
      ]),
      _c(
        "b-card-footer",
        [
          _c(
            "b-button",
            {
              attrs: { variant: "warning" },
              on: {
                click: function($event) {
                  return _vm.handleAddProductToUser(_vm.user)
                }
              }
            },
            [_vm._v(_vm._s(_vm.$t("products.add_product")))]
          ),
          _c(
            "b-button",
            {
              attrs: { variant: "link" },
              on: {
                click: function($event) {
                  return _vm.$emit("edit-user")
                }
              }
            },
            [
              _c("b-icon-pencil-fill"),
              _vm._v(" " + _vm._s(_vm.$t("buttons.edit")))
            ],
            1
          ),
          _vm.user.id !== _vm.actualUser.id
            ? _c(
                "b-button",
                {
                  staticClass: "text-danger",
                  attrs: { variant: "link" },
                  on: {
                    click: function($event) {
                      return _vm.$emit("delete-user")
                    }
                  }
                },
                [
                  _c("b-icon-trash-fill"),
                  _vm._v(" " + _vm._s(_vm.$t("buttons.delete")))
                ],
                1
              )
            : _vm._e()
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersModal.vue?vue&type=template&id=729b86b9&lang=pug& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-modal",
    {
      attrs: {
        "hide-header-close": "",
        visible: _vm.isVisible,
        "cancel-title": _vm.$t("buttons.cancel"),
        "ok-disabled": _vm.isModalLoading,
        "ok-title": _vm.isModalLoading
          ? _vm.$t("buttons.sending")
          : _vm.isAdd
          ? _vm.$t("buttons.add")
          : _vm.$t("buttons.update"),
        title: _vm.isAdd ? _vm.$t("users.add_user") : _vm.$t("users.edit_user")
      },
      on: {
        hide: _vm.handleClose,
        ok: function($event) {
          $event.preventDefault()
          return _vm.handleOk($event)
        }
      }
    },
    [
      _c(
        "b-form",
        [
          _c(
            "b-form-group",
            { attrs: { label: _vm.$t("strings.name"), "label-for": "name" } },
            [
              _c("b-form-input", {
                attrs: {
                  id: "name",
                  type: "text",
                  maxlength: "25",
                  required: ""
                },
                model: {
                  value: _vm.form.name,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "name", $$v)
                  },
                  expression: "form.name"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            {
              attrs: {
                label: _vm.$t("strings.lastname"),
                "label-for": "lastname"
              }
            },
            [
              _c("b-form-input", {
                attrs: {
                  id: "lastname",
                  type: "text",
                  maxlength: "15",
                  required: ""
                },
                model: {
                  value: _vm.form.lastname,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "lastname", $$v)
                  },
                  expression: "form.lastname"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            {
              attrs: {
                label: _vm.$t("strings.second_lastname"),
                "label-for": "second_lastname"
              }
            },
            [
              _c("b-form-input", {
                attrs: {
                  id: "second_lastname",
                  type: "text",
                  maxlength: "15",
                  required: ""
                },
                model: {
                  value: _vm.form.second_lastname,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "second_lastname", $$v)
                  },
                  expression: "form.second_lastname"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            { attrs: { label: _vm.$t("strings.email"), "label-for": "email" } },
            [
              _c("b-form-input", {
                attrs: {
                  id: "email",
                  type: "email",
                  maxlength: "191",
                  required: ""
                },
                model: {
                  value: _vm.form.email,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "email", $$v)
                  },
                  expression: "form.email"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            {
              attrs: {
                label: _vm.$t("strings.password"),
                "label-for": "password"
              }
            },
            [
              _c("b-form-input", {
                attrs: {
                  id: "password",
                  type: "password",
                  maxlength: "191",
                  required: ""
                },
                model: {
                  value: _vm.form.password,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "password", $$v)
                  },
                  expression: "form.password"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            {
              attrs: {
                label: _vm.$t("settings.password_confirmation"),
                "label-for": "password_confirmation"
              }
            },
            [
              _c("b-form-input", {
                attrs: {
                  id: "password_confirmation",
                  type: "password",
                  maxlength: "191"
                },
                model: {
                  value: _vm.form.password_confirmation,
                  callback: function($$v) {
                    _vm.$set(_vm.form, "password_confirmation", $$v)
                  },
                  expression: "form.password_confirmation"
                }
              })
            ],
            1
          ),
          _c(
            "b-form-group",
            { attrs: { label: _vm.$t("users.user_type") } },
            [
              _c(
                "b-form-radio-group",
                {
                  attrs: { name: "type_id" },
                  model: {
                    value: _vm.form.type_id,
                    callback: function($$v) {
                      _vm.$set(_vm.form, "type_id", _vm._n($$v))
                    },
                    expression: "form.type_id"
                  }
                },
                [
                  _c("b-form-radio", { attrs: { value: "2" } }, [
                    _vm._v(_vm._s(_vm.$t("strings.normal")))
                  ]),
                  _c("b-form-radio", { attrs: { value: "1" } }, [
                    _vm._v(_vm._s(_vm.$t("strings.admin")))
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/users/components/UsersCard.vue?vue&type=style&index=0&id=20005f34&lang=scss&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2a468bbd", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvdXNlcnMvVXNlcnMudnVlPzE2NjAiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvQWRkUHJvZHVjdFRvVXNlci52dWU/MDVmZiIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvdXNlcnMvY29tcG9uZW50cy9Vc2Vyc0NhcmQudnVlPzI5M2IiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNNb2RhbC52dWU/MDNmNCIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvdXNlcnMvY29tcG9uZW50cy9Vc2Vyc0NhcmQudnVlP2ZkMjMiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL1VzZXJzLnZ1ZT9iOTJmIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL0FkZFByb2R1Y3RUb1VzZXIudnVlPzc1NzIiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNDYXJkLnZ1ZT80NDU5Iiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL1VzZXJzTW9kYWwudnVlPzMwNDAiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL1VzZXJzLnZ1ZT9iNjA2Iiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL0FkZFByb2R1Y3RUb1VzZXIudnVlPzlkNTIiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNDYXJkLnZ1ZT9kYzgxIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL1VzZXJzTW9kYWwudnVlPzc1MTMiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL1VzZXJzLnZ1ZT82MDEwIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL0FkZFByb2R1Y3RUb1VzZXIudnVlP2VkYjEiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNDYXJkLnZ1ZT81MmQyIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL1VzZXJzTW9kYWwudnVlPzU2YmYiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNDYXJkLnZ1ZT8zY2FmIl0sIm5hbWVzIjpbIl9fZXh0ZW5kcyIsImV4dGVuZFN0YXRpY3MiLCJkIiwiYiIsIk9iamVjdCIsInNldFByb3RvdHlwZU9mIiwiX19wcm90b19fIiwiQXJyYXkiLCJwIiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiX18iLCJjb25zdHJ1Y3RvciIsImNyZWF0ZSIsIl9fYXNzaWduIiwiYXNzaWduIiwidCIsInMiLCJpIiwibiIsImFyZ3VtZW50cyIsImxlbmd0aCIsImFwcGx5IiwiX19kZWNvcmF0ZSIsImRlY29yYXRvcnMiLCJ0YXJnZXQiLCJrZXkiLCJkZXNjIiwiYyIsInIiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJSZWZsZWN0IiwiZGVjb3JhdGUiLCJkZWZpbmVQcm9wZXJ0eSIsIl9fYXdhaXRlciIsInRoaXNBcmciLCJfYXJndW1lbnRzIiwiUCIsImdlbmVyYXRvciIsImFkb3B0IiwidmFsdWUiLCJyZXNvbHZlIiwiUHJvbWlzZSIsInJlamVjdCIsImZ1bGZpbGxlZCIsInN0ZXAiLCJuZXh0IiwiZSIsInJlamVjdGVkIiwicmVzdWx0IiwiZG9uZSIsInRoZW4iLCJfX2dlbmVyYXRvciIsImJvZHkiLCJfIiwibGFiZWwiLCJzZW50IiwidHJ5cyIsIm9wcyIsImYiLCJ5IiwiZyIsInZlcmIiLCJTeW1ib2wiLCJpdGVyYXRvciIsInYiLCJvcCIsInBvcCIsInB1c2giLCJ1U3RvcmUiLCJuYW1lc3BhY2UiLCJVc2VycyIsIl9zdXBlciIsIl90aGlzIiwiY3VycmVudFBhZ2UiLCJmb3JtIiwiaXNNb2RhbEFkZCIsImNyZWF0ZWQiLCJfYSIsInNldEJhY2tVcmwiLCJzZXRNZW51IiwidGV4dCIsImhhbmRsZXIiLCJhZGRVc2VyIiwicGFnaW5hdGlvbiIsInVzZXJzIiwiZ2V0VXNlcnMiLCJzZXRNb2RhbFZpc2libGUiLCJ0eXBlX2lkIiwiZWRpdFVzZXIiLCJ1c2VyIiwiZGVsZXRlVXNlckNvbmZpcm0iLCJkaWFsb2ciLCJkZWxldGVVc2VyIiwicGFnZSIsImxvYWRVc2VycyIsIkFjdGlvbiIsIlN0YXRlIiwiQ29tcG9uZW50IiwiY29tcG9uZW50cyIsIkFkZFByb2R1Y3RUb1VzZXIiLCJVc2Vyc0NhcmQiLCJVc2Vyc01vZGFsIiwiVnVlIiwicFN0b3JlIiwiZ2V0UHJvZHVjdHMiLCJsb2FkUHJvZHVjdHMiLCJoYW5kbGVPayIsInJlc3BvbnNlIiwiY2hlY2tFcnJvcnMiLCJfYiIsInNldExvYWRpbmciLCJheGlvcyIsImNoZWNrUmVzcG9uc2UiLCIkYnZUb2FzdCIsInRvYXN0IiwidGl0bGUiLCJtZXNzYWdlIiwidmFyaWFudCIsInRvYXN0ZXIiLCJzb2xpZCIsImhhbmRsZUNsb3NlIiwiJHQiLCJzZXRNb2RhbFRvQWRkUHJvZHVjdFRvVXNlclZpc2libGUiLCJQcm9wIiwiZ2V0IiwiJHN0b3JlIiwic3RhdGUiLCJhdXRoIiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsImhhbmRsZUFkZFByb2R1Y3RUb1VzZXIiLCJzZXRGb3JtUHJvZHVjdCIsIkJJY29uUGVuY2lsRmlsbCIsIkJJY29uVHJhc2hGaWxsIiwiY2hlY2tQYXNzd29yZCIsImlzQWRkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE2QixZQUFZO0FBQ3JELE1BQUlDLGNBQWEsR0FBRyx1QkFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ2hDRixrQkFBYSxHQUFHRyxNQUFNLENBQUNDLGNBQVAsSUFDWDtBQUFFQyxlQUFTLEVBQUU7QUFBYixpQkFBNkJDLEtBQTdCLElBQXNDLFVBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFRCxPQUFDLENBQUNJLFNBQUYsR0FBY0gsQ0FBZDtBQUFrQixLQUQvRCxJQUVaLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFLFdBQUssSUFBSUssQ0FBVCxJQUFjTCxDQUFkO0FBQWlCLFlBQUlDLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUixDQUFyQyxFQUF3Q0ssQ0FBeEMsQ0FBSixFQUFnRE4sQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBT0wsQ0FBQyxDQUFDSyxDQUFELENBQVI7QUFBakU7QUFBK0UsS0FGckc7O0FBR0EsV0FBT1AsY0FBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBcEI7QUFDSCxHQUxEOztBQU1BLFNBQU8sVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ25CLFFBQUksT0FBT0EsQ0FBUCxLQUFhLFVBQWIsSUFBMkJBLENBQUMsS0FBSyxJQUFyQyxFQUNJLE1BQU0sSUFBSVMsU0FBSixDQUFjLHlCQUF5QkMsTUFBTSxDQUFDVixDQUFELENBQS9CLEdBQXFDLCtCQUFuRCxDQUFOOztBQUNKRixrQkFBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBYjs7QUFDQSxhQUFTVyxFQUFULEdBQWM7QUFBRSxXQUFLQyxXQUFMLEdBQW1CYixDQUFuQjtBQUF1Qjs7QUFDdkNBLEtBQUMsQ0FBQ08sU0FBRixHQUFjTixDQUFDLEtBQUssSUFBTixHQUFhQyxNQUFNLENBQUNZLE1BQVAsQ0FBY2IsQ0FBZCxDQUFiLElBQWlDVyxFQUFFLENBQUNMLFNBQUgsR0FBZU4sQ0FBQyxDQUFDTSxTQUFqQixFQUE0QixJQUFJSyxFQUFKLEVBQTdELENBQWQ7QUFDSCxHQU5EO0FBT0gsQ0FkMkMsRUFBNUM7O0FBZUEsSUFBSUcsUUFBUSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFFBQWQsSUFBMkIsWUFBWTtBQUNsREEsVUFBUSxHQUFHYixNQUFNLENBQUNjLE1BQVAsSUFBaUIsVUFBU0MsQ0FBVCxFQUFZO0FBQ3BDLFNBQUssSUFBSUMsQ0FBSixFQUFPQyxDQUFDLEdBQUcsQ0FBWCxFQUFjQyxDQUFDLEdBQUdDLFNBQVMsQ0FBQ0MsTUFBakMsRUFBeUNILENBQUMsR0FBR0MsQ0FBN0MsRUFBZ0RELENBQUMsRUFBakQsRUFBcUQ7QUFDakRELE9BQUMsR0FBR0csU0FBUyxDQUFDRixDQUFELENBQWI7O0FBQ0EsV0FBSyxJQUFJYixDQUFULElBQWNZLENBQWQ7QUFBaUIsWUFBSWhCLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUyxDQUFyQyxFQUF3Q1osQ0FBeEMsQ0FBSixFQUNiVyxDQUFDLENBQUNYLENBQUQsQ0FBRCxHQUFPWSxDQUFDLENBQUNaLENBQUQsQ0FBUjtBQURKO0FBRUg7O0FBQ0QsV0FBT1csQ0FBUDtBQUNILEdBUEQ7O0FBUUEsU0FBT0YsUUFBUSxDQUFDUSxLQUFULENBQWUsSUFBZixFQUFxQkYsU0FBckIsQ0FBUDtBQUNILENBVkQ7O0FBV0EsSUFBSUcsVUFBVSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFVBQWQsSUFBNkIsVUFBVUMsVUFBVixFQUFzQkMsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DQyxJQUFuQyxFQUF5QztBQUNuRixNQUFJQyxDQUFDLEdBQUdSLFNBQVMsQ0FBQ0MsTUFBbEI7QUFBQSxNQUEwQlEsQ0FBQyxHQUFHRCxDQUFDLEdBQUcsQ0FBSixHQUFRSCxNQUFSLEdBQWlCRSxJQUFJLEtBQUssSUFBVCxHQUFnQkEsSUFBSSxHQUFHMUIsTUFBTSxDQUFDNkIsd0JBQVAsQ0FBZ0NMLE1BQWhDLEVBQXdDQyxHQUF4QyxDQUF2QixHQUFzRUMsSUFBckg7QUFBQSxNQUEySDVCLENBQTNIO0FBQ0EsTUFBSSxRQUFPZ0MsT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUFuQixJQUErQixPQUFPQSxPQUFPLENBQUNDLFFBQWYsS0FBNEIsVUFBL0QsRUFBMkVILENBQUMsR0FBR0UsT0FBTyxDQUFDQyxRQUFSLENBQWlCUixVQUFqQixFQUE2QkMsTUFBN0IsRUFBcUNDLEdBQXJDLEVBQTBDQyxJQUExQyxDQUFKLENBQTNFLEtBQ0ssS0FBSyxJQUFJVCxDQUFDLEdBQUdNLFVBQVUsQ0FBQ0gsTUFBWCxHQUFvQixDQUFqQyxFQUFvQ0gsQ0FBQyxJQUFJLENBQXpDLEVBQTRDQSxDQUFDLEVBQTdDO0FBQWlELFFBQUluQixDQUFDLEdBQUd5QixVQUFVLENBQUNOLENBQUQsQ0FBbEIsRUFBdUJXLENBQUMsR0FBRyxDQUFDRCxDQUFDLEdBQUcsQ0FBSixHQUFRN0IsQ0FBQyxDQUFDOEIsQ0FBRCxDQUFULEdBQWVELENBQUMsR0FBRyxDQUFKLEdBQVE3QixDQUFDLENBQUMwQixNQUFELEVBQVNDLEdBQVQsRUFBY0csQ0FBZCxDQUFULEdBQTRCOUIsQ0FBQyxDQUFDMEIsTUFBRCxFQUFTQyxHQUFULENBQTdDLEtBQStERyxDQUFuRTtBQUF4RTtBQUNMLFNBQU9ELENBQUMsR0FBRyxDQUFKLElBQVNDLENBQVQsSUFBYzVCLE1BQU0sQ0FBQ2dDLGNBQVAsQ0FBc0JSLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0csQ0FBbkMsQ0FBZCxFQUFxREEsQ0FBNUQ7QUFDSCxDQUxEOztBQU1BLElBQUlLLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsYUFBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFlBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixjQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxZQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxRQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNoQixLQUFWLENBQWdCYSxPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSU0sV0FBVyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFdBQWQsSUFBOEIsVUFBVWpCLE9BQVYsRUFBbUJrQixJQUFuQixFQUF5QjtBQUNyRSxNQUFJQyxDQUFDLEdBQUc7QUFBRUMsU0FBSyxFQUFFLENBQVQ7QUFBWUMsUUFBSSxFQUFFLGdCQUFXO0FBQUUsVUFBSXhDLENBQUMsQ0FBQyxDQUFELENBQUQsR0FBTyxDQUFYLEVBQWMsTUFBTUEsQ0FBQyxDQUFDLENBQUQsQ0FBUDtBQUFZLGFBQU9BLENBQUMsQ0FBQyxDQUFELENBQVI7QUFBYyxLQUF2RTtBQUF5RXlDLFFBQUksRUFBRSxFQUEvRTtBQUFtRkMsT0FBRyxFQUFFO0FBQXhGLEdBQVI7QUFBQSxNQUFzR0MsQ0FBdEc7QUFBQSxNQUF5R0MsQ0FBekc7QUFBQSxNQUE0RzVDLENBQTVHO0FBQUEsTUFBK0c2QyxDQUEvRztBQUNBLFNBQU9BLENBQUMsR0FBRztBQUFFZixRQUFJLEVBQUVnQixJQUFJLENBQUMsQ0FBRCxDQUFaO0FBQWlCLGFBQVNBLElBQUksQ0FBQyxDQUFELENBQTlCO0FBQW1DLGNBQVVBLElBQUksQ0FBQyxDQUFEO0FBQWpELEdBQUosRUFBNEQsT0FBT0MsTUFBUCxLQUFrQixVQUFsQixLQUFpQ0YsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLFFBQVIsQ0FBRCxHQUFxQixZQUFXO0FBQUUsV0FBTyxJQUFQO0FBQWMsR0FBakYsQ0FBNUQsRUFBZ0pILENBQXZKOztBQUNBLFdBQVNDLElBQVQsQ0FBYzNDLENBQWQsRUFBaUI7QUFBRSxXQUFPLFVBQVU4QyxDQUFWLEVBQWE7QUFBRSxhQUFPcEIsSUFBSSxDQUFDLENBQUMxQixDQUFELEVBQUk4QyxDQUFKLENBQUQsQ0FBWDtBQUFzQixLQUE1QztBQUErQzs7QUFDbEUsV0FBU3BCLElBQVQsQ0FBY3FCLEVBQWQsRUFBa0I7QUFDZCxRQUFJUCxDQUFKLEVBQU8sTUFBTSxJQUFJbEQsU0FBSixDQUFjLGlDQUFkLENBQU47O0FBQ1AsV0FBTzZDLENBQVA7QUFBVSxVQUFJO0FBQ1YsWUFBSUssQ0FBQyxHQUFHLENBQUosRUFBT0MsQ0FBQyxLQUFLNUMsQ0FBQyxHQUFHa0QsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVIsR0FBWU4sQ0FBQyxDQUFDLFFBQUQsQ0FBYixHQUEwQk0sRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRTixDQUFDLENBQUMsT0FBRCxDQUFELEtBQWUsQ0FBQzVDLENBQUMsR0FBRzRDLENBQUMsQ0FBQyxRQUFELENBQU4sS0FBcUI1QyxDQUFDLENBQUNSLElBQUYsQ0FBT29ELENBQVAsQ0FBckIsRUFBZ0MsQ0FBL0MsQ0FBUixHQUE0REEsQ0FBQyxDQUFDZCxJQUFqRyxDQUFELElBQTJHLENBQUMsQ0FBQzlCLENBQUMsR0FBR0EsQ0FBQyxDQUFDUixJQUFGLENBQU9vRCxDQUFQLEVBQVVNLEVBQUUsQ0FBQyxDQUFELENBQVosQ0FBTCxFQUF1QmhCLElBQTlJLEVBQW9KLE9BQU9sQyxDQUFQO0FBQ3BKLFlBQUk0QyxDQUFDLEdBQUcsQ0FBSixFQUFPNUMsQ0FBWCxFQUFja0QsRUFBRSxHQUFHLENBQUNBLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFULEVBQVlsRCxDQUFDLENBQUN3QixLQUFkLENBQUw7O0FBQ2QsZ0JBQVEwQixFQUFFLENBQUMsQ0FBRCxDQUFWO0FBQ0ksZUFBSyxDQUFMO0FBQVEsZUFBSyxDQUFMO0FBQVFsRCxhQUFDLEdBQUdrRCxFQUFKO0FBQVE7O0FBQ3hCLGVBQUssQ0FBTDtBQUFRWixhQUFDLENBQUNDLEtBQUY7QUFBVyxtQkFBTztBQUFFZixtQkFBSyxFQUFFMEIsRUFBRSxDQUFDLENBQUQsQ0FBWDtBQUFnQmhCLGtCQUFJLEVBQUU7QUFBdEIsYUFBUDs7QUFDbkIsZUFBSyxDQUFMO0FBQVFJLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXSyxhQUFDLEdBQUdNLEVBQUUsQ0FBQyxDQUFELENBQU47QUFBV0EsY0FBRSxHQUFHLENBQUMsQ0FBRCxDQUFMO0FBQVU7O0FBQ3hDLGVBQUssQ0FBTDtBQUFRQSxjQUFFLEdBQUdaLENBQUMsQ0FBQ0ksR0FBRixDQUFNUyxHQUFOLEVBQUw7O0FBQWtCYixhQUFDLENBQUNHLElBQUYsQ0FBT1UsR0FBUDs7QUFBYzs7QUFDeEM7QUFDSSxnQkFBSSxFQUFFbkQsQ0FBQyxHQUFHc0MsQ0FBQyxDQUFDRyxJQUFOLEVBQVl6QyxDQUFDLEdBQUdBLENBQUMsQ0FBQ0ssTUFBRixHQUFXLENBQVgsSUFBZ0JMLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDSyxNQUFGLEdBQVcsQ0FBWixDQUFuQyxNQUF1RDZDLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFoRixDQUFKLEVBQXdGO0FBQUVaLGVBQUMsR0FBRyxDQUFKO0FBQU87QUFBVzs7QUFDNUcsZ0JBQUlZLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLEtBQWdCLENBQUNsRCxDQUFELElBQU9rRCxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFsRCxDQUFDLENBQUMsQ0FBRCxDQUFULElBQWdCa0QsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRbEQsQ0FBQyxDQUFDLENBQUQsQ0FBaEQsQ0FBSixFQUEyRDtBQUFFc0MsZUFBQyxDQUFDQyxLQUFGLEdBQVVXLEVBQUUsQ0FBQyxDQUFELENBQVo7QUFBaUI7QUFBUTs7QUFDdEYsZ0JBQUlBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVaLENBQUMsQ0FBQ0MsS0FBRixHQUFVdkMsQ0FBQyxDQUFDLENBQUQsQ0FBOUIsRUFBbUM7QUFBRXNDLGVBQUMsQ0FBQ0MsS0FBRixHQUFVdkMsQ0FBQyxDQUFDLENBQUQsQ0FBWDtBQUFnQkEsZUFBQyxHQUFHa0QsRUFBSjtBQUFRO0FBQVE7O0FBQ3JFLGdCQUFJbEQsQ0FBQyxJQUFJc0MsQ0FBQyxDQUFDQyxLQUFGLEdBQVV2QyxDQUFDLENBQUMsQ0FBRCxDQUFwQixFQUF5QjtBQUFFc0MsZUFBQyxDQUFDQyxLQUFGLEdBQVV2QyxDQUFDLENBQUMsQ0FBRCxDQUFYOztBQUFnQnNDLGVBQUMsQ0FBQ0ksR0FBRixDQUFNVSxJQUFOLENBQVdGLEVBQVg7O0FBQWdCO0FBQVE7O0FBQ25FLGdCQUFJbEQsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVc0MsQ0FBQyxDQUFDSSxHQUFGLENBQU1TLEdBQU47O0FBQ1ZiLGFBQUMsQ0FBQ0csSUFBRixDQUFPVSxHQUFQOztBQUFjO0FBWHRCOztBQWFBRCxVQUFFLEdBQUdiLElBQUksQ0FBQzdDLElBQUwsQ0FBVTJCLE9BQVYsRUFBbUJtQixDQUFuQixDQUFMO0FBQ0gsT0FqQlMsQ0FpQlIsT0FBT1AsQ0FBUCxFQUFVO0FBQUVtQixVQUFFLEdBQUcsQ0FBQyxDQUFELEVBQUluQixDQUFKLENBQUw7QUFBYWEsU0FBQyxHQUFHLENBQUo7QUFBUSxPQWpCekIsU0FpQmtDO0FBQUVELFNBQUMsR0FBRzNDLENBQUMsR0FBRyxDQUFSO0FBQVk7QUFqQjFEOztBQWtCQSxRQUFJa0QsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVosRUFBZSxNQUFNQSxFQUFFLENBQUMsQ0FBRCxDQUFSO0FBQWEsV0FBTztBQUFFMUIsV0FBSyxFQUFFMEIsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRQSxFQUFFLENBQUMsQ0FBRCxDQUFWLEdBQWdCLEtBQUssQ0FBOUI7QUFBaUNoQixVQUFJLEVBQUU7QUFBdkMsS0FBUDtBQUMvQjtBQUNKLENBMUJEOztBQTJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJbUIsTUFBTSxHQUFHQyxxREFBUyxDQUFDLE9BQUQsQ0FBdEI7O0FBQ0EsSUFBSUMsS0FBSztBQUFHO0FBQWUsVUFBVUMsTUFBVixFQUFrQjtBQUN6QzNFLFdBQVMsQ0FBQzBFLEtBQUQsRUFBUUMsTUFBUixDQUFUOztBQUNBLFdBQVNELEtBQVQsR0FBaUI7QUFDYixRQUFJRSxLQUFLLEdBQUdELE1BQU0sS0FBSyxJQUFYLElBQW1CQSxNQUFNLENBQUNsRCxLQUFQLENBQWEsSUFBYixFQUFtQkYsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBaEU7O0FBQ0FxRCxTQUFLLENBQUNDLFdBQU4sR0FBb0IsQ0FBcEI7QUFDQUQsU0FBSyxDQUFDRSxJQUFOLEdBQWEsRUFBYjtBQUNBRixTQUFLLENBQUNHLFVBQU4sR0FBbUIsSUFBbkI7QUFDQSxXQUFPSCxLQUFQO0FBQ0g7O0FBQ0RGLE9BQUssQ0FBQ2pFLFNBQU4sQ0FBZ0J1RSxPQUFoQixHQUEwQixZQUFZO0FBQ2xDLFdBQU8zQyxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxhQUFPa0IsV0FBVyxDQUFDLElBQUQsRUFBTyxVQUFVMEIsRUFBVixFQUFjO0FBQ25DLGdCQUFRQSxFQUFFLENBQUN2QixLQUFYO0FBQ0ksZUFBSyxDQUFMO0FBQ0ksaUJBQUt3QixVQUFMLENBQWdCLEdBQWhCO0FBQ0EsaUJBQUtDLE9BQUwsQ0FBYSxDQUNUO0FBQ0l0RCxpQkFBRyxFQUFFLFVBRFQ7QUFFSXVELGtCQUFJLEVBQUUsZ0JBRlY7QUFHSUMscUJBQU8sRUFBRSxLQUFLQztBQUhsQixhQURTLENBQWI7QUFPQSxpQkFBS1QsV0FBTCxHQUFtQixLQUFLVSxVQUFMLENBQWdCVixXQUFuQztBQUNBLGdCQUFJLEVBQUUsS0FBS1csS0FBTCxDQUFXaEUsTUFBWCxJQUFxQixDQUF2QixDQUFKLEVBQStCLE9BQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7QUFDL0IsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxLQUFLaUUsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJUixjQUFFLENBQUN0QixJQUFIOztBQUNBc0IsY0FBRSxDQUFDdkIsS0FBSCxHQUFXLENBQVg7O0FBQ0osZUFBSyxDQUFMO0FBQVEsbUJBQU8sQ0FBQztBQUFFO0FBQUgsYUFBUDtBQWhCWjtBQWtCSCxPQW5CaUIsQ0FBbEI7QUFvQkgsS0FyQmUsQ0FBaEI7QUFzQkgsR0F2QkQ7O0FBd0JBZ0IsT0FBSyxDQUFDakUsU0FBTixDQUFnQjZFLE9BQWhCLEdBQTBCLFlBQVk7QUFDbEMsU0FBS1AsVUFBTCxHQUFrQixJQUFsQjtBQUNBLFNBQUtXLGVBQUwsQ0FBcUIsSUFBckI7QUFDQSxTQUFLWixJQUFMLEdBQVk7QUFDUmEsYUFBTyxFQUFFO0FBREQsS0FBWjtBQUdILEdBTkQ7O0FBT0FqQixPQUFLLENBQUNqRSxTQUFOLENBQWdCbUYsUUFBaEIsR0FBMkIsVUFBVUMsSUFBVixFQUFnQjtBQUN2QyxTQUFLZCxVQUFMLEdBQWtCLEtBQWxCO0FBQ0EsU0FBS1csZUFBTCxDQUFxQixJQUFyQjtBQUNBLFNBQUtaLElBQUwsR0FBWTdELFFBQVEsQ0FBQyxFQUFELEVBQUs0RSxJQUFMLENBQXBCO0FBQ0gsR0FKRDs7QUFLQW5CLE9BQUssQ0FBQ2pFLFNBQU4sQ0FBZ0JxRixpQkFBaEIsR0FBb0MsVUFBVUQsSUFBVixFQUFnQjtBQUNoRCxXQUFPeEQsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT2tCLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVTBCLEVBQVYsRUFBYztBQUNuQyxnQkFBUUEsRUFBRSxDQUFDdkIsS0FBWDtBQUNJLGVBQUssQ0FBTDtBQUFRLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWNxQyxzREFBTSxDQUFDLGdDQUFELEVBQW1DLElBQW5DLENBQXBCLENBQVA7O0FBQ1IsZUFBSyxDQUFMO0FBQ0ksZ0JBQUksQ0FBRWQsRUFBRSxDQUFDdEIsSUFBSCxFQUFOLEVBQWtCO0FBQ2QscUJBQU8sQ0FBQztBQUFFO0FBQUgsZUFBUDtBQUNIOztBQUNELGlCQUFLcUMsVUFBTCxDQUFnQkgsSUFBaEI7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxhQUFQO0FBUFI7QUFTSCxPQVZpQixDQUFsQjtBQVdILEtBWmUsQ0FBaEI7QUFhSCxHQWREOztBQWVBbkIsT0FBSyxDQUFDakUsU0FBTixDQUFnQmdGLFFBQWhCLEdBQTJCLFVBQVVRLElBQVYsRUFBZ0I7QUFDdkMsV0FBTzVELFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixZQUFZO0FBQy9DLGFBQU9rQixXQUFXLENBQUMsSUFBRCxFQUFPLFVBQVUwQixFQUFWLEVBQWM7QUFDbkMsYUFBS2lCLFNBQUwsQ0FBZTtBQUFFRCxjQUFJLEVBQUVBO0FBQVIsU0FBZjtBQUNBLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BSGlCLENBQWxCO0FBSUgsS0FMZSxDQUFoQjtBQU1ILEdBUEQ7O0FBUUF2RSxZQUFVLENBQUMsQ0FDUHlFLDhDQURPLENBQUQsRUFFUHpCLEtBQUssQ0FBQ2pFLFNBRkMsRUFFVSxZQUZWLEVBRXdCLEtBQUssQ0FGN0IsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQeUUsOENBRE8sQ0FBRCxFQUVQekIsS0FBSyxDQUFDakUsU0FGQyxFQUVVLFNBRlYsRUFFcUIsS0FBSyxDQUYxQixDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUM0QixLQURBLENBQUQsRUFFUDFCLEtBQUssQ0FBQ2pFLFNBRkMsRUFFVSxPQUZWLEVBRW1CLEtBQUssQ0FGeEIsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDNEIsS0FEQSxDQUFELEVBRVAxQixLQUFLLENBQUNqRSxTQUZDLEVBRVUsWUFGVixFQUV3QixLQUFLLENBRjdCLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzRCLEtBREEsQ0FBRCxFQUVQMUIsS0FBSyxDQUFDakUsU0FGQyxFQUVVLFdBRlYsRUFFdUIsS0FBSyxDQUY1QixDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUM0QixLQURBLENBQUQsRUFFUDFCLEtBQUssQ0FBQ2pFLFNBRkMsRUFFVSxnQkFGVixFQUU0QixLQUFLLENBRmpDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzRCLEtBREEsQ0FBRCxFQUVQMUIsS0FBSyxDQUFDakUsU0FGQyxFQUVVLDRCQUZWLEVBRXdDLEtBQUssQ0FGN0MsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDNEIsS0FEQSxDQUFELEVBRVAxQixLQUFLLENBQUNqRSxTQUZDLEVBRVUsYUFGVixFQUV5QixLQUFLLENBRjlCLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzJCLE1BREEsQ0FBRCxFQUVQekIsS0FBSyxDQUFDakUsU0FGQyxFQUVVLFlBRlYsRUFFd0IsS0FBSyxDQUY3QixDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUMyQixNQURBLENBQUQsRUFFUHpCLEtBQUssQ0FBQ2pFLFNBRkMsRUFFVSxXQUZWLEVBRXVCLEtBQUssQ0FGNUIsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDMkIsTUFEQSxDQUFELEVBRVB6QixLQUFLLENBQUNqRSxTQUZDLEVBRVUsaUJBRlYsRUFFNkIsS0FBSyxDQUZsQyxDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUMyQixNQURBLENBQUQsRUFFUHpCLEtBQUssQ0FBQ2pFLFNBRkMsRUFFVSxnQkFGVixFQUU0QixLQUFLLENBRmpDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzJCLE1BREEsQ0FBRCxFQUVQekIsS0FBSyxDQUFDakUsU0FGQyxFQUVVLG1DQUZWLEVBRStDLEtBQUssQ0FGcEQsQ0FBVjs7QUFHQWlFLE9BQUssR0FBR2hELFVBQVUsQ0FBQyxDQUNmMkUsaUVBQVMsQ0FBQztBQUNOQyxjQUFVLEVBQUU7QUFDUkMsc0JBQWdCLEVBQUVBLGlGQURWO0FBRVJDLGVBQVMsRUFBRUEsOERBRkg7QUFHUkMsZ0JBQVUsRUFBRUEsK0RBQVVBO0FBSGQ7QUFETixHQUFELENBRE0sQ0FBRCxFQVFmL0IsS0FSZSxDQUFsQjtBQVNBLFNBQU9BLEtBQVA7QUFDSCxDQXJIMEIsQ0FxSHpCZ0MsdURBckh5QixDQUEzQjs7QUFzSEEsaUVBQWVoQyxLQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqTUEsSUFBSTFFLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTZCLFlBQVk7QUFDckQsTUFBSUMsY0FBYSxHQUFHLHVCQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDaENGLGtCQUFhLEdBQUdHLE1BQU0sQ0FBQ0MsY0FBUCxJQUNYO0FBQUVDLGVBQVMsRUFBRTtBQUFiLGlCQUE2QkMsS0FBN0IsSUFBc0MsVUFBVUwsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUVELE9BQUMsQ0FBQ0ksU0FBRixHQUFjSCxDQUFkO0FBQWtCLEtBRC9ELElBRVosVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUUsV0FBSyxJQUFJSyxDQUFULElBQWNMLENBQWQ7QUFBaUIsWUFBSUMsTUFBTSxDQUFDSyxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNSLENBQXJDLEVBQXdDSyxDQUF4QyxDQUFKLEVBQWdETixDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPTCxDQUFDLENBQUNLLENBQUQsQ0FBUjtBQUFqRTtBQUErRSxLQUZyRzs7QUFHQSxXQUFPUCxjQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFwQjtBQUNILEdBTEQ7O0FBTUEsU0FBTyxVQUFVRCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDbkIsUUFBSSxPQUFPQSxDQUFQLEtBQWEsVUFBYixJQUEyQkEsQ0FBQyxLQUFLLElBQXJDLEVBQ0ksTUFBTSxJQUFJUyxTQUFKLENBQWMseUJBQXlCQyxNQUFNLENBQUNWLENBQUQsQ0FBL0IsR0FBcUMsK0JBQW5ELENBQU47O0FBQ0pGLGtCQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFiOztBQUNBLGFBQVNXLEVBQVQsR0FBYztBQUFFLFdBQUtDLFdBQUwsR0FBbUJiLENBQW5CO0FBQXVCOztBQUN2Q0EsS0FBQyxDQUFDTyxTQUFGLEdBQWNOLENBQUMsS0FBSyxJQUFOLEdBQWFDLE1BQU0sQ0FBQ1ksTUFBUCxDQUFjYixDQUFkLENBQWIsSUFBaUNXLEVBQUUsQ0FBQ0wsU0FBSCxHQUFlTixDQUFDLENBQUNNLFNBQWpCLEVBQTRCLElBQUlLLEVBQUosRUFBN0QsQ0FBZDtBQUNILEdBTkQ7QUFPSCxDQWQyQyxFQUE1Qzs7QUFlQSxJQUFJWSxVQUFVLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsVUFBZCxJQUE2QixVQUFVQyxVQUFWLEVBQXNCQyxNQUF0QixFQUE4QkMsR0FBOUIsRUFBbUNDLElBQW5DLEVBQXlDO0FBQ25GLE1BQUlDLENBQUMsR0FBR1IsU0FBUyxDQUFDQyxNQUFsQjtBQUFBLE1BQTBCUSxDQUFDLEdBQUdELENBQUMsR0FBRyxDQUFKLEdBQVFILE1BQVIsR0FBaUJFLElBQUksS0FBSyxJQUFULEdBQWdCQSxJQUFJLEdBQUcxQixNQUFNLENBQUM2Qix3QkFBUCxDQUFnQ0wsTUFBaEMsRUFBd0NDLEdBQXhDLENBQXZCLEdBQXNFQyxJQUFySDtBQUFBLE1BQTJINUIsQ0FBM0g7QUFDQSxNQUFJLFFBQU9nQyxPQUFQLHlDQUFPQSxPQUFQLE9BQW1CLFFBQW5CLElBQStCLE9BQU9BLE9BQU8sQ0FBQ0MsUUFBZixLQUE0QixVQUEvRCxFQUEyRUgsQ0FBQyxHQUFHRSxPQUFPLENBQUNDLFFBQVIsQ0FBaUJSLFVBQWpCLEVBQTZCQyxNQUE3QixFQUFxQ0MsR0FBckMsRUFBMENDLElBQTFDLENBQUosQ0FBM0UsS0FDSyxLQUFLLElBQUlULENBQUMsR0FBR00sVUFBVSxDQUFDSCxNQUFYLEdBQW9CLENBQWpDLEVBQW9DSCxDQUFDLElBQUksQ0FBekMsRUFBNENBLENBQUMsRUFBN0M7QUFBaUQsUUFBSW5CLENBQUMsR0FBR3lCLFVBQVUsQ0FBQ04sQ0FBRCxDQUFsQixFQUF1QlcsQ0FBQyxHQUFHLENBQUNELENBQUMsR0FBRyxDQUFKLEdBQVE3QixDQUFDLENBQUM4QixDQUFELENBQVQsR0FBZUQsQ0FBQyxHQUFHLENBQUosR0FBUTdCLENBQUMsQ0FBQzBCLE1BQUQsRUFBU0MsR0FBVCxFQUFjRyxDQUFkLENBQVQsR0FBNEI5QixDQUFDLENBQUMwQixNQUFELEVBQVNDLEdBQVQsQ0FBN0MsS0FBK0RHLENBQW5FO0FBQXhFO0FBQ0wsU0FBT0QsQ0FBQyxHQUFHLENBQUosSUFBU0MsQ0FBVCxJQUFjNUIsTUFBTSxDQUFDZ0MsY0FBUCxDQUFzQlIsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DRyxDQUFuQyxDQUFkLEVBQXFEQSxDQUE1RDtBQUNILENBTEQ7O0FBTUEsSUFBSUssU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVDLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlILENBQWpCLEdBQXFCRyxLQUFyQixHQUE2QixJQUFJSCxDQUFKLENBQU0sVUFBVUksT0FBVixFQUFtQjtBQUFFQSxhQUFPLENBQUNELEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLSCxDQUFDLEtBQUtBLENBQUMsR0FBR0ssT0FBVCxDQUFOLEVBQXlCLFVBQVVELE9BQVYsRUFBbUJFLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNDLFNBQVQsQ0FBbUJKLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFSyxZQUFJLENBQUNQLFNBQVMsQ0FBQ1EsSUFBVixDQUFlTixLQUFmLENBQUQsQ0FBSjtBQUE4QixPQUFwQyxDQUFxQyxPQUFPTyxDQUFQLEVBQVU7QUFBRUosY0FBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCUixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CRSxLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDOUYsYUFBU0YsSUFBVCxDQUFjSSxNQUFkLEVBQXNCO0FBQUVBLFlBQU0sQ0FBQ0MsSUFBUCxHQUFjVCxPQUFPLENBQUNRLE1BQU0sQ0FBQ1QsS0FBUixDQUFyQixHQUFzQ0QsS0FBSyxDQUFDVSxNQUFNLENBQUNULEtBQVIsQ0FBTCxDQUFvQlcsSUFBcEIsQ0FBeUJQLFNBQXpCLEVBQW9DSSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdILFFBQUksQ0FBQyxDQUFDUCxTQUFTLEdBQUdBLFNBQVMsQ0FBQ2hCLEtBQVYsQ0FBZ0JhLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RFUsSUFBekQsRUFBRCxDQUFKO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FSRDs7QUFTQSxJQUFJTSxXQUFXLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsV0FBZCxJQUE4QixVQUFVakIsT0FBVixFQUFtQmtCLElBQW5CLEVBQXlCO0FBQ3JFLE1BQUlDLENBQUMsR0FBRztBQUFFQyxTQUFLLEVBQUUsQ0FBVDtBQUFZQyxRQUFJLEVBQUUsZ0JBQVc7QUFBRSxVQUFJeEMsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQVgsRUFBYyxNQUFNQSxDQUFDLENBQUMsQ0FBRCxDQUFQO0FBQVksYUFBT0EsQ0FBQyxDQUFDLENBQUQsQ0FBUjtBQUFjLEtBQXZFO0FBQXlFeUMsUUFBSSxFQUFFLEVBQS9FO0FBQW1GQyxPQUFHLEVBQUU7QUFBeEYsR0FBUjtBQUFBLE1BQXNHQyxDQUF0RztBQUFBLE1BQXlHQyxDQUF6RztBQUFBLE1BQTRHNUMsQ0FBNUc7QUFBQSxNQUErRzZDLENBQS9HO0FBQ0EsU0FBT0EsQ0FBQyxHQUFHO0FBQUVmLFFBQUksRUFBRWdCLElBQUksQ0FBQyxDQUFELENBQVo7QUFBaUIsYUFBU0EsSUFBSSxDQUFDLENBQUQsQ0FBOUI7QUFBbUMsY0FBVUEsSUFBSSxDQUFDLENBQUQ7QUFBakQsR0FBSixFQUE0RCxPQUFPQyxNQUFQLEtBQWtCLFVBQWxCLEtBQWlDRixDQUFDLENBQUNFLE1BQU0sQ0FBQ0MsUUFBUixDQUFELEdBQXFCLFlBQVc7QUFBRSxXQUFPLElBQVA7QUFBYyxHQUFqRixDQUE1RCxFQUFnSkgsQ0FBdko7O0FBQ0EsV0FBU0MsSUFBVCxDQUFjM0MsQ0FBZCxFQUFpQjtBQUFFLFdBQU8sVUFBVThDLENBQVYsRUFBYTtBQUFFLGFBQU9wQixJQUFJLENBQUMsQ0FBQzFCLENBQUQsRUFBSThDLENBQUosQ0FBRCxDQUFYO0FBQXNCLEtBQTVDO0FBQStDOztBQUNsRSxXQUFTcEIsSUFBVCxDQUFjcUIsRUFBZCxFQUFrQjtBQUNkLFFBQUlQLENBQUosRUFBTyxNQUFNLElBQUlsRCxTQUFKLENBQWMsaUNBQWQsQ0FBTjs7QUFDUCxXQUFPNkMsQ0FBUDtBQUFVLFVBQUk7QUFDVixZQUFJSyxDQUFDLEdBQUcsQ0FBSixFQUFPQyxDQUFDLEtBQUs1QyxDQUFDLEdBQUdrRCxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBUixHQUFZTixDQUFDLENBQUMsUUFBRCxDQUFiLEdBQTBCTSxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFOLENBQUMsQ0FBQyxPQUFELENBQUQsS0FBZSxDQUFDNUMsQ0FBQyxHQUFHNEMsQ0FBQyxDQUFDLFFBQUQsQ0FBTixLQUFxQjVDLENBQUMsQ0FBQ1IsSUFBRixDQUFPb0QsQ0FBUCxDQUFyQixFQUFnQyxDQUEvQyxDQUFSLEdBQTREQSxDQUFDLENBQUNkLElBQWpHLENBQUQsSUFBMkcsQ0FBQyxDQUFDOUIsQ0FBQyxHQUFHQSxDQUFDLENBQUNSLElBQUYsQ0FBT29ELENBQVAsRUFBVU0sRUFBRSxDQUFDLENBQUQsQ0FBWixDQUFMLEVBQXVCaEIsSUFBOUksRUFBb0osT0FBT2xDLENBQVA7QUFDcEosWUFBSTRDLENBQUMsR0FBRyxDQUFKLEVBQU81QyxDQUFYLEVBQWNrRCxFQUFFLEdBQUcsQ0FBQ0EsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVQsRUFBWWxELENBQUMsQ0FBQ3dCLEtBQWQsQ0FBTDs7QUFDZCxnQkFBUTBCLEVBQUUsQ0FBQyxDQUFELENBQVY7QUFDSSxlQUFLLENBQUw7QUFBUSxlQUFLLENBQUw7QUFBUWxELGFBQUMsR0FBR2tELEVBQUo7QUFBUTs7QUFDeEIsZUFBSyxDQUFMO0FBQVFaLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXLG1CQUFPO0FBQUVmLG1CQUFLLEVBQUUwQixFQUFFLENBQUMsQ0FBRCxDQUFYO0FBQWdCaEIsa0JBQUksRUFBRTtBQUF0QixhQUFQOztBQUNuQixlQUFLLENBQUw7QUFBUUksYUFBQyxDQUFDQyxLQUFGO0FBQVdLLGFBQUMsR0FBR00sRUFBRSxDQUFDLENBQUQsQ0FBTjtBQUFXQSxjQUFFLEdBQUcsQ0FBQyxDQUFELENBQUw7QUFBVTs7QUFDeEMsZUFBSyxDQUFMO0FBQVFBLGNBQUUsR0FBR1osQ0FBQyxDQUFDSSxHQUFGLENBQU1TLEdBQU4sRUFBTDs7QUFBa0JiLGFBQUMsQ0FBQ0csSUFBRixDQUFPVSxHQUFQOztBQUFjOztBQUN4QztBQUNJLGdCQUFJLEVBQUVuRCxDQUFDLEdBQUdzQyxDQUFDLENBQUNHLElBQU4sRUFBWXpDLENBQUMsR0FBR0EsQ0FBQyxDQUFDSyxNQUFGLEdBQVcsQ0FBWCxJQUFnQkwsQ0FBQyxDQUFDQSxDQUFDLENBQUNLLE1BQUYsR0FBVyxDQUFaLENBQW5DLE1BQXVENkMsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQWhGLENBQUosRUFBd0Y7QUFBRVosZUFBQyxHQUFHLENBQUo7QUFBTztBQUFXOztBQUM1RyxnQkFBSVksRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsS0FBZ0IsQ0FBQ2xELENBQUQsSUFBT2tELEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUWxELENBQUMsQ0FBQyxDQUFELENBQVQsSUFBZ0JrRCxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFsRCxDQUFDLENBQUMsQ0FBRCxDQUFoRCxDQUFKLEVBQTJEO0FBQUVzQyxlQUFDLENBQUNDLEtBQUYsR0FBVVcsRUFBRSxDQUFDLENBQUQsQ0FBWjtBQUFpQjtBQUFROztBQUN0RixnQkFBSUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZVosQ0FBQyxDQUFDQyxLQUFGLEdBQVV2QyxDQUFDLENBQUMsQ0FBRCxDQUE5QixFQUFtQztBQUFFc0MsZUFBQyxDQUFDQyxLQUFGLEdBQVV2QyxDQUFDLENBQUMsQ0FBRCxDQUFYO0FBQWdCQSxlQUFDLEdBQUdrRCxFQUFKO0FBQVE7QUFBUTs7QUFDckUsZ0JBQUlsRCxDQUFDLElBQUlzQyxDQUFDLENBQUNDLEtBQUYsR0FBVXZDLENBQUMsQ0FBQyxDQUFELENBQXBCLEVBQXlCO0FBQUVzQyxlQUFDLENBQUNDLEtBQUYsR0FBVXZDLENBQUMsQ0FBQyxDQUFELENBQVg7O0FBQWdCc0MsZUFBQyxDQUFDSSxHQUFGLENBQU1VLElBQU4sQ0FBV0YsRUFBWDs7QUFBZ0I7QUFBUTs7QUFDbkUsZ0JBQUlsRCxDQUFDLENBQUMsQ0FBRCxDQUFMLEVBQVVzQyxDQUFDLENBQUNJLEdBQUYsQ0FBTVMsR0FBTjs7QUFDVmIsYUFBQyxDQUFDRyxJQUFGLENBQU9VLEdBQVA7O0FBQWM7QUFYdEI7O0FBYUFELFVBQUUsR0FBR2IsSUFBSSxDQUFDN0MsSUFBTCxDQUFVMkIsT0FBVixFQUFtQm1CLENBQW5CLENBQUw7QUFDSCxPQWpCUyxDQWlCUixPQUFPUCxDQUFQLEVBQVU7QUFBRW1CLFVBQUUsR0FBRyxDQUFDLENBQUQsRUFBSW5CLENBQUosQ0FBTDtBQUFhYSxTQUFDLEdBQUcsQ0FBSjtBQUFRLE9BakJ6QixTQWlCa0M7QUFBRUQsU0FBQyxHQUFHM0MsQ0FBQyxHQUFHLENBQVI7QUFBWTtBQWpCMUQ7O0FBa0JBLFFBQUlrRCxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBWixFQUFlLE1BQU1BLEVBQUUsQ0FBQyxDQUFELENBQVI7QUFBYSxXQUFPO0FBQUUxQixXQUFLLEVBQUUwQixFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFBLEVBQUUsQ0FBQyxDQUFELENBQVYsR0FBZ0IsS0FBSyxDQUE5QjtBQUFpQ2hCLFVBQUksRUFBRTtBQUF2QyxLQUFQO0FBQy9CO0FBQ0osQ0ExQkQ7O0FBMkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSW1CLE1BQU0sR0FBR0MscURBQVMsQ0FBQyxPQUFELENBQXRCO0FBQ0EsSUFBSWtDLE1BQU0sR0FBR2xDLHFEQUFTLENBQUMsVUFBRCxDQUF0Qjs7QUFDQSxJQUFJOEIsZ0JBQWdCO0FBQUc7QUFBZSxVQUFVNUIsTUFBVixFQUFrQjtBQUNwRDNFLFdBQVMsQ0FBQ3VHLGdCQUFELEVBQW1CNUIsTUFBbkIsQ0FBVDs7QUFDQSxXQUFTNEIsZ0JBQVQsR0FBNEI7QUFDeEIsV0FBTzVCLE1BQU0sS0FBSyxJQUFYLElBQW1CQSxNQUFNLENBQUNsRCxLQUFQLENBQWEsSUFBYixFQUFtQkYsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDs7QUFDRGdGLGtCQUFnQixDQUFDOUYsU0FBakIsQ0FBMkJ1RSxPQUEzQixHQUFxQyxZQUFZO0FBQzdDLFdBQU8zQyxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxhQUFPa0IsV0FBVyxDQUFDLElBQUQsRUFBTyxVQUFVMEIsRUFBVixFQUFjO0FBQ25DLGdCQUFRQSxFQUFFLENBQUN2QixLQUFYO0FBQ0ksZUFBSyxDQUFMO0FBQVEsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxLQUFLa0QsV0FBTCxFQUFkLENBQVA7O0FBQ1IsZUFBSyxDQUFMO0FBQ0kzQixjQUFFLENBQUN0QixJQUFIOztBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7QUFKUjtBQU1ILE9BUGlCLENBQWxCO0FBUUgsS0FUZSxDQUFoQjtBQVVILEdBWEQ7O0FBWUE0QyxrQkFBZ0IsQ0FBQzlGLFNBQWpCLENBQTJCbUcsV0FBM0IsR0FBeUMsWUFBWTtBQUNqRCxXQUFPdkUsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT2tCLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVTBCLEVBQVYsRUFBYztBQUNuQyxhQUFLNEIsWUFBTDtBQUNBLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BSGlCLENBQWxCO0FBSUgsS0FMZSxDQUFoQjtBQU1ILEdBUEQ7O0FBUUFOLGtCQUFnQixDQUFDOUYsU0FBakIsQ0FBMkJxRyxRQUEzQixHQUFzQyxZQUFZO0FBQzlDLFdBQU96RSxTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxVQUFJMEUsUUFBSixFQUFjQyxXQUFkLEVBQTJCL0IsRUFBM0I7O0FBQ0EsYUFBTzFCLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVTBELEVBQVYsRUFBYztBQUNuQyxnQkFBUUEsRUFBRSxDQUFDdkQsS0FBWDtBQUNJLGVBQUssQ0FBTDtBQUNJdUQsY0FBRSxDQUFDckQsSUFBSCxDQUFRVyxJQUFSLENBQWEsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLENBQWI7O0FBQ0EsaUJBQUsyQyxVQUFMLENBQWdCLElBQWhCO0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBY0MsaURBQUEsQ0FBVyxrQkFBWCxFQUErQixLQUFLckMsSUFBcEMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJaUMsb0JBQVEsR0FBR0UsRUFBRSxDQUFDdEQsSUFBSCxFQUFYO0FBQ0FxRCx1QkFBVyxHQUFHSSw2REFBYSxDQUFDTCxRQUFELENBQTNCOztBQUNBLGdCQUFJQyxXQUFKLEVBQWlCO0FBQ2IsbUJBQUtLLFFBQUwsQ0FBY0MsS0FBZCxDQUFvQixFQUFwQixFQUF3QjtBQUNwQkMscUJBQUssRUFBRVAsV0FBVyxDQUFDUSxPQURDO0FBRXBCQyx1QkFBTyxFQUFFLFFBRlc7QUFHcEJDLHVCQUFPLEVBQUUsc0JBSFc7QUFJcEJDLHFCQUFLLEVBQUU7QUFKYSxlQUF4QjtBQU1ILGFBUEQsTUFRSztBQUNELG1CQUFLQyxXQUFMO0FBQ0g7O0FBQ0QsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7O0FBQ0osZUFBSyxDQUFMO0FBQ0kzQyxjQUFFLEdBQUdnQyxFQUFFLENBQUN0RCxJQUFILEVBQUw7QUFDQSxpQkFBSzBELFFBQUwsQ0FBY0MsS0FBZCxDQUFvQixFQUFwQixFQUF3QjtBQUNwQkMsbUJBQUssRUFBRSxLQUFLTSxFQUFMLENBQVEsc0JBQVIsQ0FEYTtBQUVwQkoscUJBQU8sRUFBRSxRQUZXO0FBR3BCQyxxQkFBTyxFQUFFLHNCQUhXO0FBSXBCQyxtQkFBSyxFQUFFO0FBSmEsYUFBeEI7QUFNQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLENBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSSxpQkFBS1QsVUFBTCxDQUFnQixLQUFoQjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7O0FBQ0osZUFBSyxDQUFMO0FBQVEsbUJBQU8sQ0FBQztBQUFFO0FBQUgsYUFBUDtBQWhDWjtBQWtDSCxPQW5DaUIsQ0FBbEI7QUFvQ0gsS0F0Q2UsQ0FBaEI7QUF1Q0gsR0F4Q0Q7O0FBeUNBWCxrQkFBZ0IsQ0FBQzlGLFNBQWpCLENBQTJCbUgsV0FBM0IsR0FBeUMsWUFBWTtBQUNqRCxTQUFLRSxpQ0FBTCxDQUF1QyxLQUF2QztBQUNILEdBRkQ7O0FBR0FwRyxZQUFVLENBQUMsQ0FDUHFHLDREQUFJLEVBREcsQ0FBRCxFQUVQeEIsZ0JBQWdCLENBQUM5RixTQUZWLEVBRXFCLE1BRnJCLEVBRTZCLEtBQUssQ0FGbEMsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQcUcsNERBQUksRUFERyxDQUFELEVBRVB4QixnQkFBZ0IsQ0FBQzlGLFNBRlYsRUFFcUIsV0FGckIsRUFFa0MsS0FBSyxDQUZ2QyxDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUMyQixNQURBLENBQUQsRUFFUEksZ0JBQWdCLENBQUM5RixTQUZWLEVBRXFCLG1DQUZyQixFQUUwRCxLQUFLLENBRi9ELENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzJCLE1BREEsQ0FBRCxFQUVQSSxnQkFBZ0IsQ0FBQzlGLFNBRlYsRUFFcUIsa0JBRnJCLEVBRXlDLEtBQUssQ0FGOUMsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDNEIsS0FEQSxDQUFELEVBRVBHLGdCQUFnQixDQUFDOUYsU0FGVixFQUVxQixnQkFGckIsRUFFdUMsS0FBSyxDQUY1QyxDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUM0QixLQURBLENBQUQsRUFFUEcsZ0JBQWdCLENBQUM5RixTQUZWLEVBRXFCLDRCQUZyQixFQUVtRCxLQUFLLENBRnhELENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUHlFLDhDQURPLENBQUQsRUFFUEksZ0JBQWdCLENBQUM5RixTQUZWLEVBRXFCLGtCQUZyQixFQUV5QyxLQUFLLENBRjlDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUGlGLE1BQU0sQ0FBQ1AsS0FEQSxDQUFELEVBRVBHLGdCQUFnQixDQUFDOUYsU0FGVixFQUVxQixVQUZyQixFQUVpQyxLQUFLLENBRnRDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUGlGLE1BQU0sQ0FBQ1IsTUFEQSxDQUFELEVBRVBJLGdCQUFnQixDQUFDOUYsU0FGVixFQUVxQixjQUZyQixFQUVxQyxLQUFLLENBRjFDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUGlGLE1BQU0sQ0FBQ1IsTUFEQSxDQUFELEVBRVBJLGdCQUFnQixDQUFDOUYsU0FGVixFQUVxQixZQUZyQixFQUVtQyxLQUFLLENBRnhDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUGlGLE1BQU0sQ0FBQ1AsS0FEQSxDQUFELEVBRVBHLGdCQUFnQixDQUFDOUYsU0FGVixFQUVxQixXQUZyQixFQUVrQyxLQUFLLENBRnZDLENBQVY7O0FBR0E4RixrQkFBZ0IsR0FBRzdFLFVBQVUsQ0FBQyxDQUMxQjJFLGlFQUFTLENBQUMsRUFBRCxDQURpQixDQUFELEVBRTFCRSxnQkFGMEIsQ0FBN0I7QUFHQSxTQUFPQSxnQkFBUDtBQUNILENBMUdxQyxDQTBHcENHLHVEQTFHb0MsQ0FBdEM7O0FBMkdBLGlFQUFlSCxnQkFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFLQSxJQUFJdkcsU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNkIsWUFBWTtBQUNyRCxNQUFJQyxjQUFhLEdBQUcsdUJBQVVDLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNoQ0Ysa0JBQWEsR0FBR0csTUFBTSxDQUFDQyxjQUFQLElBQ1g7QUFBRUMsZUFBUyxFQUFFO0FBQWIsaUJBQTZCQyxLQUE3QixJQUFzQyxVQUFVTCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFBRUQsT0FBQyxDQUFDSSxTQUFGLEdBQWNILENBQWQ7QUFBa0IsS0FEL0QsSUFFWixVQUFVRCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFBRSxXQUFLLElBQUlLLENBQVQsSUFBY0wsQ0FBZDtBQUFpQixZQUFJQyxNQUFNLENBQUNLLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQ1IsQ0FBckMsRUFBd0NLLENBQXhDLENBQUosRUFBZ0ROLENBQUMsQ0FBQ00sQ0FBRCxDQUFELEdBQU9MLENBQUMsQ0FBQ0ssQ0FBRCxDQUFSO0FBQWpFO0FBQStFLEtBRnJHOztBQUdBLFdBQU9QLGNBQWEsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLENBQXBCO0FBQ0gsR0FMRDs7QUFNQSxTQUFPLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNuQixRQUFJLE9BQU9BLENBQVAsS0FBYSxVQUFiLElBQTJCQSxDQUFDLEtBQUssSUFBckMsRUFDSSxNQUFNLElBQUlTLFNBQUosQ0FBYyx5QkFBeUJDLE1BQU0sQ0FBQ1YsQ0FBRCxDQUEvQixHQUFxQywrQkFBbkQsQ0FBTjs7QUFDSkYsa0JBQWEsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLENBQWI7O0FBQ0EsYUFBU1csRUFBVCxHQUFjO0FBQUUsV0FBS0MsV0FBTCxHQUFtQmIsQ0FBbkI7QUFBdUI7O0FBQ3ZDQSxLQUFDLENBQUNPLFNBQUYsR0FBY04sQ0FBQyxLQUFLLElBQU4sR0FBYUMsTUFBTSxDQUFDWSxNQUFQLENBQWNiLENBQWQsQ0FBYixJQUFpQ1csRUFBRSxDQUFDTCxTQUFILEdBQWVOLENBQUMsQ0FBQ00sU0FBakIsRUFBNEIsSUFBSUssRUFBSixFQUE3RCxDQUFkO0FBQ0gsR0FORDtBQU9ILENBZDJDLEVBQTVDOztBQWVBLElBQUlZLFVBQVUsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxVQUFkLElBQTZCLFVBQVVDLFVBQVYsRUFBc0JDLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0MsSUFBbkMsRUFBeUM7QUFDbkYsTUFBSUMsQ0FBQyxHQUFHUixTQUFTLENBQUNDLE1BQWxCO0FBQUEsTUFBMEJRLENBQUMsR0FBR0QsQ0FBQyxHQUFHLENBQUosR0FBUUgsTUFBUixHQUFpQkUsSUFBSSxLQUFLLElBQVQsR0FBZ0JBLElBQUksR0FBRzFCLE1BQU0sQ0FBQzZCLHdCQUFQLENBQWdDTCxNQUFoQyxFQUF3Q0MsR0FBeEMsQ0FBdkIsR0FBc0VDLElBQXJIO0FBQUEsTUFBMkg1QixDQUEzSDtBQUNBLE1BQUksUUFBT2dDLE9BQVAseUNBQU9BLE9BQVAsT0FBbUIsUUFBbkIsSUFBK0IsT0FBT0EsT0FBTyxDQUFDQyxRQUFmLEtBQTRCLFVBQS9ELEVBQTJFSCxDQUFDLEdBQUdFLE9BQU8sQ0FBQ0MsUUFBUixDQUFpQlIsVUFBakIsRUFBNkJDLE1BQTdCLEVBQXFDQyxHQUFyQyxFQUEwQ0MsSUFBMUMsQ0FBSixDQUEzRSxLQUNLLEtBQUssSUFBSVQsQ0FBQyxHQUFHTSxVQUFVLENBQUNILE1BQVgsR0FBb0IsQ0FBakMsRUFBb0NILENBQUMsSUFBSSxDQUF6QyxFQUE0Q0EsQ0FBQyxFQUE3QztBQUFpRCxRQUFJbkIsQ0FBQyxHQUFHeUIsVUFBVSxDQUFDTixDQUFELENBQWxCLEVBQXVCVyxDQUFDLEdBQUcsQ0FBQ0QsQ0FBQyxHQUFHLENBQUosR0FBUTdCLENBQUMsQ0FBQzhCLENBQUQsQ0FBVCxHQUFlRCxDQUFDLEdBQUcsQ0FBSixHQUFRN0IsQ0FBQyxDQUFDMEIsTUFBRCxFQUFTQyxHQUFULEVBQWNHLENBQWQsQ0FBVCxHQUE0QjlCLENBQUMsQ0FBQzBCLE1BQUQsRUFBU0MsR0FBVCxDQUE3QyxLQUErREcsQ0FBbkU7QUFBeEU7QUFDTCxTQUFPRCxDQUFDLEdBQUcsQ0FBSixJQUFTQyxDQUFULElBQWM1QixNQUFNLENBQUNnQyxjQUFQLENBQXNCUixNQUF0QixFQUE4QkMsR0FBOUIsRUFBbUNHLENBQW5DLENBQWQsRUFBcURBLENBQTVEO0FBQ0gsQ0FMRDs7QUFNQTtBQUNBO0FBQ0E7QUFDQSxJQUFJd0MsTUFBTSxHQUFHQyxxREFBUyxDQUFDLE9BQUQsQ0FBdEI7O0FBQ0EsSUFBSStCLFNBQVM7QUFBRztBQUFlLFVBQVU3QixNQUFWLEVBQWtCO0FBQzdDM0UsV0FBUyxDQUFDd0csU0FBRCxFQUFZN0IsTUFBWixDQUFUOztBQUNBLFdBQVM2QixTQUFULEdBQXFCO0FBQ2pCLFdBQU83QixNQUFNLEtBQUssSUFBWCxJQUFtQkEsTUFBTSxDQUFDbEQsS0FBUCxDQUFhLElBQWIsRUFBbUJGLFNBQW5CLENBQW5CLElBQW9ELElBQTNEO0FBQ0g7O0FBQ0RuQixRQUFNLENBQUNnQyxjQUFQLENBQXNCb0UsU0FBUyxDQUFDL0YsU0FBaEMsRUFBMkMsWUFBM0MsRUFBeUQ7QUFDckR1SCxPQUFHLEVBQUUsZUFBWTtBQUNiLGFBQU8sS0FBS0MsTUFBTCxDQUFZQyxLQUFaLENBQWtCQyxJQUFsQixDQUF1QnRDLElBQTlCO0FBQ0gsS0FIb0Q7QUFJckR1QyxjQUFVLEVBQUUsS0FKeUM7QUFLckRDLGdCQUFZLEVBQUU7QUFMdUMsR0FBekQ7O0FBT0E3QixXQUFTLENBQUMvRixTQUFWLENBQW9CNkgsc0JBQXBCLEdBQTZDLFVBQVV6QyxJQUFWLEVBQWdCO0FBQ3pELFNBQUswQyxjQUFMLENBQW9CMUMsSUFBcEI7QUFDQSxTQUFLaUMsaUNBQUwsQ0FBdUMsSUFBdkM7QUFDSCxHQUhEOztBQUlBcEcsWUFBVSxDQUFDLENBQ1BxRyw0REFBSSxFQURHLENBQUQsRUFFUHZCLFNBQVMsQ0FBQy9GLFNBRkgsRUFFYyxNQUZkLEVBRXNCLEtBQUssQ0FGM0IsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDMkIsTUFEQSxDQUFELEVBRVBLLFNBQVMsQ0FBQy9GLFNBRkgsRUFFYyxtQ0FGZCxFQUVtRCxLQUFLLENBRnhELENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzJCLE1BREEsQ0FBRCxFQUVQSyxTQUFTLENBQUMvRixTQUZILEVBRWMsZ0JBRmQsRUFFZ0MsS0FBSyxDQUZyQyxDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1A4QyxNQUFNLENBQUM0QixLQURBLENBQUQsRUFFUEksU0FBUyxDQUFDL0YsU0FGSCxFQUVjLDRCQUZkLEVBRTRDLEtBQUssQ0FGakQsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDNEIsS0FEQSxDQUFELEVBRVBJLFNBQVMsQ0FBQy9GLFNBRkgsRUFFYyxhQUZkLEVBRTZCLEtBQUssQ0FGbEMsQ0FBVjs7QUFHQStGLFdBQVMsR0FBRzlFLFVBQVUsQ0FBQyxDQUNuQjJFLGlFQUFTLENBQUM7QUFDTkMsY0FBVSxFQUFFO0FBQ1JrQyxxQkFBZSxFQUFFQSwwREFEVDtBQUVSQyxvQkFBYyxFQUFFQSx5REFBY0E7QUFGdEI7QUFETixHQUFELENBRFUsQ0FBRCxFQU9uQmpDLFNBUG1CLENBQXRCO0FBUUEsU0FBT0EsU0FBUDtBQUNILENBeEM4QixDQXdDN0JFLHVEQXhDNkIsQ0FBL0I7O0FBeUNBLGlFQUFlRixTQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVBLElBQUl4RyxTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE2QixZQUFZO0FBQ3JELE1BQUlDLGNBQWEsR0FBRyx1QkFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ2hDRixrQkFBYSxHQUFHRyxNQUFNLENBQUNDLGNBQVAsSUFDWDtBQUFFQyxlQUFTLEVBQUU7QUFBYixpQkFBNkJDLEtBQTdCLElBQXNDLFVBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFRCxPQUFDLENBQUNJLFNBQUYsR0FBY0gsQ0FBZDtBQUFrQixLQUQvRCxJQUVaLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFLFdBQUssSUFBSUssQ0FBVCxJQUFjTCxDQUFkO0FBQWlCLFlBQUlDLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUixDQUFyQyxFQUF3Q0ssQ0FBeEMsQ0FBSixFQUFnRE4sQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBT0wsQ0FBQyxDQUFDSyxDQUFELENBQVI7QUFBakU7QUFBK0UsS0FGckc7O0FBR0EsV0FBT1AsY0FBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBcEI7QUFDSCxHQUxEOztBQU1BLFNBQU8sVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ25CLFFBQUksT0FBT0EsQ0FBUCxLQUFhLFVBQWIsSUFBMkJBLENBQUMsS0FBSyxJQUFyQyxFQUNJLE1BQU0sSUFBSVMsU0FBSixDQUFjLHlCQUF5QkMsTUFBTSxDQUFDVixDQUFELENBQS9CLEdBQXFDLCtCQUFuRCxDQUFOOztBQUNKRixrQkFBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBYjs7QUFDQSxhQUFTVyxFQUFULEdBQWM7QUFBRSxXQUFLQyxXQUFMLEdBQW1CYixDQUFuQjtBQUF1Qjs7QUFDdkNBLEtBQUMsQ0FBQ08sU0FBRixHQUFjTixDQUFDLEtBQUssSUFBTixHQUFhQyxNQUFNLENBQUNZLE1BQVAsQ0FBY2IsQ0FBZCxDQUFiLElBQWlDVyxFQUFFLENBQUNMLFNBQUgsR0FBZU4sQ0FBQyxDQUFDTSxTQUFqQixFQUE0QixJQUFJSyxFQUFKLEVBQTdELENBQWQ7QUFDSCxHQU5EO0FBT0gsQ0FkMkMsRUFBNUM7O0FBZUEsSUFBSVksVUFBVSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFVBQWQsSUFBNkIsVUFBVUMsVUFBVixFQUFzQkMsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DQyxJQUFuQyxFQUF5QztBQUNuRixNQUFJQyxDQUFDLEdBQUdSLFNBQVMsQ0FBQ0MsTUFBbEI7QUFBQSxNQUEwQlEsQ0FBQyxHQUFHRCxDQUFDLEdBQUcsQ0FBSixHQUFRSCxNQUFSLEdBQWlCRSxJQUFJLEtBQUssSUFBVCxHQUFnQkEsSUFBSSxHQUFHMUIsTUFBTSxDQUFDNkIsd0JBQVAsQ0FBZ0NMLE1BQWhDLEVBQXdDQyxHQUF4QyxDQUF2QixHQUFzRUMsSUFBckg7QUFBQSxNQUEySDVCLENBQTNIO0FBQ0EsTUFBSSxRQUFPZ0MsT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUFuQixJQUErQixPQUFPQSxPQUFPLENBQUNDLFFBQWYsS0FBNEIsVUFBL0QsRUFBMkVILENBQUMsR0FBR0UsT0FBTyxDQUFDQyxRQUFSLENBQWlCUixVQUFqQixFQUE2QkMsTUFBN0IsRUFBcUNDLEdBQXJDLEVBQTBDQyxJQUExQyxDQUFKLENBQTNFLEtBQ0ssS0FBSyxJQUFJVCxDQUFDLEdBQUdNLFVBQVUsQ0FBQ0gsTUFBWCxHQUFvQixDQUFqQyxFQUFvQ0gsQ0FBQyxJQUFJLENBQXpDLEVBQTRDQSxDQUFDLEVBQTdDO0FBQWlELFFBQUluQixDQUFDLEdBQUd5QixVQUFVLENBQUNOLENBQUQsQ0FBbEIsRUFBdUJXLENBQUMsR0FBRyxDQUFDRCxDQUFDLEdBQUcsQ0FBSixHQUFRN0IsQ0FBQyxDQUFDOEIsQ0FBRCxDQUFULEdBQWVELENBQUMsR0FBRyxDQUFKLEdBQVE3QixDQUFDLENBQUMwQixNQUFELEVBQVNDLEdBQVQsRUFBY0csQ0FBZCxDQUFULEdBQTRCOUIsQ0FBQyxDQUFDMEIsTUFBRCxFQUFTQyxHQUFULENBQTdDLEtBQStERyxDQUFuRTtBQUF4RTtBQUNMLFNBQU9ELENBQUMsR0FBRyxDQUFKLElBQVNDLENBQVQsSUFBYzVCLE1BQU0sQ0FBQ2dDLGNBQVAsQ0FBc0JSLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0csQ0FBbkMsQ0FBZCxFQUFxREEsQ0FBNUQ7QUFDSCxDQUxEOztBQU1BO0FBQ0E7QUFDQTtBQUNBLElBQUl3QyxNQUFNLEdBQUdDLHFEQUFTLENBQUMsT0FBRCxDQUF0Qjs7QUFDQSxJQUFJZ0MsVUFBVTtBQUFHO0FBQWUsVUFBVTlCLE1BQVYsRUFBa0I7QUFDOUMzRSxXQUFTLENBQUN5RyxVQUFELEVBQWE5QixNQUFiLENBQVQ7O0FBQ0EsV0FBUzhCLFVBQVQsR0FBc0I7QUFDbEIsV0FBTzlCLE1BQU0sS0FBSyxJQUFYLElBQW1CQSxNQUFNLENBQUNsRCxLQUFQLENBQWEsSUFBYixFQUFtQkYsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDs7QUFDRGtGLFlBQVUsQ0FBQ2hHLFNBQVgsQ0FBcUJxRyxRQUFyQixHQUFnQyxZQUFZO0FBQ3hDLFFBQUksQ0FBQzRCLDZEQUFhLENBQUMsS0FBSzVELElBQU4sQ0FBbEIsRUFBK0I7QUFDM0I7QUFDSDs7QUFDRCxRQUFJLEtBQUs2RCxLQUFULEVBQWdCO0FBQ1osV0FBS3JELE9BQUwsQ0FBYSxLQUFLUixJQUFsQjtBQUNILEtBRkQsTUFHSztBQUNELFdBQUtjLFFBQUwsQ0FBYyxLQUFLZCxJQUFuQjtBQUNIO0FBQ0osR0FWRDs7QUFXQTJCLFlBQVUsQ0FBQ2hHLFNBQVgsQ0FBcUJtSCxXQUFyQixHQUFtQyxZQUFZO0FBQzNDLFNBQUtsQyxlQUFMLENBQXFCLEtBQXJCO0FBQ0gsR0FGRDs7QUFHQWhFLFlBQVUsQ0FBQyxDQUNQcUcsNERBQUksRUFERyxDQUFELEVBRVB0QixVQUFVLENBQUNoRyxTQUZKLEVBRWUsTUFGZixFQUV1QixLQUFLLENBRjVCLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUHFHLDREQUFJLEVBREcsQ0FBRCxFQUVQdEIsVUFBVSxDQUFDaEcsU0FGSixFQUVlLE9BRmYsRUFFd0IsS0FBSyxDQUY3QixDQUFWOztBQUdBaUIsWUFBVSxDQUFDLENBQ1BxRyw0REFBSSxFQURHLENBQUQsRUFFUHRCLFVBQVUsQ0FBQ2hHLFNBRkosRUFFZSxXQUZmLEVBRTRCLEtBQUssQ0FGakMsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDMkIsTUFEQSxDQUFELEVBRVBNLFVBQVUsQ0FBQ2hHLFNBRkosRUFFZSxTQUZmLEVBRTBCLEtBQUssQ0FGL0IsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDMkIsTUFEQSxDQUFELEVBRVBNLFVBQVUsQ0FBQ2hHLFNBRkosRUFFZSxVQUZmLEVBRTJCLEtBQUssQ0FGaEMsQ0FBVjs7QUFHQWlCLFlBQVUsQ0FBQyxDQUNQOEMsTUFBTSxDQUFDMkIsTUFEQSxDQUFELEVBRVBNLFVBQVUsQ0FBQ2hHLFNBRkosRUFFZSxpQkFGZixFQUVrQyxLQUFLLENBRnZDLENBQVY7O0FBR0FpQixZQUFVLENBQUMsQ0FDUDhDLE1BQU0sQ0FBQzRCLEtBREEsQ0FBRCxFQUVQSyxVQUFVLENBQUNoRyxTQUZKLEVBRWUsZ0JBRmYsRUFFaUMsS0FBSyxDQUZ0QyxDQUFWOztBQUdBZ0csWUFBVSxHQUFHL0UsVUFBVSxDQUFDLENBQ3BCMkUsNkRBRG9CLENBQUQsRUFFcEJJLFVBRm9CLENBQXZCO0FBR0EsU0FBT0EsVUFBUDtBQUNILENBNUMrQixDQTRDOUJDLHVEQTVDOEIsQ0FBaEM7O0FBNkNBLGlFQUFlRCxVQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RUE7QUFDcUk7QUFDN0I7QUFDeEcsOEJBQThCLG1GQUEyQixDQUFDLHdHQUFxQztBQUMvRjtBQUNBLHlFQUF5RSxrQkFBa0IsOEJBQThCLEdBQUcsd0NBQXdDLGtCQUFrQix3QkFBd0IsR0FBRyxPQUFPLDZIQUE2SCxVQUFVLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxnS0FBZ0ssb0JBQW9CLGdDQUFnQyxjQUFjLHNCQUFzQiw0QkFBNEIsT0FBTyxLQUFLLHVCQUF1QjtBQUNsc0I7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BzRDtBQUNwQztBQUNMOzs7QUFHcEQ7QUFDQSxDQUFtRztBQUNuRyxnQkFBZ0Isb0dBQVU7QUFDMUIsRUFBRSx3RUFBTTtBQUNSLEVBQUUsc0ZBQU07QUFDUixFQUFFLCtGQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsSUFBSSxLQUFVLEVBQUUsWUFpQmY7QUFDRDtBQUNBLGlFQUFlLGlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q3lGO0FBQ3BDO0FBQ0w7OztBQUcvRDtBQUNBLENBQXNHO0FBQ3RHLGdCQUFnQixvR0FBVTtBQUMxQixFQUFFLG1GQUFNO0FBQ1IsRUFBRSxpR0FBTTtBQUNSLEVBQUUsMEdBQWU7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxJQUFJLEtBQVUsRUFBRSxZQWlCZjtBQUNEO0FBQ0EsaUVBQWUsaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QzhGO0FBQ2hEO0FBQ0w7QUFDeEQsQ0FBOEY7OztBQUc5RjtBQUNzRztBQUN0RyxnQkFBZ0Isb0dBQVU7QUFDMUIsRUFBRSw0RUFBTTtBQUNSLEVBQUUsc0dBQU07QUFDUixFQUFFLCtHQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsSUFBSSxLQUFVLEVBQUUsWUFpQmY7QUFDRDtBQUNBLGlFQUFlLGlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2Q21GO0FBQ3BDO0FBQ0w7OztBQUd6RDtBQUNBLENBQXNHO0FBQ3RHLGdCQUFnQixvR0FBVTtBQUMxQixFQUFFLDZFQUFNO0FBQ1IsRUFBRSwyRkFBTTtBQUNSLEVBQUUsb0dBQWU7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxJQUFJLEtBQVUsRUFBRSxZQWlCZjtBQUNEO0FBQ0EsaUVBQWUsaUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q3lSLENBQUMsaUVBQWUsa1FBQUcsRUFBQyxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsQ0FBQyxpRUFBZSw2UUFBRyxFQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBM0IsQ0FBQyxpRUFBZSxzUUFBRyxFQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBbkIsQ0FBQyxpRUFBZSx1UUFBRyxFQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTFVO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssU0FBUyxjQUFjLEVBQUU7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsaUJBQWlCLHVCQUF1QjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSx1QkFBdUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGFBQWE7QUFDckM7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLGlCQUFpQix1QkFBdUI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixTQUFTLFVBQVUsRUFBRTtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsbUJBQW1CO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLGlCQUFpQixvQkFBb0IsRUFBRTtBQUN4RTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEMseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsU0FBUyxVQUFVLEVBQUU7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLHlDQUF5QyxnQkFBZ0IsRUFBRTtBQUNoRTtBQUNBLGdCQUFnQixTQUFTLGlCQUFpQixrQkFBa0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLDJCQUEyQjtBQUM1QyxzQkFBc0Isa0NBQWtDO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGtDQUFrQztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IscUJBQXFCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixrQkFBa0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLGtCQUFrQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsU0FBUyxxREFBcUQsRUFBRTtBQUM3RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxTQUFTLHVEQUF1RCxFQUFFO0FBQy9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxTQUFTLG1DQUFtQyxFQUFFO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLGtCQUFrQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0Esc0NBQXNDLFNBQVMsYUFBYSxFQUFFO0FBQzlEO0FBQ0E7QUFDQSxzQ0FBc0MsU0FBUyxhQUFhLEVBQUU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDM05BOztBQUVBO0FBQ0EsY0FBYyxtQkFBTyxDQUFDLDg4QkFBdWY7QUFDN2dCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSxvS0FBMEY7QUFDcEcsK0NBQStDO0FBQy9DO0FBQ0EsR0FBRyxLQUFVLEVBQUUsRSIsImZpbGUiOiJqcy9yZXNvdXJjZXNfYXNzZXRzX3Z1ZV92aWV3c191c2Vyc19Vc2Vyc192dWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IChmdW5jdGlvbiAoKSB7XHJcbiAgICB2YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChiLCBwKSkgZFtwXSA9IGJbcF07IH07XHJcbiAgICAgICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBiICE9PSBcImZ1bmN0aW9uXCIgJiYgYiAhPT0gbnVsbClcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNsYXNzIGV4dGVuZHMgdmFsdWUgXCIgKyBTdHJpbmcoYikgKyBcIiBpcyBub3QgYSBjb25zdHJ1Y3RvciBvciBudWxsXCIpO1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICAgICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICAgICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xyXG4gICAgfTtcclxufSkoKTtcclxudmFyIF9fYXNzaWduID0gKHRoaXMgJiYgdGhpcy5fX2Fzc2lnbikgfHwgZnVuY3Rpb24gKCkge1xyXG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uKHQpIHtcclxuICAgICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcclxuICAgICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcclxuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKVxyXG4gICAgICAgICAgICAgICAgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfTtcclxuICAgIHJldHVybiBfX2Fzc2lnbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG59O1xyXG52YXIgX19kZWNvcmF0ZSA9ICh0aGlzICYmIHRoaXMuX19kZWNvcmF0ZSkgfHwgZnVuY3Rpb24gKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59O1xyXG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xyXG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcclxuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XHJcbiAgICAgICAgd2hpbGUgKF8pIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcclxuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cclxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcclxuICAgIH1cclxufTtcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBWdWUgfSBmcm9tICd2dWUtcHJvcGVydHktZGVjb3JhdG9yJztcclxuaW1wb3J0IHsgQWN0aW9uLCBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IGRpYWxvZyBmcm9tICdAL3V0aWxzL2RpYWxvZyc7XHJcbmltcG9ydCBVc2Vyc0NhcmQgZnJvbSAnLi9jb21wb25lbnRzL1VzZXJzQ2FyZC52dWUnO1xyXG5pbXBvcnQgVXNlcnNNb2RhbCBmcm9tICcuL2NvbXBvbmVudHMvVXNlcnNNb2RhbC52dWUnO1xyXG5pbXBvcnQgQWRkUHJvZHVjdFRvVXNlciBmcm9tICdAL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvQWRkUHJvZHVjdFRvVXNlci52dWUnO1xyXG52YXIgdVN0b3JlID0gbmFtZXNwYWNlKCd1c2VycycpO1xyXG52YXIgVXNlcnMgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XHJcbiAgICBfX2V4dGVuZHMoVXNlcnMsIF9zdXBlcik7XHJcbiAgICBmdW5jdGlvbiBVc2VycygpIHtcclxuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIgIT09IG51bGwgJiYgX3N1cGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgfHwgdGhpcztcclxuICAgICAgICBfdGhpcy5jdXJyZW50UGFnZSA9IDE7XHJcbiAgICAgICAgX3RoaXMuZm9ybSA9IHt9O1xyXG4gICAgICAgIF90aGlzLmlzTW9kYWxBZGQgPSB0cnVlO1xyXG4gICAgICAgIHJldHVybiBfdGhpcztcclxuICAgIH1cclxuICAgIFVzZXJzLnByb3RvdHlwZS5jcmVhdGVkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRCYWNrVXJsKCcvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0TWVudShbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiAnYWRkX3VzZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICd1c2Vycy5hZGRfdXNlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlcjogdGhpcy5hZGRVc2VyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFBhZ2UgPSB0aGlzLnBhZ2luYXRpb24uY3VycmVudFBhZ2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKHRoaXMudXNlcnMubGVuZ3RoID09IDApKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRVc2VycygxKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gMjtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6IHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgVXNlcnMucHJvdG90eXBlLmFkZFVzZXIgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5pc01vZGFsQWRkID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnNldE1vZGFsVmlzaWJsZSh0cnVlKTtcclxuICAgICAgICB0aGlzLmZvcm0gPSB7XHJcbiAgICAgICAgICAgIHR5cGVfaWQ6IDIsXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcbiAgICBVc2Vycy5wcm90b3R5cGUuZWRpdFVzZXIgPSBmdW5jdGlvbiAodXNlcikge1xyXG4gICAgICAgIHRoaXMuaXNNb2RhbEFkZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuc2V0TW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gICAgICAgIHRoaXMuZm9ybSA9IF9fYXNzaWduKHt9LCB1c2VyKTtcclxuICAgIH07XHJcbiAgICBVc2Vycy5wcm90b3R5cGUuZGVsZXRlVXNlckNvbmZpcm0gPSBmdW5jdGlvbiAodXNlcikge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgZGlhbG9nKCdmcm9udC5kZWxldGVfdXNlcl9jb25maXJtYXRpb24nLCB0cnVlKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIShfYS5zZW50KCkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWxldGVVc2VyKHVzZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIFVzZXJzLnByb3RvdHlwZS5nZXRVc2VycyA9IGZ1bmN0aW9uIChwYWdlKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRVc2Vycyh7IHBhZ2U6IHBhZ2UgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgVXNlcnMucHJvdG90eXBlLCBcInNldEJhY2tVcmxcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgVXNlcnMucHJvdG90eXBlLCBcInNldE1lbnVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgVXNlcnMucHJvdG90eXBlLCBcInVzZXJzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuU3RhdGVcclxuICAgIF0sIFVzZXJzLnByb3RvdHlwZSwgXCJwYWdpbmF0aW9uXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuU3RhdGVcclxuICAgIF0sIFVzZXJzLnByb3RvdHlwZSwgXCJpc0xvYWRpbmdcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgVXNlcnMucHJvdG90eXBlLCBcImlzTW9kYWxWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuU3RhdGVcclxuICAgIF0sIFVzZXJzLnByb3RvdHlwZSwgXCJpc01vZGFsVG9BZGRQcm9kdWN0VmlzaWJsZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgdVN0b3JlLlN0YXRlXHJcbiAgICBdLCBVc2Vycy5wcm90b3R5cGUsIFwiZm9ybVByb2R1Y3RcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIFVzZXJzLnByb3RvdHlwZSwgXCJkZWxldGVVc2VyXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBVc2Vycy5wcm90b3R5cGUsIFwibG9hZFVzZXJzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBVc2Vycy5wcm90b3R5cGUsIFwic2V0TW9kYWxWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBVc2Vycy5wcm90b3R5cGUsIFwic2V0Rm9ybVByb2R1Y3RcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIFVzZXJzLnByb3RvdHlwZSwgXCJzZXRNb2RhbFRvQWRkUHJvZHVjdFRvVXNlclZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIFVzZXJzID0gX19kZWNvcmF0ZShbXHJcbiAgICAgICAgQ29tcG9uZW50KHtcclxuICAgICAgICAgICAgY29tcG9uZW50czoge1xyXG4gICAgICAgICAgICAgICAgQWRkUHJvZHVjdFRvVXNlcjogQWRkUHJvZHVjdFRvVXNlcixcclxuICAgICAgICAgICAgICAgIFVzZXJzQ2FyZDogVXNlcnNDYXJkLFxyXG4gICAgICAgICAgICAgICAgVXNlcnNNb2RhbDogVXNlcnNNb2RhbCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgXSwgVXNlcnMpO1xyXG4gICAgcmV0dXJuIFVzZXJzO1xyXG59KFZ1ZSkpO1xyXG5leHBvcnQgZGVmYXVsdCBVc2VycztcclxuIiwidmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2RlY29yYXRlID0gKHRoaXMgJiYgdGhpcy5fX2RlY29yYXRlKSB8fCBmdW5jdGlvbiAoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn07XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFByb3AsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBBY3Rpb24sIG5hbWVzcGFjZSB9IGZyb20gJ3Z1ZXgtY2xhc3MnO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgY2hlY2tSZXNwb25zZSBmcm9tICdAL3V0aWxzL2NoZWNrUmVzcG9uc2UnO1xyXG52YXIgdVN0b3JlID0gbmFtZXNwYWNlKCd1c2VycycpO1xyXG52YXIgcFN0b3JlID0gbmFtZXNwYWNlKCdwcm9kdWN0cycpO1xyXG52YXIgQWRkUHJvZHVjdFRvVXNlciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhBZGRQcm9kdWN0VG9Vc2VyLCBfc3VwZXIpO1xyXG4gICAgZnVuY3Rpb24gQWRkUHJvZHVjdFRvVXNlcigpIHtcclxuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XHJcbiAgICB9XHJcbiAgICBBZGRQcm9kdWN0VG9Vc2VyLnByb3RvdHlwZS5jcmVhdGVkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRQcm9kdWN0cygpXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBBZGRQcm9kdWN0VG9Vc2VyLnByb3RvdHlwZS5nZXRQcm9kdWN0cyA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubG9hZFByb2R1Y3RzKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIEFkZFByb2R1Y3RUb1VzZXIucHJvdG90eXBlLmhhbmRsZU9rID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgdmFyIHJlc3BvbnNlLCBjaGVja0Vycm9ycywgX2E7XHJcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2IubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9iLnRyeXMucHVzaChbMCwgMiwgMywgNF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGF4aW9zLnBvc3QoJ3VzZXIvYWRkL3Byb2R1Y3QnLCB0aGlzLmZvcm0pXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja0Vycm9ycyA9IGNoZWNrUmVzcG9uc2UocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2hlY2tFcnJvcnMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGJ2VG9hc3QudG9hc3QoJycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogY2hlY2tFcnJvcnMubWVzc2FnZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiAnZGFuZ2VyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b2FzdGVyOiAnYi10b2FzdGVyLXRvcC1jZW50ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvbGlkOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlQ2xvc2UoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA0XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hID0gX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRidlRvYXN0LnRvYXN0KCcnLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy4kdCgnZXJyb3JzLmdlbmVyaWNfZXJyb3InKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6ICdkYW5nZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3RlcjogJ2ItdG9hc3Rlci10b3AtY2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvbGlkOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA0XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNyAvKmVuZGZpbmFsbHkqL107XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSA0OiByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIEFkZFByb2R1Y3RUb1VzZXIucHJvdG90eXBlLmhhbmRsZUNsb3NlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuc2V0TW9kYWxUb0FkZFByb2R1Y3RUb1VzZXJWaXNpYmxlKGZhbHNlKTtcclxuICAgIH07XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBQcm9wKClcclxuICAgIF0sIEFkZFByb2R1Y3RUb1VzZXIucHJvdG90eXBlLCBcImZvcm1cIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIFByb3AoKVxyXG4gICAgXSwgQWRkUHJvZHVjdFRvVXNlci5wcm90b3R5cGUsIFwiaXNWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBBZGRQcm9kdWN0VG9Vc2VyLnByb3RvdHlwZSwgXCJzZXRNb2RhbFRvQWRkUHJvZHVjdFRvVXNlclZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIEFkZFByb2R1Y3RUb1VzZXIucHJvdG90eXBlLCBcImFkZFByb2R1Y3RUb1VzZXJcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgQWRkUHJvZHVjdFRvVXNlci5wcm90b3R5cGUsIFwiaXNNb2RhbExvYWRpbmdcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgQWRkUHJvZHVjdFRvVXNlci5wcm90b3R5cGUsIFwiaXNNb2RhbFRvQWRkUHJvZHVjdFZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgQWRkUHJvZHVjdFRvVXNlci5wcm90b3R5cGUsIFwic2V0RGlhbG9nTWVzc2FnZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLlN0YXRlXHJcbiAgICBdLCBBZGRQcm9kdWN0VG9Vc2VyLnByb3RvdHlwZSwgXCJwcm9kdWN0c1wiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgcFN0b3JlLkFjdGlvblxyXG4gICAgXSwgQWRkUHJvZHVjdFRvVXNlci5wcm90b3R5cGUsIFwibG9hZFByb2R1Y3RzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuQWN0aW9uXHJcbiAgICBdLCBBZGRQcm9kdWN0VG9Vc2VyLnByb3RvdHlwZSwgXCJzZXRMb2FkaW5nXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBwU3RvcmUuU3RhdGVcclxuICAgIF0sIEFkZFByb2R1Y3RUb1VzZXIucHJvdG90eXBlLCBcImlzTG9hZGluZ1wiLCB2b2lkIDApO1xyXG4gICAgQWRkUHJvZHVjdFRvVXNlciA9IF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIENvbXBvbmVudCh7fSlcclxuICAgIF0sIEFkZFByb2R1Y3RUb1VzZXIpO1xyXG4gICAgcmV0dXJuIEFkZFByb2R1Y3RUb1VzZXI7XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IEFkZFByb2R1Y3RUb1VzZXI7XHJcbiIsInZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgKGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgICAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIH07XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2xhc3MgZXh0ZW5kcyB2YWx1ZSBcIiArIFN0cmluZyhiKSArIFwiIGlzIG5vdCBhIGNvbnN0cnVjdG9yIG9yIG51bGxcIik7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgICAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbiAgICB9O1xyXG59KSgpO1xyXG52YXIgX19kZWNvcmF0ZSA9ICh0aGlzICYmIHRoaXMuX19kZWNvcmF0ZSkgfHwgZnVuY3Rpb24gKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFByb3AsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBCSWNvblBlbmNpbEZpbGwsIEJJY29uVHJhc2hGaWxsIH0gZnJvbSAnYm9vdHN0cmFwLXZ1ZSc7XHJcbmltcG9ydCB7IG5hbWVzcGFjZSB9IGZyb20gJ3Z1ZXgtY2xhc3MnO1xyXG52YXIgdVN0b3JlID0gbmFtZXNwYWNlKCd1c2VycycpO1xyXG52YXIgVXNlcnNDYXJkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xyXG4gICAgX19leHRlbmRzKFVzZXJzQ2FyZCwgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIFVzZXJzQ2FyZCgpIHtcclxuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XHJcbiAgICB9XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoVXNlcnNDYXJkLnByb3RvdHlwZSwgXCJhY3R1YWxVc2VyXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHN0b3JlLnN0YXRlLmF1dGgudXNlcjtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBVc2Vyc0NhcmQucHJvdG90eXBlLmhhbmRsZUFkZFByb2R1Y3RUb1VzZXIgPSBmdW5jdGlvbiAodXNlcikge1xyXG4gICAgICAgIHRoaXMuc2V0Rm9ybVByb2R1Y3QodXNlcik7XHJcbiAgICAgICAgdGhpcy5zZXRNb2RhbFRvQWRkUHJvZHVjdFRvVXNlclZpc2libGUodHJ1ZSk7XHJcbiAgICB9O1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgUHJvcCgpXHJcbiAgICBdLCBVc2Vyc0NhcmQucHJvdG90eXBlLCBcInVzZXJcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIFVzZXJzQ2FyZC5wcm90b3R5cGUsIFwic2V0TW9kYWxUb0FkZFByb2R1Y3RUb1VzZXJWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBVc2Vyc0NhcmQucHJvdG90eXBlLCBcInNldEZvcm1Qcm9kdWN0XCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuU3RhdGVcclxuICAgIF0sIFVzZXJzQ2FyZC5wcm90b3R5cGUsIFwiaXNNb2RhbFRvQWRkUHJvZHVjdFZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgVXNlcnNDYXJkLnByb3RvdHlwZSwgXCJmb3JtUHJvZHVjdFwiLCB2b2lkIDApO1xyXG4gICAgVXNlcnNDYXJkID0gX19kZWNvcmF0ZShbXHJcbiAgICAgICAgQ29tcG9uZW50KHtcclxuICAgICAgICAgICAgY29tcG9uZW50czoge1xyXG4gICAgICAgICAgICAgICAgQkljb25QZW5jaWxGaWxsOiBCSWNvblBlbmNpbEZpbGwsXHJcbiAgICAgICAgICAgICAgICBCSWNvblRyYXNoRmlsbDogQkljb25UcmFzaEZpbGwsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSlcclxuICAgIF0sIFVzZXJzQ2FyZCk7XHJcbiAgICByZXR1cm4gVXNlcnNDYXJkO1xyXG59KFZ1ZSkpO1xyXG5leHBvcnQgZGVmYXVsdCBVc2Vyc0NhcmQ7XHJcbiIsInZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgKGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgICAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIH07XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2xhc3MgZXh0ZW5kcyB2YWx1ZSBcIiArIFN0cmluZyhiKSArIFwiIGlzIG5vdCBhIGNvbnN0cnVjdG9yIG9yIG51bGxcIik7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgICAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbiAgICB9O1xyXG59KSgpO1xyXG52YXIgX19kZWNvcmF0ZSA9ICh0aGlzICYmIHRoaXMuX19kZWNvcmF0ZSkgfHwgZnVuY3Rpb24gKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFByb3AsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IGNoZWNrUGFzc3dvcmQgZnJvbSAnQC91dGlscy9jaGVja1Bhc3N3b3JkJztcclxudmFyIHVTdG9yZSA9IG5hbWVzcGFjZSgndXNlcnMnKTtcclxudmFyIFVzZXJzTW9kYWwgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XHJcbiAgICBfX2V4dGVuZHMoVXNlcnNNb2RhbCwgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIFVzZXJzTW9kYWwoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xyXG4gICAgfVxyXG4gICAgVXNlcnNNb2RhbC5wcm90b3R5cGUuaGFuZGxlT2sgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKCFjaGVja1Bhc3N3b3JkKHRoaXMuZm9ybSkpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5pc0FkZCkge1xyXG4gICAgICAgICAgICB0aGlzLmFkZFVzZXIodGhpcy5mb3JtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZWRpdFVzZXIodGhpcy5mb3JtKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgVXNlcnNNb2RhbC5wcm90b3R5cGUuaGFuZGxlQ2xvc2UgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5zZXRNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgfTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIFByb3AoKVxyXG4gICAgXSwgVXNlcnNNb2RhbC5wcm90b3R5cGUsIFwiZm9ybVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgUHJvcCgpXHJcbiAgICBdLCBVc2Vyc01vZGFsLnByb3RvdHlwZSwgXCJpc0FkZFwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgUHJvcCgpXHJcbiAgICBdLCBVc2Vyc01vZGFsLnByb3RvdHlwZSwgXCJpc1Zpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIFVzZXJzTW9kYWwucHJvdG90eXBlLCBcImFkZFVzZXJcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5BY3Rpb25cclxuICAgIF0sIFVzZXJzTW9kYWwucHJvdG90eXBlLCBcImVkaXRVc2VyXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBVc2Vyc01vZGFsLnByb3RvdHlwZSwgXCJzZXRNb2RhbFZpc2libGVcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgVXNlcnNNb2RhbC5wcm90b3R5cGUsIFwiaXNNb2RhbExvYWRpbmdcIiwgdm9pZCAwKTtcclxuICAgIFVzZXJzTW9kYWwgPSBfX2RlY29yYXRlKFtcclxuICAgICAgICBDb21wb25lbnRcclxuICAgIF0sIFVzZXJzTW9kYWwpO1xyXG4gICAgcmV0dXJuIFVzZXJzTW9kYWw7XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJzTW9kYWw7XHJcbiIsIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvY3NzV2l0aE1hcHBpbmdUb1N0cmluZy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiLmNhcmQtZm9vdGVyW2RhdGEtdi0yMDAwNWYzNF0ge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxufVxcbi5jYXJkLWZvb3RlciBidXR0b25bZGF0YS12LTIwMDA1ZjM0XSB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcXG59XCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvdXNlcnMvY29tcG9uZW50cy9Vc2Vyc0NhcmQudnVlXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQTJEQTtFQUNFLGFBQUE7RUFDQSx5QkFBQTtBQTFERjtBQTJERTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQXpESlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXG5cXHJcXG4uY2FyZC1mb290ZXIge1xcclxcbiAgZGlzcGxheTogZmxleDtcXHJcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxyXFxuICBidXR0b24ge1xcclxcbiAgICBkaXNwbGF5OiBmbGV4O1xcclxcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xcclxcbiAgfVxcclxcbn1cXHJcXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiaW1wb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSBmcm9tIFwiLi9Vc2Vycy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MzY0OGUzNjMmbGFuZz1wdWcmXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vVXNlcnMudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiXG5leHBvcnQgKiBmcm9tIFwiLi9Vc2Vycy52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcblxuXG4vKiBub3JtYWxpemUgY29tcG9uZW50ICovXG5pbXBvcnQgbm9ybWFsaXplciBmcm9tIFwiIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanNcIlxudmFyIGNvbXBvbmVudCA9IG5vcm1hbGl6ZXIoXG4gIHNjcmlwdCxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZhbHNlLFxuICBudWxsLFxuICBudWxsLFxuICBudWxsXG4gIFxuKVxuXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICB2YXIgYXBpID0gcmVxdWlyZShcIkM6XFxcXFVzZXJzXFxcXGNhcmRlXFxcXFByb2plY3RzXFxcXGluYWdhdmVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1ob3QtcmVsb2FkLWFwaVxcXFxkaXN0XFxcXGluZGV4LmpzXCIpXG4gIGFwaS5pbnN0YWxsKHJlcXVpcmUoJ3Z1ZScpKVxuICBpZiAoYXBpLmNvbXBhdGlibGUpIHtcbiAgICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gICAgaWYgKCFhcGkuaXNSZWNvcmRlZCgnMzY0OGUzNjMnKSkge1xuICAgICAgYXBpLmNyZWF0ZVJlY29yZCgnMzY0OGUzNjMnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9IGVsc2Uge1xuICAgICAgYXBpLnJlbG9hZCgnMzY0OGUzNjMnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL1VzZXJzLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0zNjQ4ZTM2MyZsYW5nPXB1ZyZcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgYXBpLnJlcmVuZGVyKCczNjQ4ZTM2MycsIHtcbiAgICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICAgIHN0YXRpY1JlbmRlckZuczogc3RhdGljUmVuZGVyRm5zXG4gICAgICB9KVxuICAgIH0pXG4gIH1cbn1cbmNvbXBvbmVudC5vcHRpb25zLl9fZmlsZSA9IFwicmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3MvdXNlcnMvVXNlcnMudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSBmcm9tIFwiLi9BZGRQcm9kdWN0VG9Vc2VyLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD1iNTE2MmY3MCZsYW5nPXB1ZyZcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9BZGRQcm9kdWN0VG9Vc2VyLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuZXhwb3J0ICogZnJvbSBcIi4vQWRkUHJvZHVjdFRvVXNlci52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcblxuXG4vKiBub3JtYWxpemUgY29tcG9uZW50ICovXG5pbXBvcnQgbm9ybWFsaXplciBmcm9tIFwiIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanNcIlxudmFyIGNvbXBvbmVudCA9IG5vcm1hbGl6ZXIoXG4gIHNjcmlwdCxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZhbHNlLFxuICBudWxsLFxuICBudWxsLFxuICBudWxsXG4gIFxuKVxuXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICB2YXIgYXBpID0gcmVxdWlyZShcIkM6XFxcXFVzZXJzXFxcXGNhcmRlXFxcXFByb2plY3RzXFxcXGluYWdhdmVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1ob3QtcmVsb2FkLWFwaVxcXFxkaXN0XFxcXGluZGV4LmpzXCIpXG4gIGFwaS5pbnN0YWxsKHJlcXVpcmUoJ3Z1ZScpKVxuICBpZiAoYXBpLmNvbXBhdGlibGUpIHtcbiAgICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gICAgaWYgKCFhcGkuaXNSZWNvcmRlZCgnYjUxNjJmNzAnKSkge1xuICAgICAgYXBpLmNyZWF0ZVJlY29yZCgnYjUxNjJmNzAnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9IGVsc2Uge1xuICAgICAgYXBpLnJlbG9hZCgnYjUxNjJmNzAnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL0FkZFByb2R1Y3RUb1VzZXIudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWI1MTYyZjcwJmxhbmc9cHVnJlwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICBhcGkucmVyZW5kZXIoJ2I1MTYyZjcwJywge1xuICAgICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgICAgc3RhdGljUmVuZGVyRm5zOiBzdGF0aWNSZW5kZXJGbnNcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuY29tcG9uZW50Lm9wdGlvbnMuX19maWxlID0gXCJyZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL0FkZFByb2R1Y3RUb1VzZXIudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSBmcm9tIFwiLi9Vc2Vyc0NhcmQudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTIwMDA1ZjM0JnNjb3BlZD10cnVlJmxhbmc9cHVnJlwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcbmV4cG9ydCAqIGZyb20gXCIuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcbmltcG9ydCBzdHlsZTAgZnJvbSBcIi4vVXNlcnNDYXJkLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTIwMDA1ZjM0Jmxhbmc9c2NzcyZzY29wZWQ9dHJ1ZSZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIFwiMjAwMDVmMzRcIixcbiAgbnVsbFxuICBcbilcblxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgdmFyIGFwaSA9IHJlcXVpcmUoXCJDOlxcXFxVc2Vyc1xcXFxjYXJkZVxcXFxQcm9qZWN0c1xcXFxpbmFnYXZlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtaG90LXJlbG9hZC1hcGlcXFxcZGlzdFxcXFxpbmRleC5qc1wiKVxuICBhcGkuaW5zdGFsbChyZXF1aXJlKCd2dWUnKSlcbiAgaWYgKGFwaS5jb21wYXRpYmxlKSB7XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICAgIGlmICghYXBpLmlzUmVjb3JkZWQoJzIwMDA1ZjM0JykpIHtcbiAgICAgIGFwaS5jcmVhdGVSZWNvcmQoJzIwMDA1ZjM0JywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfSBlbHNlIHtcbiAgICAgIGFwaS5yZWxvYWQoJzIwMDA1ZjM0JywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfVxuICAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9Vc2Vyc0NhcmQudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTIwMDA1ZjM0JnNjb3BlZD10cnVlJmxhbmc9cHVnJlwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICBhcGkucmVyZW5kZXIoJzIwMDA1ZjM0Jywge1xuICAgICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgICAgc3RhdGljUmVuZGVyRm5zOiBzdGF0aWNSZW5kZXJGbnNcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuY29tcG9uZW50Lm9wdGlvbnMuX19maWxlID0gXCJyZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy91c2Vycy9jb21wb25lbnRzL1VzZXJzQ2FyZC52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1VzZXJzTW9kYWwudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTcyOWI4NmI5Jmxhbmc9cHVnJlwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL1VzZXJzTW9kYWwudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiXG5leHBvcnQgKiBmcm9tIFwiLi9Vc2Vyc01vZGFsLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcY2FyZGVcXFxcUHJvamVjdHNcXFxcaW5hZ2F2ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCc3MjliODZiOScpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCc3MjliODZiOScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCc3MjliODZiOScsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vVXNlcnNNb2RhbC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NzI5Yjg2YjkmbGFuZz1wdWcmXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGFwaS5yZXJlbmRlcignNzI5Yjg2YjknLCB7XG4gICAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgICBzdGF0aWNSZW5kZXJGbnM6IHN0YXRpY1JlbmRlckZuc1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG5jb21wb25lbnQub3B0aW9ucy5fX2ZpbGUgPSBcInJlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3VzZXJzL2NvbXBvbmVudHMvVXNlcnNNb2RhbC52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgbW9kIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9Vc2Vycy52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1VzZXJzLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIiIsImltcG9ydCBtb2QgZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL0FkZFByb2R1Y3RUb1VzZXIudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiOyBleHBvcnQgZGVmYXVsdCBtb2Q7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9BZGRQcm9kdWN0VG9Vc2VyLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIiIsImltcG9ydCBtb2QgZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCIiLCJpbXBvcnQgbW9kIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9Vc2Vyc01vZGFsLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIjsgZXhwb3J0IGRlZmF1bHQgbW9kOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vVXNlcnNNb2RhbC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCIiLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1jb250YWluZXJcIixcbiAgICB7IGF0dHJzOiB7IHRhZzogXCJtYWluXCIgfSB9LFxuICAgIFtcbiAgICAgIF92bS5wYWdpbmF0aW9uLnRvdGFsVXNlcnMgPiBfdm0ucGFnaW5hdGlvbi5wZXJQYWdlXG4gICAgICAgID8gX2MoXCJiLXBhZ2luYXRpb25cIiwge1xuICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgYWxpZ246IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIFwicGVyLXBhZ2VcIjogX3ZtLnBhZ2luYXRpb24ucGVyUGFnZSxcbiAgICAgICAgICAgICAgXCJ0b3RhbC1yb3dzXCI6IF92bS5wYWdpbmF0aW9uLnRvdGFsVXNlcnNcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbjogeyBjaGFuZ2U6IF92bS5nZXRVc2VycyB9LFxuICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgdmFsdWU6IF92bS5jdXJyZW50UGFnZSxcbiAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgIF92bS5jdXJyZW50UGFnZSA9ICQkdlxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImN1cnJlbnRQYWdlXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICA6IF92bS5fZSgpLFxuICAgICAgX3ZtLnVzZXJzLmxlbmd0aCA+IDBcbiAgICAgICAgPyBfYyhcbiAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcInVzZXJzXCIgfSxcbiAgICAgICAgICAgIF92bS5fbChfdm0udXNlcnMsIGZ1bmN0aW9uKHVzZXIsIGkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9jKFwidXNlcnMtY2FyZFwiLCB7XG4gICAgICAgICAgICAgICAga2V5OiB1c2VyLmlkLFxuICAgICAgICAgICAgICAgIGF0dHJzOiB7IHVzZXI6IHVzZXIgfSxcbiAgICAgICAgICAgICAgICBvbjoge1xuICAgICAgICAgICAgICAgICAgXCJlZGl0LXVzZXJcIjogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBfdm0uZWRpdFVzZXIodXNlciwgaSlcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBcImRlbGV0ZS11c2VyXCI6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3ZtLmRlbGV0ZVVzZXJDb25maXJtKHVzZXIpXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKVxuICAgICAgICA6IF92bS5pc0xvYWRpbmdcbiAgICAgICAgPyBfYyhcImRpdlwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLmxvYWRpbmdcIikpICsgXCIuLi5cIildKVxuICAgICAgICA6IF9jKFwiZGl2XCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInVzZXJzLm5vX3VzZXJzXCIpKSldKSxcbiAgICAgIF92bS5wYWdpbmF0aW9uLnRvdGFsVXNlcnMgPiBfdm0ucGFnaW5hdGlvbi5wZXJQYWdlXG4gICAgICAgID8gX2MoXCJiLXBhZ2luYXRpb25cIiwge1xuICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgYWxpZ246IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIFwicGVyLXBhZ2VcIjogX3ZtLnBhZ2luYXRpb24ucGVyUGFnZSxcbiAgICAgICAgICAgICAgXCJ0b3RhbC1yb3dzXCI6IF92bS5wYWdpbmF0aW9uLnRvdGFsVXNlcnNcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbjogeyBjaGFuZ2U6IF92bS5nZXRVc2VycyB9LFxuICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgdmFsdWU6IF92bS5jdXJyZW50UGFnZSxcbiAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgIF92bS5jdXJyZW50UGFnZSA9ICQkdlxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImN1cnJlbnRQYWdlXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICA6IF92bS5fZSgpLFxuICAgICAgX2MoXCJ1c2Vycy1tb2RhbFwiLCB7XG4gICAgICAgIHJlZjogXCJ1c2Vyc19tb2RhbFwiLFxuICAgICAgICBhdHRyczoge1xuICAgICAgICAgIGZvcm06IF92bS5mb3JtLFxuICAgICAgICAgIFwiaXMtYWRkXCI6IF92bS5pc01vZGFsQWRkLFxuICAgICAgICAgIFwiaXMtdmlzaWJsZVwiOiBfdm0uaXNNb2RhbFZpc2libGVcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICBfYyhcImFkZC1wcm9kdWN0LXRvLXVzZXJcIiwge1xuICAgICAgICByZWY6IFwiYWRkX3Byb2R1Y3RfdG9fdXNlclwiLFxuICAgICAgICBhdHRyczoge1xuICAgICAgICAgIGZvcm06IF92bS5mb3JtUHJvZHVjdCxcbiAgICAgICAgICBcImlzLXZpc2libGVcIjogX3ZtLmlzTW9kYWxUb0FkZFByb2R1Y3RWaXNpYmxlXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1tb2RhbFwiLFxuICAgIHtcbiAgICAgIGF0dHJzOiB7XG4gICAgICAgIFwiaGlkZS1oZWFkZXItY2xvc2VcIjogXCJcIixcbiAgICAgICAgdmlzaWJsZTogX3ZtLmlzVmlzaWJsZSxcbiAgICAgICAgc2l6ZTogXCJ4bFwiLFxuICAgICAgICBzY3JvbGxhYmxlOiBcIlwiLFxuICAgICAgICBjZW50ZXJlZDogXCJcIixcbiAgICAgICAgXCJjYW5jZWwtdGl0bGVcIjogX3ZtLiR0KFwiYnV0dG9ucy5jYW5jZWxcIiksXG4gICAgICAgIFwib2stZGlzYWJsZWRcIjogX3ZtLmlzTW9kYWxMb2FkaW5nLFxuICAgICAgICBcIm9rLXRpdGxlXCI6IF92bS4kdChcImJ1dHRvbnMuYWRkXCIpLFxuICAgICAgICB0aXRsZTogX3ZtLiR0KFwicHJvZHVjdHMuYWRkX3Byb2R1Y3RcIilcbiAgICAgIH0sXG4gICAgICBvbjoge1xuICAgICAgICBoaWRlOiBfdm0uaGFuZGxlQ2xvc2UsXG4gICAgICAgIG9rOiBmdW5jdGlvbigkZXZlbnQpIHtcbiAgICAgICAgICAkZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgIHJldHVybiBfdm0uaGFuZGxlT2soJGV2ZW50KVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBbXG4gICAgICBfYyhcbiAgICAgICAgXCJiLWZvcm1cIixcbiAgICAgICAgW1xuICAgICAgICAgIF9jKFxuICAgICAgICAgICAgXCJiLXJvd1wiLFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICAgICAgeyBhdHRyczogeyBtZDogXCI2XCIgfSB9LFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICFfdm0uaXNMb2FkaW5nXG4gICAgICAgICAgICAgICAgICAgID8gX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICBcImItZm9ybS1ncm91cFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBfdm0uJHQoXCJwcm9kdWN0cy5mb3JtX2VzdGF0ZVwiKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogX3ZtLiR0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJwcm9kdWN0cy5mb3JtX2VzdGF0ZV9kZXNjcmlwdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImxhYmVsLWZvclwiOiBcImVzdGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYi1mb3JtLXNlbGVjdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IFwic2VsZWN0LXNpemVcIjogNyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnByb2R1Y3RfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJwcm9kdWN0X2lkXCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLnByb2R1Y3RfaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLl9sKF92bS5wcm9kdWN0cywgZnVuY3Rpb24ocHJvZHVjdCwgaSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImItZm9ybS1zZWxlY3Qtb3B0aW9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBpLCBhdHRyczogeyB2YWx1ZTogcHJvZHVjdC5pZCB9IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKHByb2R1Y3QuZXN0YXRlKSldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgOiBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgdmFyaWFudDogXCJ3YXJuaW5nXCIsIGRpc2FibGVkOiBcIlwiLCBibG9jazogXCJcIiB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcImItc3Bpbm5lclwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgc21hbGw6IFwiXCIsIHZhcmlhbnQ6IFwibGlnaHRcIiwgdHlwZTogXCJncm93XCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgIFwiYi1jb2xcIixcbiAgICAgICAgICAgICAgICB7IGF0dHJzOiB7IG1kOiBcIjZcIiB9IH0sXG4gICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgIV92bS5pc0xvYWRpbmdcbiAgICAgICAgICAgICAgICAgICAgPyBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYi1mb3JtLWdyb3VwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IF92bS4kdChcInByb2R1Y3RzLmZvcm1fcXVhbnRpdHlfbmFtZVwiKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogX3ZtLiR0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJwcm9kdWN0cy5mb3JtX3F1YW50aXR5X2Rlc2NyaXB0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwibGFiZWwtZm9yXCI6IFwicXVhbnRpdHlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBcInF1YW50aXR5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIm51bWJlclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnF1YW50aXR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJxdWFudGl0eVwiLCAkJHYpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLnF1YW50aXR5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgOiBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgdmFyaWFudDogXCJ3YXJuaW5nXCIsIGRpc2FibGVkOiBcIlwiLCBibG9jazogXCJcIiB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcImItc3Bpbm5lclwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHsgc21hbGw6IFwiXCIsIHZhcmlhbnQ6IFwibGlnaHRcIiwgdHlwZTogXCJncm93XCIgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKVxuICAgICAgICBdLFxuICAgICAgICAxXG4gICAgICApXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1jYXJkXCIsXG4gICAgeyBzdGF0aWNDbGFzczogXCJ1c2Vycy1jYXJkIG1iLTNcIiwgYXR0cnM6IHsgXCJuby1ib2R5XCI6IFwiXCIgfSB9LFxuICAgIFtcbiAgICAgIF9jKFwiaDRcIiwgeyBhdHRyczogeyBzbG90OiBcImhlYWRlclwiIH0sIHNsb3Q6IFwiaGVhZGVyXCIgfSwgW1xuICAgICAgICBfdm0uX3YoXG4gICAgICAgICAgX3ZtLl9zKF92bS51c2VyLm5hbWUpICtcbiAgICAgICAgICAgIFwiIFwiICtcbiAgICAgICAgICAgIF92bS5fcyhfdm0udXNlci5sYXN0bmFtZSkgK1xuICAgICAgICAgICAgXCIgXCIgK1xuICAgICAgICAgICAgX3ZtLl9zKF92bS51c2VyLnNlY29uZF9sYXN0bmFtZSlcbiAgICAgICAgKVxuICAgICAgXSksXG4gICAgICBfYyhcImItY2FyZC1ib2R5XCIsIFtcbiAgICAgICAgX2MoXCJwXCIsIHsgc3RhdGljQ2xhc3M6IFwiY2FyZC10ZXh0XCIgfSwgW1xuICAgICAgICAgIF9jKFwic3BhblwiLCB7IHN0YXRpY0NsYXNzOiBcImZvbnQtd2VpZ2h0LWJvbGRcIiB9LCBbXG4gICAgICAgICAgICBfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MuZW1haWxcIikpICsgXCI6XCIpXG4gICAgICAgICAgXSksXG4gICAgICAgICAgX3ZtLl92KFwiwqBcIiArIF92bS5fcyhfdm0udXNlci5lbWFpbCkpLFxuICAgICAgICAgIF9jKFwiYnJcIiksXG4gICAgICAgICAgX2MoXCJzcGFuXCIsIHsgc3RhdGljQ2xhc3M6IFwiZm9udC13ZWlnaHQtYm9sZFwiIH0sIFtcbiAgICAgICAgICAgIF92bS5fdihfdm0uX3MoX3ZtLiR0KFwidXNlcnMudXNlcl90eXBlXCIpKSArIFwiOlwiKVxuICAgICAgICAgIF0pLFxuICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgIFwiwqBcIiArXG4gICAgICAgICAgICAgIF92bS5fcyhcbiAgICAgICAgICAgICAgICBfdm0udXNlci50eXBlX2lkID09PSAxXG4gICAgICAgICAgICAgICAgICA/IF92bS4kdChcInN0cmluZ3MuYWRtaW5cIilcbiAgICAgICAgICAgICAgICAgIDogX3ZtLiR0KFwic3RyaW5ncy5ub3JtYWxcIilcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgIClcbiAgICAgICAgXSlcbiAgICAgIF0pLFxuICAgICAgX2MoXG4gICAgICAgIFwiYi1jYXJkLWZvb3RlclwiLFxuICAgICAgICBbXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGF0dHJzOiB7IHZhcmlhbnQ6IFwid2FybmluZ1wiIH0sXG4gICAgICAgICAgICAgIG9uOiB7XG4gICAgICAgICAgICAgICAgY2xpY2s6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF92bS5oYW5kbGVBZGRQcm9kdWN0VG9Vc2VyKF92bS51c2VyKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInByb2R1Y3RzLmFkZF9wcm9kdWN0XCIpKSldXG4gICAgICAgICAgKSxcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgYXR0cnM6IHsgdmFyaWFudDogXCJsaW5rXCIgfSxcbiAgICAgICAgICAgICAgb246IHtcbiAgICAgICAgICAgICAgICBjbGljazogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX3ZtLiRlbWl0KFwiZWRpdC11c2VyXCIpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcImItaWNvbi1wZW5jaWwtZmlsbFwiKSxcbiAgICAgICAgICAgICAgX3ZtLl92KFwiwqBcIiArIF92bS5fcyhfdm0uJHQoXCJidXR0b25zLmVkaXRcIikpKVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApLFxuICAgICAgICAgIF92bS51c2VyLmlkICE9PSBfdm0uYWN0dWFsVXNlci5pZFxuICAgICAgICAgICAgPyBfYyhcbiAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwidGV4dC1kYW5nZXJcIixcbiAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHZhcmlhbnQ6IFwibGlua1wiIH0sXG4gICAgICAgICAgICAgICAgICBvbjoge1xuICAgICAgICAgICAgICAgICAgICBjbGljazogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF92bS4kZW1pdChcImRlbGV0ZS11c2VyXCIpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFwiYi1pY29uLXRyYXNoLWZpbGxcIiksXG4gICAgICAgICAgICAgICAgICBfdm0uX3YoXCLCoFwiICsgX3ZtLl9zKF92bS4kdChcImJ1dHRvbnMuZGVsZXRlXCIpKSlcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgOiBfdm0uX2UoKVxuICAgICAgICBdLFxuICAgICAgICAxXG4gICAgICApXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiYi1tb2RhbFwiLFxuICAgIHtcbiAgICAgIGF0dHJzOiB7XG4gICAgICAgIFwiaGlkZS1oZWFkZXItY2xvc2VcIjogXCJcIixcbiAgICAgICAgdmlzaWJsZTogX3ZtLmlzVmlzaWJsZSxcbiAgICAgICAgXCJjYW5jZWwtdGl0bGVcIjogX3ZtLiR0KFwiYnV0dG9ucy5jYW5jZWxcIiksXG4gICAgICAgIFwib2stZGlzYWJsZWRcIjogX3ZtLmlzTW9kYWxMb2FkaW5nLFxuICAgICAgICBcIm9rLXRpdGxlXCI6IF92bS5pc01vZGFsTG9hZGluZ1xuICAgICAgICAgID8gX3ZtLiR0KFwiYnV0dG9ucy5zZW5kaW5nXCIpXG4gICAgICAgICAgOiBfdm0uaXNBZGRcbiAgICAgICAgICA/IF92bS4kdChcImJ1dHRvbnMuYWRkXCIpXG4gICAgICAgICAgOiBfdm0uJHQoXCJidXR0b25zLnVwZGF0ZVwiKSxcbiAgICAgICAgdGl0bGU6IF92bS5pc0FkZCA/IF92bS4kdChcInVzZXJzLmFkZF91c2VyXCIpIDogX3ZtLiR0KFwidXNlcnMuZWRpdF91c2VyXCIpXG4gICAgICB9LFxuICAgICAgb246IHtcbiAgICAgICAgaGlkZTogX3ZtLmhhbmRsZUNsb3NlLFxuICAgICAgICBvazogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgJGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgICByZXR1cm4gX3ZtLmhhbmRsZU9rKCRldmVudClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgW1xuICAgICAgX2MoXG4gICAgICAgIFwiYi1mb3JtXCIsXG4gICAgICAgIFtcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1mb3JtLWdyb3VwXCIsXG4gICAgICAgICAgICB7IGF0dHJzOiB7IGxhYmVsOiBfdm0uJHQoXCJzdHJpbmdzLm5hbWVcIiksIFwibGFiZWwtZm9yXCI6IFwibmFtZVwiIH0gfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICBpZDogXCJuYW1lXCIsXG4gICAgICAgICAgICAgICAgICB0eXBlOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgIG1heGxlbmd0aDogXCIyNVwiLFxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IFwiXCJcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG1vZGVsOiB7XG4gICAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLmZvcm0ubmFtZSxcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoX3ZtLmZvcm0sIFwibmFtZVwiLCAkJHYpXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLm5hbWVcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKSxcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1mb3JtLWdyb3VwXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6IF92bS4kdChcInN0cmluZ3MubGFzdG5hbWVcIiksXG4gICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJsYXN0bmFtZVwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFwiYi1mb3JtLWlucHV0XCIsIHtcbiAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgaWQ6IFwibGFzdG5hbWVcIixcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxuICAgICAgICAgICAgICAgICAgbWF4bGVuZ3RoOiBcIjE1XCIsXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZDogXCJcIlxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBfdm0uZm9ybS5sYXN0bmFtZSxcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoX3ZtLmZvcm0sIFwibGFzdG5hbWVcIiwgJCR2KVxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IFwiZm9ybS5sYXN0bmFtZVwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApLFxuICAgICAgICAgIF9jKFxuICAgICAgICAgICAgXCJiLWZvcm0tZ3JvdXBcIixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICBsYWJlbDogX3ZtLiR0KFwic3RyaW5ncy5zZWNvbmRfbGFzdG5hbWVcIiksXG4gICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJzZWNvbmRfbGFzdG5hbWVcIlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiBcInNlY29uZF9sYXN0bmFtZVwiLFxuICAgICAgICAgICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgICAgICBtYXhsZW5ndGg6IFwiMTVcIixcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBcIlwiXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnNlY29uZF9sYXN0bmFtZSxcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoX3ZtLmZvcm0sIFwic2Vjb25kX2xhc3RuYW1lXCIsICQkdilcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0uc2Vjb25kX2xhc3RuYW1lXCJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItZm9ybS1ncm91cFwiLFxuICAgICAgICAgICAgeyBhdHRyczogeyBsYWJlbDogX3ZtLiR0KFwic3RyaW5ncy5lbWFpbFwiKSwgXCJsYWJlbC1mb3JcIjogXCJlbWFpbFwiIH0gfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICBpZDogXCJlbWFpbFwiLFxuICAgICAgICAgICAgICAgICAgdHlwZTogXCJlbWFpbFwiLFxuICAgICAgICAgICAgICAgICAgbWF4bGVuZ3RoOiBcIjE5MVwiLFxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IFwiXCJcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG1vZGVsOiB7XG4gICAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLmZvcm0uZW1haWwsXG4gICAgICAgICAgICAgICAgICBjYWxsYmFjazogZnVuY3Rpb24oJCR2KSB7XG4gICAgICAgICAgICAgICAgICAgIF92bS4kc2V0KF92bS5mb3JtLCBcImVtYWlsXCIsICQkdilcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0uZW1haWxcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKSxcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1mb3JtLWdyb3VwXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6IF92bS4kdChcInN0cmluZ3MucGFzc3dvcmRcIiksXG4gICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIF9jKFwiYi1mb3JtLWlucHV0XCIsIHtcbiAgICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgICAgaWQ6IFwicGFzc3dvcmRcIixcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwicGFzc3dvcmRcIixcbiAgICAgICAgICAgICAgICAgIG1heGxlbmd0aDogXCIxOTFcIixcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBcIlwiXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnBhc3N3b3JkLFxuICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJwYXNzd29yZFwiLCAkJHYpXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLnBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItZm9ybS1ncm91cFwiLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBhdHRyczoge1xuICAgICAgICAgICAgICAgIGxhYmVsOiBfdm0uJHQoXCJzZXR0aW5ncy5wYXNzd29yZF9jb25maXJtYXRpb25cIiksXG4gICAgICAgICAgICAgICAgXCJsYWJlbC1mb3JcIjogXCJwYXNzd29yZF9jb25maXJtYXRpb25cIlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiBcInBhc3N3b3JkX2NvbmZpcm1hdGlvblwiLFxuICAgICAgICAgICAgICAgICAgdHlwZTogXCJwYXNzd29yZFwiLFxuICAgICAgICAgICAgICAgICAgbWF4bGVuZ3RoOiBcIjE5MVwiXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnBhc3N3b3JkX2NvbmZpcm1hdGlvbixcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoX3ZtLmZvcm0sIFwicGFzc3dvcmRfY29uZmlybWF0aW9uXCIsICQkdilcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0ucGFzc3dvcmRfY29uZmlybWF0aW9uXCJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgMVxuICAgICAgICAgICksXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItZm9ybS1ncm91cFwiLFxuICAgICAgICAgICAgeyBhdHRyczogeyBsYWJlbDogX3ZtLiR0KFwidXNlcnMudXNlcl90eXBlXCIpIH0gfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJiLWZvcm0tcmFkaW8tZ3JvdXBcIixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBhdHRyczogeyBuYW1lOiBcInR5cGVfaWRcIiB9LFxuICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLnR5cGVfaWQsXG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJ0eXBlX2lkXCIsIF92bS5fbigkJHYpKVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBcImZvcm0udHlwZV9pZFwiXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICBfYyhcImItZm9ybS1yYWRpb1wiLCB7IGF0dHJzOiB7IHZhbHVlOiBcIjJcIiB9IH0sIFtcbiAgICAgICAgICAgICAgICAgICAgX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLm5vcm1hbFwiKSkpXG4gICAgICAgICAgICAgICAgICBdKSxcbiAgICAgICAgICAgICAgICAgIF9jKFwiYi1mb3JtLXJhZGlvXCIsIHsgYXR0cnM6IHsgdmFsdWU6IFwiMVwiIH0gfSwgW1xuICAgICAgICAgICAgICAgICAgICBfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MuYWRtaW5cIikpKVxuICAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApXG4gICAgICAgIF0sXG4gICAgICAgIDFcbiAgICAgIClcbiAgICBdLFxuICAgIDFcbiAgKVxufVxudmFyIHN0YXRpY1JlbmRlckZucyA9IFtdXG5yZW5kZXIuX3dpdGhTdHJpcHBlZCA9IHRydWVcblxuZXhwb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSIsIi8vIHN0eWxlLWxvYWRlcjogQWRkcyBzb21lIGNzcyB0byB0aGUgRE9NIGJ5IGFkZGluZyBhIDxzdHlsZT4gdGFnXG5cbi8vIGxvYWQgdGhlIHN0eWxlc1xudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC0xMlswXS5ydWxlc1swXS51c2VbMV0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2xvYWRlcnMvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9wb3N0Y3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC0xMlswXS5ydWxlc1swXS51c2VbMl0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTEyWzBdLnJ1bGVzWzBdLnVzZVszXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yMDAwNWYzNCZsYW5nPXNjc3Mmc2NvcGVkPXRydWUmXCIpO1xuaWYoY29udGVudC5fX2VzTW9kdWxlKSBjb250ZW50ID0gY29udGVudC5kZWZhdWx0O1xuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2Fscztcbi8vIGFkZCB0aGUgc3R5bGVzIHRvIHRoZSBET01cbnZhciBhZGQgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtc3R5bGUtbG9hZGVyL2xpYi9hZGRTdHlsZXNDbGllbnQuanNcIikuZGVmYXVsdFxudmFyIHVwZGF0ZSA9IGFkZChcIjJhNDY4YmJkXCIsIGNvbnRlbnQsIGZhbHNlLCB7fSk7XG4vLyBIb3QgTW9kdWxlIFJlcGxhY2VtZW50XG5pZihtb2R1bGUuaG90KSB7XG4gLy8gV2hlbiB0aGUgc3R5bGVzIGNoYW5nZSwgdXBkYXRlIHRoZSA8c3R5bGU+IHRhZ3NcbiBpZighY29udGVudC5sb2NhbHMpIHtcbiAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiISEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC0xMlswXS5ydWxlc1swXS51c2VbMV0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2xvYWRlcnMvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9wb3N0Y3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/Y2xvbmVkUnVsZVNldC0xMlswXS5ydWxlc1swXS51c2VbMl0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTEyWzBdLnJ1bGVzWzBdLnVzZVszXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1VzZXJzQ2FyZC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yMDAwNWYzNCZsYW5nPXNjc3Mmc2NvcGVkPXRydWUmXCIsIGZ1bmN0aW9uKCkge1xuICAgICB2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTEyWzBdLnJ1bGVzWzBdLnVzZVsxXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvbG9hZGVycy9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Bvc3Rjc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9jbG9uZWRSdWxlU2V0LTEyWzBdLnJ1bGVzWzBdLnVzZVsyXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvZGlzdC9janMuanM/P2Nsb25lZFJ1bGVTZXQtMTJbMF0ucnVsZXNbMF0udXNlWzNdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vVXNlcnNDYXJkLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTIwMDA1ZjM0Jmxhbmc9c2NzcyZzY29wZWQ9dHJ1ZSZcIik7XG4gICAgIGlmKG5ld0NvbnRlbnQuX19lc01vZHVsZSkgbmV3Q29udGVudCA9IG5ld0NvbnRlbnQuZGVmYXVsdDtcbiAgICAgaWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG4gICAgIHVwZGF0ZShuZXdDb250ZW50KTtcbiAgIH0pO1xuIH1cbiAvLyBXaGVuIHRoZSBtb2R1bGUgaXMgZGlzcG9zZWQsIHJlbW92ZSB0aGUgPHN0eWxlPiB0YWdzXG4gbW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59Il0sInNvdXJjZVJvb3QiOiIifQ==