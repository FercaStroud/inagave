export default {
  isAdmin(state) {
    return state.user.is_admin;
  },
};
