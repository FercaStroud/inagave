const SET_USER = (state, obj) => {
  state.user = obj;
};

export default {
  SET_USER,
};
