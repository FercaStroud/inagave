export default {
  user: {},
};
