export default {
  appName: '',
  backUrl: '',
  csrfToken: '',
  homeItems: [],
  menu: [],
  settings: {},
  dialogMessage: '',
  title: '',
  MP_TOKEN: 'APP_USR-655f750c-4355-4210-a1c4-4e1745da9d1b',
  website: {
    title: 'Inagave - Administración',
  },
};
