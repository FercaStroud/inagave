declare interface Image {
  id: number;
  product_id: number;
  name: string;
  src: any;
}
