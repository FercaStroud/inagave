declare interface Percentage {
  id: number;
  name: string;
  value: any;
}
