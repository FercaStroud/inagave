declare interface Price {
  id: number;
  price: any;
  year: number;
}
