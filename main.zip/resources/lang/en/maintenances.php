<?php

return [
    'title' => 'All Maintenance Transactions',
    'product_name' => 'Product',
    'product_id' => 'Product ID',

];
