<?php

return [
    'title' => 'Percentages',
    'name' => 'Name',
    'value' => 'Value',

    'add_percentage' => 'Add Percentage',
    'edit_percentage' => 'Edit Percentage',
    'form_name' => 'Name',
    'form_name_description' => 'EJ: OBREROS',

    'form_value' => 'Value',
    'form_value_description' => 'Es en base 100, sin símbolos. EJ: 40.4, que es igual al 40.4%',
];
