<?php

return [
    'title' => 'Agave Prices',
    'price' => 'Price',
    'year' => 'Year',

    'add_price' => 'Add Price',
    'edit_price' => 'Edit Price',
    'form_price' => 'Price',
    'form_price_description' => 'KG Agave / Year',
    'form_year' => 'Year',
    'form_year_description' => 'form_year_description',

];
