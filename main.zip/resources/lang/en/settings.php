<?php

return [

    'new_password' => 'New password',
    'password_confirmation' => 'Password confirmation',

];
