<?php

return [
    'shortcuts' => 'SHORTCUTS',
    'products' => 'Products',
    'payments' => 'Payments',
    'prices' => 'Agave Prices',
    'users' => 'Users',
    'percentages' => 'Percentages',
    'maintenances' => 'Maintenances',
    'wallets' => 'Wallets',
];
