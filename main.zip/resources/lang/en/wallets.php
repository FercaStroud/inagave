<?php

return [
    'title' => 'My Wallet Transactions',
    'name' => 'User Name',
    'status' => 'Transaction Status',
    'amount' => 'Amount',
    'bank' => 'Bank',
    'account' => 'Account',
    'type' => 'Type',
    'request' => 'Withdraw Request',

    'edit_wallet' => 'Edit Wallet Status',
    'form_status' => 'Status',
    'form_status_description' => 'form_status_description',

];
