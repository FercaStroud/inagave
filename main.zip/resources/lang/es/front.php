<?php

return [

    'deleted_successfully' => 'Ha sido eliminado con éxito.',
    'password_changed_successfully' => 'Tu contraseña ha sido cambiada exitosamente.',
    'passwords_not_match' => 'La confirmación de contraseña no coincide.',
    'settings' => 'Configuraciones',

    'delete_user_confirmation' => '¿Seguro que quieres eliminar a este usuario?',
    'delete_product_confirmation' => '¿Seguro que quieres eliminar este producto?',
    'delete_price_confirmation' => '¿Seguro que quieres eliminar este precio?',
    'language' => 'Español',

];
