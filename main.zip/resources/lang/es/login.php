<?php

return [

    'confirm_password' => 'Confirmar contraseña',
    'description' => '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.',
    'forgot_password' => '¿Olvidaste tu contraseña?',
    'login' => 'Iniciar sesión',
    'keep_connected' => 'Mantenme conectado',
    'register' => 'Registro',
    'reset_password' => 'Restablecer la contraseña',
    'send_reset_link' => 'Enviar el enlace de reinicio',

    'account_created' => 'Su cuenta ha sido creada con éxito.',

];
