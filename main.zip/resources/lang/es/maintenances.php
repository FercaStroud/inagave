<?php

return [
    'title' => 'Inversionistas próximos mantenimientos',
    'product_name' => 'Producto Predio',
    'product_id' => 'ID de Producto',

];
