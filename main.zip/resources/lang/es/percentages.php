<?php

return [
    'title' => 'Porcentajes de Pago',
    'name' => 'Nombre',
    'value' => 'Porcentaje',

    'add_percentage' => 'Añadir Porcentaje',
    'edit_percentage' => 'Editar Porcentaje',
    'form_name' => 'Nombre',
    'form_name_description' => 'EJ: OBREROS',

    'form_value' => 'Valor',
    'form_value_description' => 'Es en base 100, sin símbolos. EJ: 40.4, que es igual al 40.4%',
];
