<?php

return [
    'title' => 'Precio de Agave (KG / Anual)',
    'price' => 'Precio',
    'year' => 'Año',

    'add_price' => 'Añadir Precio de Agave',
    'edit_price' => 'Editar Precio de Agave',
    'form_price' => 'Precio',
    'form_price_description' => 'KG Agave / Anual',

    'form_year' => 'Año',
    'form_year_description' => ' ',
];
