<?php

return [
    'shortcuts' => 'ACCESOS RÁPIDOS',
    'products' => 'Productos',
    'payments' => 'Historial de Pagos',
    'prices' => 'Precios de Agave (kg)',
    'users' => 'Usuarios',
    'percentages' => 'Porcentajes',
    'maintenances' => 'Mantenimientos',
    'wallets' => 'Carteras',
];
