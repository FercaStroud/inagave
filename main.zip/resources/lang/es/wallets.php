<?php

return [
    'title' => 'Historial de Transacciones (Depósitos/Retiros)',
    'name' => 'Usuario',
    'amount' => 'Cantidad',
    'bank' => 'Banco',
    'account' => 'Cuenta/Tarjeta Bancaria',
    'type' => 'Tipo de transacción',
    'request' => 'Solicitar Retiro',
    'status' => 'Estado de la Transacción',

    'edit_wallet' => 'Editar Estado de Transacción',
    'form_status' => 'Estado de Transacción',
    'form_status_description' => 'EJ: Declinado, Completado, etc.',

];
