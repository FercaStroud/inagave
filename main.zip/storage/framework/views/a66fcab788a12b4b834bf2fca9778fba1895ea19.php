
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>" />

    <meta name="application-name" content="<?php echo e(config('app.name', 'Laravel')); ?>">

    <meta name="theme-color" content="#3A7C8D">

    <meta name="apple-mobile-web-app-title" content="<?php echo e(config('app.name', 'Laravel')); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link rel="apple-touch-icon-precomposed" sizes="60x60" href="<?php echo e(asset('assets/icons/icon-60x60.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="<?php echo e(asset('assets/icons/icon-76x76.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="<?php echo e(asset('assets/icons/icon-120x120.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo e(asset('assets/icons/icon-152x152.png')); ?>" />

    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('assets/icons/icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('assets/icons/icon-96x96.png')); ?>">

    <link rel="shortcut icon" href="<?php echo e(url('favicon.ico')); ?>">

    <base href="<?php echo e(url('/')); ?>">
</head>
<body>
    <div id="app">
        <div id="vue-loading"><?php echo e(__('strings.loading')); ?>...</div>
    </div>

    <script>
      let authenticated = <?php echo e(Auth::guest() ? 'false' : 'true'); ?>;
    </script>
    <script src="https://sdk.mercadopago.com/js/v2"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\carde\Projects\inagave\resources\views/app.blade.php ENDPATH**/ ?>