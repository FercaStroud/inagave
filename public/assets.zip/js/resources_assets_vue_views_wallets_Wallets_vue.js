(self["webpackChunklaravel_vue_boilerplate"] = self["webpackChunklaravel_vue_boilerplate"] || []).push([["resources_assets_vue_views_wallets_Wallets_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var _components_WalletsList_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/WalletsList.vue */ "./resources/assets/vue/views/wallets/components/WalletsList.vue");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};





var Wallets =
/** @class */
function (_super) {
  __extends(Wallets, _super);

  function Wallets() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  Wallets.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.setBackUrl('/');
        this.setMenu([]);
        return [2
        /*return*/
        ];
      });
    });
  };

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Wallets.prototype, "setBackUrl", void 0);

  __decorate([vuex_class__WEBPACK_IMPORTED_MODULE_1__.Action], Wallets.prototype, "setMenu", void 0);

  Wallets = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {
      WalletsList: _components_WalletsList_vue__WEBPACK_IMPORTED_MODULE_2__.default
    }
  })], Wallets);
  return Wallets;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wallets);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuex_class__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex-class */ "./node_modules/vuex-class/lib/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
    if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  }
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
    label: 0,
    sent: function sent() {
      if (t[0] & 1) throw t[1];
      return t[1];
    },
    trys: [],
    ops: []
  },
      f,
      y,
      t,
      g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;

  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }

  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");

    while (_) {
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];

        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;

          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;

          case 7:
            op = _.ops.pop();

            _.trys.pop();

            continue;

          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }

            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }

            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }

            if (t && _.label < t[2]) {
              _.label = t[2];

              _.ops.push(op);

              break;
            }

            if (t[2]) _.ops.pop();

            _.trys.pop();

            continue;
        }

        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    }

    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};




var wStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('wallets');
var uStore = (0,vuex_class__WEBPACK_IMPORTED_MODULE_1__.namespace)('users');

var WalletsList =
/** @class */
function (_super) {
  __extends(WalletsList, _super);

  function WalletsList() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  WalletsList.prototype.created = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            if (!(this.wallets.length == 0)) return [3
            /*break*/
            , 4];
            if (!(this.actualUser.type_id === 2)) return [3
            /*break*/
            , 2];
            return [4
            /*yield*/
            , this.getUserWallets()];

          case 1:
            _a.sent();

            return [3
            /*break*/
            , 4];

          case 2:
            return [4
            /*yield*/
            , this.getAllWallets()];

          case 3:
            _a.sent();

            _a.label = 4;

          case 4:
            return [4
            /*yield*/
            , this.getUserStats()];

          case 5:
            _a.sent();

            return [2
            /*return*/
            ];
        }
      });
    });
  };

  Object.defineProperty(WalletsList.prototype, "actualUser", {
    get: function get() {
      return this.$store.state.auth.user;
    },
    enumerable: false,
    configurable: true
  });

  WalletsList.prototype.getAllWallets = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadWallets();
        return [2
        /*return*/
        ];
      });
    });
  };

  WalletsList.prototype.getUserWallets = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadUserWallet();
        return [2
        /*return*/
        ];
      });
    });
  };

  WalletsList.prototype.getUserStats = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        this.loadUserStats();
        return [2
        /*return*/
        ];
      });
    });
  };

  WalletsList.prototype.requestWithdraw = function () {
    return __awaiter(this, void 0, void 0, function () {
      var response, _a;

      return __generator(this, function (_b) {
        switch (_b.label) {
          case 0:
            if (!(this.form.amount > this.stats.total_user_founds)) return [3
            /*break*/
            , 1];
            this.$bvModal.msgBoxOk('' + this.$t('errors.max_error'));
            return [3
            /*break*/
            , 9];

          case 1:
            if (!(this.form.account === '' || this.form.bank === '')) return [3
            /*break*/
            , 2];
            this.$bvModal.msgBoxOk('' + this.$t('errors.generic_error'));
            return [3
            /*break*/
            , 9];

          case 2:
            this.setLoading(true);
            _b.label = 3;

          case 3:
            _b.trys.push([3, 5, 6, 9]);

            return [4
            /*yield*/
            , axios__WEBPACK_IMPORTED_MODULE_2___default().post('request/withdraw', this.form)];

          case 4:
            response = _b.sent();
            return [3
            /*break*/
            , 9];

          case 5:
            _a = _b.sent();
            this.$bvModal.msgBoxOk('' + this.$t('errors.generic_error'));
            return [3
            /*break*/
            , 9];

          case 6:
            this.setLoading(false);
            return [4
            /*yield*/
            , this.getUserWallets()];

          case 7:
            _b.sent();

            return [4
            /*yield*/
            , this.getUserStats()];

          case 8:
            _b.sent();

            this.setModalVisible(false);
            return [7
            /*endfinally*/
            ];

          case 9:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  WalletsList.prototype.changeStatus = function (wallet) {
    return __awaiter(this, void 0, void 0, function () {
      var response, _a;

      return __generator(this, function (_b) {
        switch (_b.label) {
          case 0:
            this.setLoading(true);
            _b.label = 1;

          case 1:
            _b.trys.push([1, 3, 4, 5]);

            return [4
            /*yield*/
            , axios__WEBPACK_IMPORTED_MODULE_2___default().post('approve/user/request', wallet)];

          case 2:
            response = _b.sent();
            return [3
            /*break*/
            , 5];

          case 3:
            _a = _b.sent();
            this.$bvModal.msgBoxOk('' + this.$t('errors.generic_error'));
            return [3
            /*break*/
            , 5];

          case 4:
            this.loadWallets();
            return [7
            /*endfinally*/
            ];

          case 5:
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  __decorate([wStore.State], WalletsList.prototype, "wallets", void 0);

  __decorate([wStore.State], WalletsList.prototype, "fields", void 0);

  __decorate([wStore.State], WalletsList.prototype, "form", void 0);

  __decorate([wStore.State], WalletsList.prototype, "isLoading", void 0);

  __decorate([wStore.State], WalletsList.prototype, "isModalVisible", void 0);

  __decorate([wStore.Action], WalletsList.prototype, "loadWallets", void 0);

  __decorate([wStore.Action], WalletsList.prototype, "loadUserWallet", void 0);

  __decorate([wStore.Action], WalletsList.prototype, "setModalVisible", void 0);

  __decorate([wStore.Action], WalletsList.prototype, "setLoading", void 0);

  __decorate([uStore.State], WalletsList.prototype, "stats", void 0);

  __decorate([uStore.Action], WalletsList.prototype, "setUserStats", void 0);

  __decorate([uStore.Action], WalletsList.prototype, "loadUserStats", void 0);

  WalletsList = __decorate([(0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
    components: {}
  })], WalletsList);
  return WalletsList;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletsList);

/***/ }),

/***/ "./resources/assets/vue/views/wallets/Wallets.vue":
/*!********************************************************!*\
  !*** ./resources/assets/vue/views/wallets/Wallets.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Wallets.vue?vue&type=template&id=22f65347&lang=pug& */ "./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug&");
/* harmony import */ var _Wallets_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Wallets.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _Wallets_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/wallets/Wallets.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/wallets/components/WalletsList.vue":
/*!***********************************************************************!*\
  !*** ./resources/assets/vue/views/wallets/components/WalletsList.vue ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug& */ "./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug&");
/* harmony import */ var _WalletsList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WalletsList.vue?vue&type=script&lang=ts& */ "./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _WalletsList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__.default,
  _WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render,
  _WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "7380ca02",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/assets/vue/views/wallets/components/WalletsList.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts&":
/*!*********************************************************************************!*\
  !*** ./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Wallets_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Wallets.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Wallets_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts&":
/*!************************************************************************************************!*\
  !*** ./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletsList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletsList.vue?vue&type=script&lang=ts& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/ts-loader/index.js??clonedRuleSet-22[0].rules[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=script&lang=ts&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_ts_loader_index_js_clonedRuleSet_22_0_rules_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletsList_vue_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug&":
/*!************************************************************************************************!*\
  !*** ./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Wallets_vue_vue_type_template_id_22f65347_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/pug-plain-loader/index.js!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Wallets.vue?vue&type=template&id=22f65347&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug&");


/***/ }),

/***/ "./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug& ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_pug_plain_loader_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletsList_vue_vue_type_template_id_7380ca02_scoped_true_lang_pug___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/pug-plain-loader/index.js!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug&":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/Wallets.vue?vue&type=template&id=22f65347&lang=pug& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-container",
    { attrs: { tag: "main", fluid: "" } },
    [
      _c(
        "b-row",
        [_c("b-col", { staticClass: "mt-3" }, [_c("WalletsList")], 1)],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader/index.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/assets/vue/views/wallets/components/WalletsList.vue?vue&type=template&id=7380ca02&scoped=true&lang=pug& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-container",
        { attrs: { fluid: "" } },
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { md: "8", sm: "12" } }, [
                _c("h2", [_vm._v(_vm._s(_vm.$t("wallets.title")))])
              ]),
              this.actualUser.type_id === 2
                ? _c("b-col", { attrs: { md: "4", sm: "12" } }, [
                    _c(
                      "div",
                      {
                        staticClass:
                          "text-center font-weight-bold text-info montserrat"
                      },
                      [
                        _vm._v(
                          _vm._s(_vm.$t("strings.total_wallet_user")) + ":"
                        )
                      ]
                    ),
                    _c(
                      "p",
                      {
                        staticClass:
                          "font-weight-bold text-center text-danger montserrat",
                        staticStyle: { "font-size": "2em" }
                      },
                      [
                        _vm._v(
                          "$" +
                            _vm._s(
                              _vm.stats.total_user_founds
                                .toFixed(2)
                                .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                            ) +
                            " (MXN)"
                        )
                      ]
                    )
                  ])
                : _vm._e()
            ],
            1
          )
        ],
        1
      ),
      _c(
        "b-modal",
        {
          attrs: { "hide-header-close": "", centered: "", "hide-footer": "" },
          on: {
            hide: function($event) {
              _vm.form.amount = 0
              _vm.form.account = ""
              _vm.form.bank = ""
              _vm.setModalVisible(false)
            }
          },
          model: {
            value: _vm.isModalVisible,
            callback: function($$v) {
              _vm.isModalVisible = $$v
            },
            expression: "isModalVisible"
          }
        },
        [
          _c(
            "b-container",
            { attrs: { fluid: "" } },
            [
              _c(
                "b-row",
                [
                  _c("b-col", { attrs: { md: "12" } }, [
                    _c(
                      "div",
                      {
                        staticClass:
                          "text-center font-weight-bold text-info montserrat"
                      },
                      [
                        _vm._v(
                          _vm._s(_vm.$t("strings.total_wallet_user")) + ":"
                        )
                      ]
                    ),
                    _c(
                      "p",
                      {
                        staticClass:
                          "font-weight-bold text-center text-danger montserrat",
                        staticStyle: { "font-size": "2em" }
                      },
                      [
                        _vm._v(
                          "$" +
                            _vm._s(
                              _vm.stats.total_user_founds
                                .toFixed(2)
                                .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                            ) +
                            " (MXN)"
                        )
                      ]
                    )
                  ]),
                  _c(
                    "b-col",
                    { attrs: { md: "12" } },
                    [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-left font-weight-bold text-info montserrat"
                        },
                        [_vm._v(_vm._s(_vm.$t("wallets.amount")) + ":")]
                      ),
                      _c("b-form-input", {
                        attrs: {
                          type: "number",
                          min: "0",
                          step: "0.01",
                          max: _vm.stats.total_user_founds
                        },
                        model: {
                          value: _vm.form.amount,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "amount", $$v)
                          },
                          expression: "form.amount"
                        }
                      })
                    ],
                    1
                  ),
                  _c(
                    "b-col",
                    { staticClass: "mt-3", attrs: { md: "12" } },
                    [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-left font-weight-bold text-info montserrat"
                        },
                        [_vm._v(_vm._s(_vm.$t("wallets.bank")) + ":")]
                      ),
                      _c("b-form-input", {
                        attrs: { type: "text" },
                        model: {
                          value: _vm.form.bank,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "bank", $$v)
                          },
                          expression: "form.bank"
                        }
                      })
                    ],
                    1
                  ),
                  _c(
                    "b-col",
                    { staticClass: "mt-3", attrs: { md: "12" } },
                    [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-left font-weight-bold text-info montserrat"
                        },
                        [_vm._v(_vm._s(_vm.$t("wallets.account")) + ":")]
                      ),
                      _c("b-form-input", {
                        attrs: { type: "text" },
                        model: {
                          value: _vm.form.account,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "account", $$v)
                          },
                          expression: "form.account"
                        }
                      })
                    ],
                    1
                  ),
                  _c(
                    "b-col",
                    { staticClass: "mt-3", attrs: { md: "12" } },
                    [
                      !_vm.isLoading
                        ? _c(
                            "b-button",
                            {
                              staticStyle: { "margin-bottom": "5px" },
                              attrs: { variant: "success", block: "" },
                              on: { click: _vm.requestWithdraw }
                            },
                            [_vm._v(_vm._s(_vm.$t("strings.request")))]
                          )
                        : _c(
                            "b-button",
                            {
                              attrs: {
                                variant: "warning",
                                disabled: "",
                                block: ""
                              }
                            },
                            [
                              _c("b-spinner", {
                                attrs: {
                                  small: "",
                                  variant: "light",
                                  type: "grow"
                                }
                              })
                            ],
                            1
                          )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm.actualUser.type_id === 2
        ? _c(
            "b-button",
            {
              staticStyle: { "margin-bottom": "5px" },
              attrs: { size: "sm", variant: "outline-primary" },
              on: { click: _vm.getUserWallets }
            },
            [_vm._v(_vm._s(_vm.$t("strings.update_table")))]
          )
        : _c(
            "b-button",
            {
              staticStyle: { "margin-bottom": "5px" },
              attrs: { size: "sm", variant: "outline-primary" },
              on: { click: _vm.getAllWallets }
            },
            [_vm._v(_vm._s(_vm.$t("strings.update_table")))]
          ),
      _vm.actualUser.type_id === 2
        ? _c(
            "b-button",
            {
              staticClass: "ml-2",
              staticStyle: { "margin-bottom": "5px" },
              attrs: { size: "sm", variant: "warning" },
              on: {
                click: function($event) {
                  _vm.form.amount = 0
                  _vm.form.account = ""
                  _vm.form.bank = ""
                  _vm.setModalVisible(true)
                }
              }
            },
            [_vm._v(_vm._s(_vm.$t("wallets.request")))]
          )
        : _vm._e(),
      _c("b-table", {
        staticClass: "btable",
        staticStyle: {
          "max-height": "calc(100vh - 191px)",
          "font-size": ".75em"
        },
        attrs: {
          striped: "",
          hover: "",
          responsive: "",
          "sticky-header": "",
          "no-border-collapse": "",
          bordered: "",
          outlined: "",
          "head-variant": "dark",
          busy: _vm.isLoading,
          items: _vm.wallets,
          fields: _vm.fields,
          "select-mode": "single",
          small: ""
        },
        scopedSlots: _vm._u([
          {
            key: "table-busy",
            fn: function() {
              return [
                _c(
                  "div",
                  { staticClass: "text-center text-danger" },
                  [_c("b-spinner", { staticClass: "align-middle" })],
                  1
                )
              ]
            },
            proxy: true
          },
          {
            key: "head(user_name)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.user_name")))])]
            }
          },
          {
            key: "head(status)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.status")))])]
            }
          },
          {
            key: "head(amount)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.amount")))])]
            }
          },
          {
            key: "head(bank)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.bank")))])]
            }
          },
          {
            key: "head(account)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.account")))])]
            }
          },
          {
            key: "head(type)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("wallets.type")))])]
            }
          },
          {
            key: "head(created_at)",
            fn: function(data) {
              return [
                _c("span", [_vm._v(_vm._s(_vm.$t("strings.created_at")))])
              ]
            }
          },
          {
            key: "head(details)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(_vm.$t("strings.details")))])]
            }
          },
          {
            key: "cell(user_name)",
            fn: function(data) {
              return [
                _c("span", [
                  _vm._v(
                    _vm._s(data.item.user.name) +
                      " " +
                      _vm._s(data.item.user.lastname)
                  )
                ])
              ]
            }
          },
          {
            key: "cell(created_at)",
            fn: function(data) {
              return [
                _c("span", [
                  _vm._v(
                    _vm._s(
                      _vm._f("moment")(data.item.created_at, "D, MMMM YYYY")
                    )
                  )
                ])
              ]
            }
          },
          {
            key: "cell(details)",
            fn: function(data) {
              return [
                _c(
                  "b-button",
                  {
                    staticStyle: { "font-size": ".8em" },
                    attrs: {
                      variant: "outline-primary",
                      title:
                        (data.detailsShowing
                          ? _vm.$t("strings.hide")
                          : _vm.$t("strings.show")) +
                        " " +
                        _vm.$t("strings.details")
                    },
                    on: { click: data.toggleDetails }
                  },
                  [
                    _c("span", [
                      _vm._v(
                        _vm._s(
                          data.detailsShowing
                            ? _vm.$t("strings.hide")
                            : _vm.$t("strings.show")
                        ) +
                          " " +
                          _vm._s(_vm.$t("strings.details"))
                      )
                    ])
                  ]
                )
              ]
            }
          },
          {
            key: "cell(amount)",
            fn: function(data) {
              return [
                data.item.type === "DEPOSIT"
                  ? _c("strong", { staticClass: "text-success" }, [
                      _vm._v(
                        "+ $" +
                          _vm._s(
                            parseInt(data.item.amount)
                              .toFixed(2)
                              .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                          ) +
                          " (MXN)"
                      )
                    ])
                  : _c("strong", { staticClass: "text-danger" }, [
                      _vm._v(
                        "- $" +
                          _vm._s(
                            parseInt(data.item.amount)
                              .toFixed(2)
                              .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                          ) +
                          " (MXN)"
                      )
                    ])
              ]
            }
          },
          {
            key: "cell(actions)",
            fn: function(data) {
              return [
                _vm.actualUser.type_id !== 2 && data.item.status === "PENDING"
                  ? _c(
                      "b-button",
                      {
                        staticStyle: { "font-size": ".8em" },
                        attrs: {
                          title: _vm.$t("strings.edit"),
                          variant: "warning"
                        },
                        on: {
                          click: function($event) {
                            return _vm.changeStatus(data.item)
                          }
                        }
                      },
                      [_vm._v(_vm._s(_vm.$t("strings.approve")))]
                    )
                  : _vm._e()
              ]
            }
          },
          {
            key: "row-details",
            fn: function(data) {
              return [
                _c(
                  "b-container",
                  { staticClass: "bg-primary", attrs: { fluid: "" } },
                  [
                    _c(
                      "b-row",
                      [
                        _c(
                          "b-col",
                          [
                            _c("b-table", {
                              staticClass: "mt-3 bg-white",
                              staticStyle: {
                                "max-height": "calc(100vh - 191px)"
                              },
                              attrs: {
                                striped: "",
                                hover: "",
                                responsive: "",
                                "sticky-header": "",
                                "no-border-collapse": "",
                                bordered: "",
                                small: "",
                                "head-variant": "dark",
                                items: data.item.transactions
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ]
            }
          },
          {
            key: "cell(index)",
            fn: function(data) {
              return [_c("span", [_vm._v(_vm._s(data.index + 1))])]
            }
          }
        ])
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3Mvd2FsbGV0cy9XYWxsZXRzLnZ1ZT9mMGY0Iiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy93YWxsZXRzL2NvbXBvbmVudHMvV2FsbGV0c0xpc3QudnVlP2UzZmQiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3dhbGxldHMvV2FsbGV0cy52dWU/Zjg3OSIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3Mvd2FsbGV0cy9jb21wb25lbnRzL1dhbGxldHNMaXN0LnZ1ZT8xMWJjIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy93YWxsZXRzL1dhbGxldHMudnVlPzU4M2QiLCJ3ZWJwYWNrLWdlbmVyYXRlZDovLy8uL3Jlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3dhbGxldHMvY29tcG9uZW50cy9XYWxsZXRzTGlzdC52dWU/ODIyMyIsIndlYnBhY2stZ2VuZXJhdGVkOi8vLy4vcmVzb3VyY2VzL2Fzc2V0cy92dWUvdmlld3Mvd2FsbGV0cy9XYWxsZXRzLnZ1ZT82MzczIiwid2VicGFjay1nZW5lcmF0ZWQ6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL3Z1ZS92aWV3cy93YWxsZXRzL2NvbXBvbmVudHMvV2FsbGV0c0xpc3QudnVlP2RkMTgiXSwibmFtZXMiOlsiX19leHRlbmRzIiwiZXh0ZW5kU3RhdGljcyIsImQiLCJiIiwiT2JqZWN0Iiwic2V0UHJvdG90eXBlT2YiLCJfX3Byb3RvX18iLCJBcnJheSIsInAiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJfXyIsImNvbnN0cnVjdG9yIiwiY3JlYXRlIiwiX19kZWNvcmF0ZSIsImRlY29yYXRvcnMiLCJ0YXJnZXQiLCJrZXkiLCJkZXNjIiwiYyIsImFyZ3VtZW50cyIsImxlbmd0aCIsInIiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJSZWZsZWN0IiwiZGVjb3JhdGUiLCJpIiwiZGVmaW5lUHJvcGVydHkiLCJfX2F3YWl0ZXIiLCJ0aGlzQXJnIiwiX2FyZ3VtZW50cyIsIlAiLCJnZW5lcmF0b3IiLCJhZG9wdCIsInZhbHVlIiwicmVzb2x2ZSIsIlByb21pc2UiLCJyZWplY3QiLCJmdWxmaWxsZWQiLCJzdGVwIiwibmV4dCIsImUiLCJyZWplY3RlZCIsInJlc3VsdCIsImRvbmUiLCJ0aGVuIiwiYXBwbHkiLCJfX2dlbmVyYXRvciIsImJvZHkiLCJfIiwibGFiZWwiLCJzZW50IiwidCIsInRyeXMiLCJvcHMiLCJmIiwieSIsImciLCJ2ZXJiIiwiU3ltYm9sIiwiaXRlcmF0b3IiLCJuIiwidiIsIm9wIiwicG9wIiwicHVzaCIsIldhbGxldHMiLCJfc3VwZXIiLCJjcmVhdGVkIiwiX2EiLCJzZXRCYWNrVXJsIiwic2V0TWVudSIsIkFjdGlvbiIsIkNvbXBvbmVudCIsImNvbXBvbmVudHMiLCJXYWxsZXRzTGlzdCIsIlZ1ZSIsIndTdG9yZSIsIm5hbWVzcGFjZSIsInVTdG9yZSIsIndhbGxldHMiLCJhY3R1YWxVc2VyIiwidHlwZV9pZCIsImdldFVzZXJXYWxsZXRzIiwiZ2V0QWxsV2FsbGV0cyIsImdldFVzZXJTdGF0cyIsImdldCIsIiRzdG9yZSIsInN0YXRlIiwiYXV0aCIsInVzZXIiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwibG9hZFdhbGxldHMiLCJsb2FkVXNlcldhbGxldCIsImxvYWRVc2VyU3RhdHMiLCJyZXF1ZXN0V2l0aGRyYXciLCJyZXNwb25zZSIsIl9iIiwiZm9ybSIsImFtb3VudCIsInN0YXRzIiwidG90YWxfdXNlcl9mb3VuZHMiLCIkYnZNb2RhbCIsIm1zZ0JveE9rIiwiJHQiLCJhY2NvdW50IiwiYmFuayIsInNldExvYWRpbmciLCJheGlvcyIsInNldE1vZGFsVmlzaWJsZSIsImNoYW5nZVN0YXR1cyIsIndhbGxldCIsIlN0YXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxTQUFTLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsU0FBZCxJQUE2QixZQUFZO0FBQ3JELE1BQUlDLGNBQWEsR0FBRyx1QkFBVUMsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ2hDRixrQkFBYSxHQUFHRyxNQUFNLENBQUNDLGNBQVAsSUFDWDtBQUFFQyxlQUFTLEVBQUU7QUFBYixpQkFBNkJDLEtBQTdCLElBQXNDLFVBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFRCxPQUFDLENBQUNJLFNBQUYsR0FBY0gsQ0FBZDtBQUFrQixLQUQvRCxJQUVaLFVBQVVELENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUFFLFdBQUssSUFBSUssQ0FBVCxJQUFjTCxDQUFkO0FBQWlCLFlBQUlDLE1BQU0sQ0FBQ0ssU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDUixDQUFyQyxFQUF3Q0ssQ0FBeEMsQ0FBSixFQUFnRE4sQ0FBQyxDQUFDTSxDQUFELENBQUQsR0FBT0wsQ0FBQyxDQUFDSyxDQUFELENBQVI7QUFBakU7QUFBK0UsS0FGckc7O0FBR0EsV0FBT1AsY0FBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBcEI7QUFDSCxHQUxEOztBQU1BLFNBQU8sVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ25CLFFBQUksT0FBT0EsQ0FBUCxLQUFhLFVBQWIsSUFBMkJBLENBQUMsS0FBSyxJQUFyQyxFQUNJLE1BQU0sSUFBSVMsU0FBSixDQUFjLHlCQUF5QkMsTUFBTSxDQUFDVixDQUFELENBQS9CLEdBQXFDLCtCQUFuRCxDQUFOOztBQUNKRixrQkFBYSxDQUFDQyxDQUFELEVBQUlDLENBQUosQ0FBYjs7QUFDQSxhQUFTVyxFQUFULEdBQWM7QUFBRSxXQUFLQyxXQUFMLEdBQW1CYixDQUFuQjtBQUF1Qjs7QUFDdkNBLEtBQUMsQ0FBQ08sU0FBRixHQUFjTixDQUFDLEtBQUssSUFBTixHQUFhQyxNQUFNLENBQUNZLE1BQVAsQ0FBY2IsQ0FBZCxDQUFiLElBQWlDVyxFQUFFLENBQUNMLFNBQUgsR0FBZU4sQ0FBQyxDQUFDTSxTQUFqQixFQUE0QixJQUFJSyxFQUFKLEVBQTdELENBQWQ7QUFDSCxHQU5EO0FBT0gsQ0FkMkMsRUFBNUM7O0FBZUEsSUFBSUcsVUFBVSxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFVBQWQsSUFBNkIsVUFBVUMsVUFBVixFQUFzQkMsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DQyxJQUFuQyxFQUF5QztBQUNuRixNQUFJQyxDQUFDLEdBQUdDLFNBQVMsQ0FBQ0MsTUFBbEI7QUFBQSxNQUEwQkMsQ0FBQyxHQUFHSCxDQUFDLEdBQUcsQ0FBSixHQUFRSCxNQUFSLEdBQWlCRSxJQUFJLEtBQUssSUFBVCxHQUFnQkEsSUFBSSxHQUFHakIsTUFBTSxDQUFDc0Isd0JBQVAsQ0FBZ0NQLE1BQWhDLEVBQXdDQyxHQUF4QyxDQUF2QixHQUFzRUMsSUFBckg7QUFBQSxNQUEySG5CLENBQTNIO0FBQ0EsTUFBSSxRQUFPeUIsT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUFuQixJQUErQixPQUFPQSxPQUFPLENBQUNDLFFBQWYsS0FBNEIsVUFBL0QsRUFBMkVILENBQUMsR0FBR0UsT0FBTyxDQUFDQyxRQUFSLENBQWlCVixVQUFqQixFQUE2QkMsTUFBN0IsRUFBcUNDLEdBQXJDLEVBQTBDQyxJQUExQyxDQUFKLENBQTNFLEtBQ0ssS0FBSyxJQUFJUSxDQUFDLEdBQUdYLFVBQVUsQ0FBQ00sTUFBWCxHQUFvQixDQUFqQyxFQUFvQ0ssQ0FBQyxJQUFJLENBQXpDLEVBQTRDQSxDQUFDLEVBQTdDO0FBQWlELFFBQUkzQixDQUFDLEdBQUdnQixVQUFVLENBQUNXLENBQUQsQ0FBbEIsRUFBdUJKLENBQUMsR0FBRyxDQUFDSCxDQUFDLEdBQUcsQ0FBSixHQUFRcEIsQ0FBQyxDQUFDdUIsQ0FBRCxDQUFULEdBQWVILENBQUMsR0FBRyxDQUFKLEdBQVFwQixDQUFDLENBQUNpQixNQUFELEVBQVNDLEdBQVQsRUFBY0ssQ0FBZCxDQUFULEdBQTRCdkIsQ0FBQyxDQUFDaUIsTUFBRCxFQUFTQyxHQUFULENBQTdDLEtBQStESyxDQUFuRTtBQUF4RTtBQUNMLFNBQU9ILENBQUMsR0FBRyxDQUFKLElBQVNHLENBQVQsSUFBY3JCLE1BQU0sQ0FBQzBCLGNBQVAsQ0FBc0JYLE1BQXRCLEVBQThCQyxHQUE5QixFQUFtQ0ssQ0FBbkMsQ0FBZCxFQUFxREEsQ0FBNUQ7QUFDSCxDQUxEOztBQU1BLElBQUlNLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTRCLFVBQVVDLE9BQVYsRUFBbUJDLFVBQW5CLEVBQStCQyxDQUEvQixFQUFrQ0MsU0FBbEMsRUFBNkM7QUFDckYsV0FBU0MsS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQUUsV0FBT0EsS0FBSyxZQUFZSCxDQUFqQixHQUFxQkcsS0FBckIsR0FBNkIsSUFBSUgsQ0FBSixDQUFNLFVBQVVJLE9BQVYsRUFBbUI7QUFBRUEsYUFBTyxDQUFDRCxLQUFELENBQVA7QUFBaUIsS0FBNUMsQ0FBcEM7QUFBb0Y7O0FBQzVHLFNBQU8sS0FBS0gsQ0FBQyxLQUFLQSxDQUFDLEdBQUdLLE9BQVQsQ0FBTixFQUF5QixVQUFVRCxPQUFWLEVBQW1CRSxNQUFuQixFQUEyQjtBQUN2RCxhQUFTQyxTQUFULENBQW1CSixLQUFuQixFQUEwQjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUNRLElBQVYsQ0FBZU4sS0FBZixDQUFELENBQUo7QUFBOEIsT0FBcEMsQ0FBcUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDM0YsYUFBU0MsUUFBVCxDQUFrQlIsS0FBbEIsRUFBeUI7QUFBRSxVQUFJO0FBQUVLLFlBQUksQ0FBQ1AsU0FBUyxDQUFDLE9BQUQsQ0FBVCxDQUFtQkUsS0FBbkIsQ0FBRCxDQUFKO0FBQWtDLE9BQXhDLENBQXlDLE9BQU9PLENBQVAsRUFBVTtBQUFFSixjQUFNLENBQUNJLENBQUQsQ0FBTjtBQUFZO0FBQUU7O0FBQzlGLGFBQVNGLElBQVQsQ0FBY0ksTUFBZCxFQUFzQjtBQUFFQSxZQUFNLENBQUNDLElBQVAsR0FBY1QsT0FBTyxDQUFDUSxNQUFNLENBQUNULEtBQVIsQ0FBckIsR0FBc0NELEtBQUssQ0FBQ1UsTUFBTSxDQUFDVCxLQUFSLENBQUwsQ0FBb0JXLElBQXBCLENBQXlCUCxTQUF6QixFQUFvQ0ksUUFBcEMsQ0FBdEM7QUFBc0Y7O0FBQzlHSCxRQUFJLENBQUMsQ0FBQ1AsU0FBUyxHQUFHQSxTQUFTLENBQUNjLEtBQVYsQ0FBZ0JqQixPQUFoQixFQUF5QkMsVUFBVSxJQUFJLEVBQXZDLENBQWIsRUFBeURVLElBQXpELEVBQUQsQ0FBSjtBQUNILEdBTE0sQ0FBUDtBQU1ILENBUkQ7O0FBU0EsSUFBSU8sV0FBVyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFdBQWQsSUFBOEIsVUFBVWxCLE9BQVYsRUFBbUJtQixJQUFuQixFQUF5QjtBQUNyRSxNQUFJQyxDQUFDLEdBQUc7QUFBRUMsU0FBSyxFQUFFLENBQVQ7QUFBWUMsUUFBSSxFQUFFLGdCQUFXO0FBQUUsVUFBSUMsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQVgsRUFBYyxNQUFNQSxDQUFDLENBQUMsQ0FBRCxDQUFQO0FBQVksYUFBT0EsQ0FBQyxDQUFDLENBQUQsQ0FBUjtBQUFjLEtBQXZFO0FBQXlFQyxRQUFJLEVBQUUsRUFBL0U7QUFBbUZDLE9BQUcsRUFBRTtBQUF4RixHQUFSO0FBQUEsTUFBc0dDLENBQXRHO0FBQUEsTUFBeUdDLENBQXpHO0FBQUEsTUFBNEdKLENBQTVHO0FBQUEsTUFBK0dLLENBQS9HO0FBQ0EsU0FBT0EsQ0FBQyxHQUFHO0FBQUVqQixRQUFJLEVBQUVrQixJQUFJLENBQUMsQ0FBRCxDQUFaO0FBQWlCLGFBQVNBLElBQUksQ0FBQyxDQUFELENBQTlCO0FBQW1DLGNBQVVBLElBQUksQ0FBQyxDQUFEO0FBQWpELEdBQUosRUFBNEQsT0FBT0MsTUFBUCxLQUFrQixVQUFsQixLQUFpQ0YsQ0FBQyxDQUFDRSxNQUFNLENBQUNDLFFBQVIsQ0FBRCxHQUFxQixZQUFXO0FBQUUsV0FBTyxJQUFQO0FBQWMsR0FBakYsQ0FBNUQsRUFBZ0pILENBQXZKOztBQUNBLFdBQVNDLElBQVQsQ0FBY0csQ0FBZCxFQUFpQjtBQUFFLFdBQU8sVUFBVUMsQ0FBVixFQUFhO0FBQUUsYUFBT3ZCLElBQUksQ0FBQyxDQUFDc0IsQ0FBRCxFQUFJQyxDQUFKLENBQUQsQ0FBWDtBQUFzQixLQUE1QztBQUErQzs7QUFDbEUsV0FBU3ZCLElBQVQsQ0FBY3dCLEVBQWQsRUFBa0I7QUFDZCxRQUFJUixDQUFKLEVBQU8sTUFBTSxJQUFJOUMsU0FBSixDQUFjLGlDQUFkLENBQU47O0FBQ1AsV0FBT3dDLENBQVA7QUFBVSxVQUFJO0FBQ1YsWUFBSU0sQ0FBQyxHQUFHLENBQUosRUFBT0MsQ0FBQyxLQUFLSixDQUFDLEdBQUdXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFSLEdBQVlQLENBQUMsQ0FBQyxRQUFELENBQWIsR0FBMEJPLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUVAsQ0FBQyxDQUFDLE9BQUQsQ0FBRCxLQUFlLENBQUNKLENBQUMsR0FBR0ksQ0FBQyxDQUFDLFFBQUQsQ0FBTixLQUFxQkosQ0FBQyxDQUFDNUMsSUFBRixDQUFPZ0QsQ0FBUCxDQUFyQixFQUFnQyxDQUEvQyxDQUFSLEdBQTREQSxDQUFDLENBQUNoQixJQUFqRyxDQUFELElBQTJHLENBQUMsQ0FBQ1ksQ0FBQyxHQUFHQSxDQUFDLENBQUM1QyxJQUFGLENBQU9nRCxDQUFQLEVBQVVPLEVBQUUsQ0FBQyxDQUFELENBQVosQ0FBTCxFQUF1Qm5CLElBQTlJLEVBQW9KLE9BQU9RLENBQVA7QUFDcEosWUFBSUksQ0FBQyxHQUFHLENBQUosRUFBT0osQ0FBWCxFQUFjVyxFQUFFLEdBQUcsQ0FBQ0EsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVQsRUFBWVgsQ0FBQyxDQUFDbEIsS0FBZCxDQUFMOztBQUNkLGdCQUFRNkIsRUFBRSxDQUFDLENBQUQsQ0FBVjtBQUNJLGVBQUssQ0FBTDtBQUFRLGVBQUssQ0FBTDtBQUFRWCxhQUFDLEdBQUdXLEVBQUo7QUFBUTs7QUFDeEIsZUFBSyxDQUFMO0FBQVFkLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXLG1CQUFPO0FBQUVoQixtQkFBSyxFQUFFNkIsRUFBRSxDQUFDLENBQUQsQ0FBWDtBQUFnQm5CLGtCQUFJLEVBQUU7QUFBdEIsYUFBUDs7QUFDbkIsZUFBSyxDQUFMO0FBQVFLLGFBQUMsQ0FBQ0MsS0FBRjtBQUFXTSxhQUFDLEdBQUdPLEVBQUUsQ0FBQyxDQUFELENBQU47QUFBV0EsY0FBRSxHQUFHLENBQUMsQ0FBRCxDQUFMO0FBQVU7O0FBQ3hDLGVBQUssQ0FBTDtBQUFRQSxjQUFFLEdBQUdkLENBQUMsQ0FBQ0ssR0FBRixDQUFNVSxHQUFOLEVBQUw7O0FBQWtCZixhQUFDLENBQUNJLElBQUYsQ0FBT1csR0FBUDs7QUFBYzs7QUFDeEM7QUFDSSxnQkFBSSxFQUFFWixDQUFDLEdBQUdILENBQUMsQ0FBQ0ksSUFBTixFQUFZRCxDQUFDLEdBQUdBLENBQUMsQ0FBQy9CLE1BQUYsR0FBVyxDQUFYLElBQWdCK0IsQ0FBQyxDQUFDQSxDQUFDLENBQUMvQixNQUFGLEdBQVcsQ0FBWixDQUFuQyxNQUF1RDBDLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFoRixDQUFKLEVBQXdGO0FBQUVkLGVBQUMsR0FBRyxDQUFKO0FBQU87QUFBVzs7QUFDNUcsZ0JBQUljLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLEtBQWdCLENBQUNYLENBQUQsSUFBT1csRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRWCxDQUFDLENBQUMsQ0FBRCxDQUFULElBQWdCVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFYLENBQUMsQ0FBQyxDQUFELENBQWhELENBQUosRUFBMkQ7QUFBRUgsZUFBQyxDQUFDQyxLQUFGLEdBQVVhLEVBQUUsQ0FBQyxDQUFELENBQVo7QUFBaUI7QUFBUTs7QUFDdEYsZ0JBQUlBLEVBQUUsQ0FBQyxDQUFELENBQUYsS0FBVSxDQUFWLElBQWVkLENBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUE5QixFQUFtQztBQUFFSCxlQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBWDtBQUFnQkEsZUFBQyxHQUFHVyxFQUFKO0FBQVE7QUFBUTs7QUFDckUsZ0JBQUlYLENBQUMsSUFBSUgsQ0FBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQXBCLEVBQXlCO0FBQUVILGVBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUFYOztBQUFnQkgsZUFBQyxDQUFDSyxHQUFGLENBQU1XLElBQU4sQ0FBV0YsRUFBWDs7QUFBZ0I7QUFBUTs7QUFDbkUsZ0JBQUlYLENBQUMsQ0FBQyxDQUFELENBQUwsRUFBVUgsQ0FBQyxDQUFDSyxHQUFGLENBQU1VLEdBQU47O0FBQ1ZmLGFBQUMsQ0FBQ0ksSUFBRixDQUFPVyxHQUFQOztBQUFjO0FBWHRCOztBQWFBRCxVQUFFLEdBQUdmLElBQUksQ0FBQ3hDLElBQUwsQ0FBVXFCLE9BQVYsRUFBbUJvQixDQUFuQixDQUFMO0FBQ0gsT0FqQlMsQ0FpQlIsT0FBT1IsQ0FBUCxFQUFVO0FBQUVzQixVQUFFLEdBQUcsQ0FBQyxDQUFELEVBQUl0QixDQUFKLENBQUw7QUFBYWUsU0FBQyxHQUFHLENBQUo7QUFBUSxPQWpCekIsU0FpQmtDO0FBQUVELFNBQUMsR0FBR0gsQ0FBQyxHQUFHLENBQVI7QUFBWTtBQWpCMUQ7O0FBa0JBLFFBQUlXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUSxDQUFaLEVBQWUsTUFBTUEsRUFBRSxDQUFDLENBQUQsQ0FBUjtBQUFhLFdBQU87QUFBRTdCLFdBQUssRUFBRTZCLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUUEsRUFBRSxDQUFDLENBQUQsQ0FBVixHQUFnQixLQUFLLENBQTlCO0FBQWlDbkIsVUFBSSxFQUFFO0FBQXZDLEtBQVA7QUFDL0I7QUFDSixDQTFCRDs7QUEyQkE7QUFDQTtBQUNBOztBQUNBLElBQUlzQixPQUFPO0FBQUc7QUFBZSxVQUFVQyxNQUFWLEVBQWtCO0FBQzNDdEUsV0FBUyxDQUFDcUUsT0FBRCxFQUFVQyxNQUFWLENBQVQ7O0FBQ0EsV0FBU0QsT0FBVCxHQUFtQjtBQUNmLFdBQU9DLE1BQU0sS0FBSyxJQUFYLElBQW1CQSxNQUFNLENBQUNyQixLQUFQLENBQWEsSUFBYixFQUFtQjFCLFNBQW5CLENBQW5CLElBQW9ELElBQTNEO0FBQ0g7O0FBQ0Q4QyxTQUFPLENBQUM1RCxTQUFSLENBQWtCOEQsT0FBbEIsR0FBNEIsWUFBWTtBQUNwQyxXQUFPeEMsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT21CLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVXNCLEVBQVYsRUFBYztBQUNuQyxhQUFLQyxVQUFMLENBQWdCLEdBQWhCO0FBQ0EsYUFBS0MsT0FBTCxDQUFhLEVBQWI7QUFDQSxlQUFPLENBQUM7QUFBRTtBQUFILFNBQVA7QUFDSCxPQUppQixDQUFsQjtBQUtILEtBTmUsQ0FBaEI7QUFPSCxHQVJEOztBQVNBekQsWUFBVSxDQUFDLENBQ1AwRCw4Q0FETyxDQUFELEVBRVBOLE9BQU8sQ0FBQzVELFNBRkQsRUFFWSxZQUZaLEVBRTBCLEtBQUssQ0FGL0IsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1AwRCw4Q0FETyxDQUFELEVBRVBOLE9BQU8sQ0FBQzVELFNBRkQsRUFFWSxTQUZaLEVBRXVCLEtBQUssQ0FGNUIsQ0FBVjs7QUFHQTRELFNBQU8sR0FBR3BELFVBQVUsQ0FBQyxDQUNqQjJELGlFQUFTLENBQUM7QUFDTkMsY0FBVSxFQUFFO0FBQ1JDLGlCQUFXLEVBQUVBLGdFQUFXQTtBQURoQjtBQUROLEdBQUQsQ0FEUSxDQUFELEVBTWpCVCxPQU5pQixDQUFwQjtBQU9BLFNBQU9BLE9BQVA7QUFDSCxDQTVCNEIsQ0E0QjNCVSx1REE1QjJCLENBQTdCOztBQTZCQSxpRUFBZVYsT0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6RkEsSUFBSXJFLFNBQVMsR0FBSSxTQUFJLElBQUksU0FBSSxDQUFDQSxTQUFkLElBQTZCLFlBQVk7QUFDckQsTUFBSUMsY0FBYSxHQUFHLHVCQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDaENGLGtCQUFhLEdBQUdHLE1BQU0sQ0FBQ0MsY0FBUCxJQUNYO0FBQUVDLGVBQVMsRUFBRTtBQUFiLGlCQUE2QkMsS0FBN0IsSUFBc0MsVUFBVUwsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUVELE9BQUMsQ0FBQ0ksU0FBRixHQUFjSCxDQUFkO0FBQWtCLEtBRC9ELElBRVosVUFBVUQsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQUUsV0FBSyxJQUFJSyxDQUFULElBQWNMLENBQWQ7QUFBaUIsWUFBSUMsTUFBTSxDQUFDSyxTQUFQLENBQWlCQyxjQUFqQixDQUFnQ0MsSUFBaEMsQ0FBcUNSLENBQXJDLEVBQXdDSyxDQUF4QyxDQUFKLEVBQWdETixDQUFDLENBQUNNLENBQUQsQ0FBRCxHQUFPTCxDQUFDLENBQUNLLENBQUQsQ0FBUjtBQUFqRTtBQUErRSxLQUZyRzs7QUFHQSxXQUFPUCxjQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFwQjtBQUNILEdBTEQ7O0FBTUEsU0FBTyxVQUFVRCxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDbkIsUUFBSSxPQUFPQSxDQUFQLEtBQWEsVUFBYixJQUEyQkEsQ0FBQyxLQUFLLElBQXJDLEVBQ0ksTUFBTSxJQUFJUyxTQUFKLENBQWMseUJBQXlCQyxNQUFNLENBQUNWLENBQUQsQ0FBL0IsR0FBcUMsK0JBQW5ELENBQU47O0FBQ0pGLGtCQUFhLENBQUNDLENBQUQsRUFBSUMsQ0FBSixDQUFiOztBQUNBLGFBQVNXLEVBQVQsR0FBYztBQUFFLFdBQUtDLFdBQUwsR0FBbUJiLENBQW5CO0FBQXVCOztBQUN2Q0EsS0FBQyxDQUFDTyxTQUFGLEdBQWNOLENBQUMsS0FBSyxJQUFOLEdBQWFDLE1BQU0sQ0FBQ1ksTUFBUCxDQUFjYixDQUFkLENBQWIsSUFBaUNXLEVBQUUsQ0FBQ0wsU0FBSCxHQUFlTixDQUFDLENBQUNNLFNBQWpCLEVBQTRCLElBQUlLLEVBQUosRUFBN0QsQ0FBZDtBQUNILEdBTkQ7QUFPSCxDQWQyQyxFQUE1Qzs7QUFlQSxJQUFJRyxVQUFVLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsVUFBZCxJQUE2QixVQUFVQyxVQUFWLEVBQXNCQyxNQUF0QixFQUE4QkMsR0FBOUIsRUFBbUNDLElBQW5DLEVBQXlDO0FBQ25GLE1BQUlDLENBQUMsR0FBR0MsU0FBUyxDQUFDQyxNQUFsQjtBQUFBLE1BQTBCQyxDQUFDLEdBQUdILENBQUMsR0FBRyxDQUFKLEdBQVFILE1BQVIsR0FBaUJFLElBQUksS0FBSyxJQUFULEdBQWdCQSxJQUFJLEdBQUdqQixNQUFNLENBQUNzQix3QkFBUCxDQUFnQ1AsTUFBaEMsRUFBd0NDLEdBQXhDLENBQXZCLEdBQXNFQyxJQUFySDtBQUFBLE1BQTJIbkIsQ0FBM0g7QUFDQSxNQUFJLFFBQU95QixPQUFQLHlDQUFPQSxPQUFQLE9BQW1CLFFBQW5CLElBQStCLE9BQU9BLE9BQU8sQ0FBQ0MsUUFBZixLQUE0QixVQUEvRCxFQUEyRUgsQ0FBQyxHQUFHRSxPQUFPLENBQUNDLFFBQVIsQ0FBaUJWLFVBQWpCLEVBQTZCQyxNQUE3QixFQUFxQ0MsR0FBckMsRUFBMENDLElBQTFDLENBQUosQ0FBM0UsS0FDSyxLQUFLLElBQUlRLENBQUMsR0FBR1gsVUFBVSxDQUFDTSxNQUFYLEdBQW9CLENBQWpDLEVBQW9DSyxDQUFDLElBQUksQ0FBekMsRUFBNENBLENBQUMsRUFBN0M7QUFBaUQsUUFBSTNCLENBQUMsR0FBR2dCLFVBQVUsQ0FBQ1csQ0FBRCxDQUFsQixFQUF1QkosQ0FBQyxHQUFHLENBQUNILENBQUMsR0FBRyxDQUFKLEdBQVFwQixDQUFDLENBQUN1QixDQUFELENBQVQsR0FBZUgsQ0FBQyxHQUFHLENBQUosR0FBUXBCLENBQUMsQ0FBQ2lCLE1BQUQsRUFBU0MsR0FBVCxFQUFjSyxDQUFkLENBQVQsR0FBNEJ2QixDQUFDLENBQUNpQixNQUFELEVBQVNDLEdBQVQsQ0FBN0MsS0FBK0RLLENBQW5FO0FBQXhFO0FBQ0wsU0FBT0gsQ0FBQyxHQUFHLENBQUosSUFBU0csQ0FBVCxJQUFjckIsTUFBTSxDQUFDMEIsY0FBUCxDQUFzQlgsTUFBdEIsRUFBOEJDLEdBQTlCLEVBQW1DSyxDQUFuQyxDQUFkLEVBQXFEQSxDQUE1RDtBQUNILENBTEQ7O0FBTUEsSUFBSU0sU0FBUyxHQUFJLFNBQUksSUFBSSxTQUFJLENBQUNBLFNBQWQsSUFBNEIsVUFBVUMsT0FBVixFQUFtQkMsVUFBbkIsRUFBK0JDLENBQS9CLEVBQWtDQyxTQUFsQyxFQUE2QztBQUNyRixXQUFTQyxLQUFULENBQWVDLEtBQWYsRUFBc0I7QUFBRSxXQUFPQSxLQUFLLFlBQVlILENBQWpCLEdBQXFCRyxLQUFyQixHQUE2QixJQUFJSCxDQUFKLENBQU0sVUFBVUksT0FBVixFQUFtQjtBQUFFQSxhQUFPLENBQUNELEtBQUQsQ0FBUDtBQUFpQixLQUE1QyxDQUFwQztBQUFvRjs7QUFDNUcsU0FBTyxLQUFLSCxDQUFDLEtBQUtBLENBQUMsR0FBR0ssT0FBVCxDQUFOLEVBQXlCLFVBQVVELE9BQVYsRUFBbUJFLE1BQW5CLEVBQTJCO0FBQ3ZELGFBQVNDLFNBQVQsQ0FBbUJKLEtBQW5CLEVBQTBCO0FBQUUsVUFBSTtBQUFFSyxZQUFJLENBQUNQLFNBQVMsQ0FBQ1EsSUFBVixDQUFlTixLQUFmLENBQUQsQ0FBSjtBQUE4QixPQUFwQyxDQUFxQyxPQUFPTyxDQUFQLEVBQVU7QUFBRUosY0FBTSxDQUFDSSxDQUFELENBQU47QUFBWTtBQUFFOztBQUMzRixhQUFTQyxRQUFULENBQWtCUixLQUFsQixFQUF5QjtBQUFFLFVBQUk7QUFBRUssWUFBSSxDQUFDUCxTQUFTLENBQUMsT0FBRCxDQUFULENBQW1CRSxLQUFuQixDQUFELENBQUo7QUFBa0MsT0FBeEMsQ0FBeUMsT0FBT08sQ0FBUCxFQUFVO0FBQUVKLGNBQU0sQ0FBQ0ksQ0FBRCxDQUFOO0FBQVk7QUFBRTs7QUFDOUYsYUFBU0YsSUFBVCxDQUFjSSxNQUFkLEVBQXNCO0FBQUVBLFlBQU0sQ0FBQ0MsSUFBUCxHQUFjVCxPQUFPLENBQUNRLE1BQU0sQ0FBQ1QsS0FBUixDQUFyQixHQUFzQ0QsS0FBSyxDQUFDVSxNQUFNLENBQUNULEtBQVIsQ0FBTCxDQUFvQlcsSUFBcEIsQ0FBeUJQLFNBQXpCLEVBQW9DSSxRQUFwQyxDQUF0QztBQUFzRjs7QUFDOUdILFFBQUksQ0FBQyxDQUFDUCxTQUFTLEdBQUdBLFNBQVMsQ0FBQ2MsS0FBVixDQUFnQmpCLE9BQWhCLEVBQXlCQyxVQUFVLElBQUksRUFBdkMsQ0FBYixFQUF5RFUsSUFBekQsRUFBRCxDQUFKO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FSRDs7QUFTQSxJQUFJTyxXQUFXLEdBQUksU0FBSSxJQUFJLFNBQUksQ0FBQ0EsV0FBZCxJQUE4QixVQUFVbEIsT0FBVixFQUFtQm1CLElBQW5CLEVBQXlCO0FBQ3JFLE1BQUlDLENBQUMsR0FBRztBQUFFQyxTQUFLLEVBQUUsQ0FBVDtBQUFZQyxRQUFJLEVBQUUsZ0JBQVc7QUFBRSxVQUFJQyxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sQ0FBWCxFQUFjLE1BQU1BLENBQUMsQ0FBQyxDQUFELENBQVA7QUFBWSxhQUFPQSxDQUFDLENBQUMsQ0FBRCxDQUFSO0FBQWMsS0FBdkU7QUFBeUVDLFFBQUksRUFBRSxFQUEvRTtBQUFtRkMsT0FBRyxFQUFFO0FBQXhGLEdBQVI7QUFBQSxNQUFzR0MsQ0FBdEc7QUFBQSxNQUF5R0MsQ0FBekc7QUFBQSxNQUE0R0osQ0FBNUc7QUFBQSxNQUErR0ssQ0FBL0c7QUFDQSxTQUFPQSxDQUFDLEdBQUc7QUFBRWpCLFFBQUksRUFBRWtCLElBQUksQ0FBQyxDQUFELENBQVo7QUFBaUIsYUFBU0EsSUFBSSxDQUFDLENBQUQsQ0FBOUI7QUFBbUMsY0FBVUEsSUFBSSxDQUFDLENBQUQ7QUFBakQsR0FBSixFQUE0RCxPQUFPQyxNQUFQLEtBQWtCLFVBQWxCLEtBQWlDRixDQUFDLENBQUNFLE1BQU0sQ0FBQ0MsUUFBUixDQUFELEdBQXFCLFlBQVc7QUFBRSxXQUFPLElBQVA7QUFBYyxHQUFqRixDQUE1RCxFQUFnSkgsQ0FBdko7O0FBQ0EsV0FBU0MsSUFBVCxDQUFjRyxDQUFkLEVBQWlCO0FBQUUsV0FBTyxVQUFVQyxDQUFWLEVBQWE7QUFBRSxhQUFPdkIsSUFBSSxDQUFDLENBQUNzQixDQUFELEVBQUlDLENBQUosQ0FBRCxDQUFYO0FBQXNCLEtBQTVDO0FBQStDOztBQUNsRSxXQUFTdkIsSUFBVCxDQUFjd0IsRUFBZCxFQUFrQjtBQUNkLFFBQUlSLENBQUosRUFBTyxNQUFNLElBQUk5QyxTQUFKLENBQWMsaUNBQWQsQ0FBTjs7QUFDUCxXQUFPd0MsQ0FBUDtBQUFVLFVBQUk7QUFDVixZQUFJTSxDQUFDLEdBQUcsQ0FBSixFQUFPQyxDQUFDLEtBQUtKLENBQUMsR0FBR1csRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVIsR0FBWVAsQ0FBQyxDQUFDLFFBQUQsQ0FBYixHQUEwQk8sRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRUCxDQUFDLENBQUMsT0FBRCxDQUFELEtBQWUsQ0FBQ0osQ0FBQyxHQUFHSSxDQUFDLENBQUMsUUFBRCxDQUFOLEtBQXFCSixDQUFDLENBQUM1QyxJQUFGLENBQU9nRCxDQUFQLENBQXJCLEVBQWdDLENBQS9DLENBQVIsR0FBNERBLENBQUMsQ0FBQ2hCLElBQWpHLENBQUQsSUFBMkcsQ0FBQyxDQUFDWSxDQUFDLEdBQUdBLENBQUMsQ0FBQzVDLElBQUYsQ0FBT2dELENBQVAsRUFBVU8sRUFBRSxDQUFDLENBQUQsQ0FBWixDQUFMLEVBQXVCbkIsSUFBOUksRUFBb0osT0FBT1EsQ0FBUDtBQUNwSixZQUFJSSxDQUFDLEdBQUcsQ0FBSixFQUFPSixDQUFYLEVBQWNXLEVBQUUsR0FBRyxDQUFDQSxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVEsQ0FBVCxFQUFZWCxDQUFDLENBQUNsQixLQUFkLENBQUw7O0FBQ2QsZ0JBQVE2QixFQUFFLENBQUMsQ0FBRCxDQUFWO0FBQ0ksZUFBSyxDQUFMO0FBQVEsZUFBSyxDQUFMO0FBQVFYLGFBQUMsR0FBR1csRUFBSjtBQUFROztBQUN4QixlQUFLLENBQUw7QUFBUWQsYUFBQyxDQUFDQyxLQUFGO0FBQVcsbUJBQU87QUFBRWhCLG1CQUFLLEVBQUU2QixFQUFFLENBQUMsQ0FBRCxDQUFYO0FBQWdCbkIsa0JBQUksRUFBRTtBQUF0QixhQUFQOztBQUNuQixlQUFLLENBQUw7QUFBUUssYUFBQyxDQUFDQyxLQUFGO0FBQVdNLGFBQUMsR0FBR08sRUFBRSxDQUFDLENBQUQsQ0FBTjtBQUFXQSxjQUFFLEdBQUcsQ0FBQyxDQUFELENBQUw7QUFBVTs7QUFDeEMsZUFBSyxDQUFMO0FBQVFBLGNBQUUsR0FBR2QsQ0FBQyxDQUFDSyxHQUFGLENBQU1VLEdBQU4sRUFBTDs7QUFBa0JmLGFBQUMsQ0FBQ0ksSUFBRixDQUFPVyxHQUFQOztBQUFjOztBQUN4QztBQUNJLGdCQUFJLEVBQUVaLENBQUMsR0FBR0gsQ0FBQyxDQUFDSSxJQUFOLEVBQVlELENBQUMsR0FBR0EsQ0FBQyxDQUFDL0IsTUFBRixHQUFXLENBQVgsSUFBZ0IrQixDQUFDLENBQUNBLENBQUMsQ0FBQy9CLE1BQUYsR0FBVyxDQUFaLENBQW5DLE1BQXVEMEMsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQWhGLENBQUosRUFBd0Y7QUFBRWQsZUFBQyxHQUFHLENBQUo7QUFBTztBQUFXOztBQUM1RyxnQkFBSWMsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsS0FBZ0IsQ0FBQ1gsQ0FBRCxJQUFPVyxFQUFFLENBQUMsQ0FBRCxDQUFGLEdBQVFYLENBQUMsQ0FBQyxDQUFELENBQVQsSUFBZ0JXLEVBQUUsQ0FBQyxDQUFELENBQUYsR0FBUVgsQ0FBQyxDQUFDLENBQUQsQ0FBaEQsQ0FBSixFQUEyRDtBQUFFSCxlQUFDLENBQUNDLEtBQUYsR0FBVWEsRUFBRSxDQUFDLENBQUQsQ0FBWjtBQUFpQjtBQUFROztBQUN0RixnQkFBSUEsRUFBRSxDQUFDLENBQUQsQ0FBRixLQUFVLENBQVYsSUFBZWQsQ0FBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQTlCLEVBQW1DO0FBQUVILGVBQUMsQ0FBQ0MsS0FBRixHQUFVRSxDQUFDLENBQUMsQ0FBRCxDQUFYO0FBQWdCQSxlQUFDLEdBQUdXLEVBQUo7QUFBUTtBQUFROztBQUNyRSxnQkFBSVgsQ0FBQyxJQUFJSCxDQUFDLENBQUNDLEtBQUYsR0FBVUUsQ0FBQyxDQUFDLENBQUQsQ0FBcEIsRUFBeUI7QUFBRUgsZUFBQyxDQUFDQyxLQUFGLEdBQVVFLENBQUMsQ0FBQyxDQUFELENBQVg7O0FBQWdCSCxlQUFDLENBQUNLLEdBQUYsQ0FBTVcsSUFBTixDQUFXRixFQUFYOztBQUFnQjtBQUFROztBQUNuRSxnQkFBSVgsQ0FBQyxDQUFDLENBQUQsQ0FBTCxFQUFVSCxDQUFDLENBQUNLLEdBQUYsQ0FBTVUsR0FBTjs7QUFDVmYsYUFBQyxDQUFDSSxJQUFGLENBQU9XLEdBQVA7O0FBQWM7QUFYdEI7O0FBYUFELFVBQUUsR0FBR2YsSUFBSSxDQUFDeEMsSUFBTCxDQUFVcUIsT0FBVixFQUFtQm9CLENBQW5CLENBQUw7QUFDSCxPQWpCUyxDQWlCUixPQUFPUixDQUFQLEVBQVU7QUFBRXNCLFVBQUUsR0FBRyxDQUFDLENBQUQsRUFBSXRCLENBQUosQ0FBTDtBQUFhZSxTQUFDLEdBQUcsQ0FBSjtBQUFRLE9BakJ6QixTQWlCa0M7QUFBRUQsU0FBQyxHQUFHSCxDQUFDLEdBQUcsQ0FBUjtBQUFZO0FBakIxRDs7QUFrQkEsUUFBSVcsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRLENBQVosRUFBZSxNQUFNQSxFQUFFLENBQUMsQ0FBRCxDQUFSO0FBQWEsV0FBTztBQUFFN0IsV0FBSyxFQUFFNkIsRUFBRSxDQUFDLENBQUQsQ0FBRixHQUFRQSxFQUFFLENBQUMsQ0FBRCxDQUFWLEdBQWdCLEtBQUssQ0FBOUI7QUFBaUNuQixVQUFJLEVBQUU7QUFBdkMsS0FBUDtBQUMvQjtBQUNKLENBMUJEOztBQTJCQTtBQUNBO0FBQ0E7QUFDQSxJQUFJaUMsTUFBTSxHQUFHQyxxREFBUyxDQUFDLFNBQUQsQ0FBdEI7QUFDQSxJQUFJQyxNQUFNLEdBQUdELHFEQUFTLENBQUMsT0FBRCxDQUF0Qjs7QUFDQSxJQUFJSCxXQUFXO0FBQUc7QUFBZSxVQUFVUixNQUFWLEVBQWtCO0FBQy9DdEUsV0FBUyxDQUFDOEUsV0FBRCxFQUFjUixNQUFkLENBQVQ7O0FBQ0EsV0FBU1EsV0FBVCxHQUF1QjtBQUNuQixXQUFPUixNQUFNLEtBQUssSUFBWCxJQUFtQkEsTUFBTSxDQUFDckIsS0FBUCxDQUFhLElBQWIsRUFBbUIxQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIOztBQUNEdUQsYUFBVyxDQUFDckUsU0FBWixDQUFzQjhELE9BQXRCLEdBQWdDLFlBQVk7QUFDeEMsV0FBT3hDLFNBQVMsQ0FBQyxJQUFELEVBQU8sS0FBSyxDQUFaLEVBQWUsS0FBSyxDQUFwQixFQUF1QixZQUFZO0FBQy9DLGFBQU9tQixXQUFXLENBQUMsSUFBRCxFQUFPLFVBQVVzQixFQUFWLEVBQWM7QUFDbkMsZ0JBQVFBLEVBQUUsQ0FBQ25CLEtBQVg7QUFDSSxlQUFLLENBQUw7QUFDSSxnQkFBSSxFQUFFLEtBQUs4QixPQUFMLENBQWEzRCxNQUFiLElBQXVCLENBQXpCLENBQUosRUFBaUMsT0FBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLENBQWQsQ0FBUDtBQUNqQyxnQkFBSSxFQUFFLEtBQUs0RCxVQUFMLENBQWdCQyxPQUFoQixLQUE0QixDQUE5QixDQUFKLEVBQXNDLE9BQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7QUFDdEMsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxLQUFLQyxjQUFMLEVBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSWQsY0FBRSxDQUFDbEIsSUFBSDs7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLENBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFBUSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLEtBQUtpQyxhQUFMLEVBQWQsQ0FBUDs7QUFDUixlQUFLLENBQUw7QUFDSWYsY0FBRSxDQUFDbEIsSUFBSDs7QUFDQWtCLGNBQUUsQ0FBQ25CLEtBQUgsR0FBVyxDQUFYOztBQUNKLGVBQUssQ0FBTDtBQUFRLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsS0FBS21DLFlBQUwsRUFBZCxDQUFQOztBQUNSLGVBQUssQ0FBTDtBQUNJaEIsY0FBRSxDQUFDbEIsSUFBSDs7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxhQUFQO0FBZlI7QUFpQkgsT0FsQmlCLENBQWxCO0FBbUJILEtBcEJlLENBQWhCO0FBcUJILEdBdEJEOztBQXVCQWxELFFBQU0sQ0FBQzBCLGNBQVAsQ0FBc0JnRCxXQUFXLENBQUNyRSxTQUFsQyxFQUE2QyxZQUE3QyxFQUEyRDtBQUN2RGdGLE9BQUcsRUFBRSxlQUFZO0FBQ2IsYUFBTyxLQUFLQyxNQUFMLENBQVlDLEtBQVosQ0FBa0JDLElBQWxCLENBQXVCQyxJQUE5QjtBQUNILEtBSHNEO0FBSXZEQyxjQUFVLEVBQUUsS0FKMkM7QUFLdkRDLGdCQUFZLEVBQUU7QUFMeUMsR0FBM0Q7O0FBT0FqQixhQUFXLENBQUNyRSxTQUFaLENBQXNCOEUsYUFBdEIsR0FBc0MsWUFBWTtBQUM5QyxXQUFPeEQsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT21CLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVXNCLEVBQVYsRUFBYztBQUNuQyxhQUFLd0IsV0FBTDtBQUNBLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BSGlCLENBQWxCO0FBSUgsS0FMZSxDQUFoQjtBQU1ILEdBUEQ7O0FBUUFsQixhQUFXLENBQUNyRSxTQUFaLENBQXNCNkUsY0FBdEIsR0FBdUMsWUFBWTtBQUMvQyxXQUFPdkQsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT21CLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVXNCLEVBQVYsRUFBYztBQUNuQyxhQUFLeUIsY0FBTDtBQUNBLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BSGlCLENBQWxCO0FBSUgsS0FMZSxDQUFoQjtBQU1ILEdBUEQ7O0FBUUFuQixhQUFXLENBQUNyRSxTQUFaLENBQXNCK0UsWUFBdEIsR0FBcUMsWUFBWTtBQUM3QyxXQUFPekQsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsYUFBT21CLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVXNCLEVBQVYsRUFBYztBQUNuQyxhQUFLMEIsYUFBTDtBQUNBLGVBQU8sQ0FBQztBQUFFO0FBQUgsU0FBUDtBQUNILE9BSGlCLENBQWxCO0FBSUgsS0FMZSxDQUFoQjtBQU1ILEdBUEQ7O0FBUUFwQixhQUFXLENBQUNyRSxTQUFaLENBQXNCMEYsZUFBdEIsR0FBd0MsWUFBWTtBQUNoRCxXQUFPcEUsU0FBUyxDQUFDLElBQUQsRUFBTyxLQUFLLENBQVosRUFBZSxLQUFLLENBQXBCLEVBQXVCLFlBQVk7QUFDL0MsVUFBSXFFLFFBQUosRUFBYzVCLEVBQWQ7O0FBQ0EsYUFBT3RCLFdBQVcsQ0FBQyxJQUFELEVBQU8sVUFBVW1ELEVBQVYsRUFBYztBQUNuQyxnQkFBUUEsRUFBRSxDQUFDaEQsS0FBWDtBQUNJLGVBQUssQ0FBTDtBQUNJLGdCQUFJLEVBQUUsS0FBS2lELElBQUwsQ0FBVUMsTUFBVixHQUFtQixLQUFLQyxLQUFMLENBQVdDLGlCQUFoQyxDQUFKLEVBQXdELE9BQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7QUFDeEQsaUJBQUtDLFFBQUwsQ0FBY0MsUUFBZCxDQUF1QixLQUFLLEtBQUtDLEVBQUwsQ0FBUSxrQkFBUixDQUE1QjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJLGdCQUFJLEVBQUUsS0FBS04sSUFBTCxDQUFVTyxPQUFWLEtBQXNCLEVBQXRCLElBQTRCLEtBQUtQLElBQUwsQ0FBVVEsSUFBVixLQUFtQixFQUFqRCxDQUFKLEVBQTBELE9BQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7QUFDMUQsaUJBQUtKLFFBQUwsQ0FBY0MsUUFBZCxDQUF1QixLQUFLLEtBQUtDLEVBQUwsQ0FBUSxzQkFBUixDQUE1QjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLRyxVQUFMLENBQWdCLElBQWhCO0FBQ0FWLGNBQUUsQ0FBQ2hELEtBQUgsR0FBVyxDQUFYOztBQUNKLGVBQUssQ0FBTDtBQUNJZ0QsY0FBRSxDQUFDN0MsSUFBSCxDQUFRWSxJQUFSLENBQWEsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLENBQWI7O0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYzRDLGlEQUFBLENBQVcsa0JBQVgsRUFBK0IsS0FBS1YsSUFBcEMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJRixvQkFBUSxHQUFHQyxFQUFFLENBQUMvQyxJQUFILEVBQVg7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLENBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSWtCLGNBQUUsR0FBRzZCLEVBQUUsQ0FBQy9DLElBQUgsRUFBTDtBQUNBLGlCQUFLb0QsUUFBTCxDQUFjQyxRQUFkLENBQXVCLEtBQUssS0FBS0MsRUFBTCxDQUFRLHNCQUFSLENBQTVCO0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7O0FBQ0osZUFBSyxDQUFMO0FBQ0ksaUJBQUtHLFVBQUwsQ0FBZ0IsS0FBaEI7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLEtBQUt6QixjQUFMLEVBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSWUsY0FBRSxDQUFDL0MsSUFBSDs7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxjQUFjLEtBQUtrQyxZQUFMLEVBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSWEsY0FBRSxDQUFDL0MsSUFBSDs7QUFDQSxpQkFBSzJELGVBQUwsQ0FBcUIsS0FBckI7QUFDQSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxhQUFQOztBQUNKLGVBQUssQ0FBTDtBQUFRLG1CQUFPLENBQUM7QUFBRTtBQUFILGFBQVA7QUFoQ1o7QUFrQ0gsT0FuQ2lCLENBQWxCO0FBb0NILEtBdENlLENBQWhCO0FBdUNILEdBeENEOztBQXlDQW5DLGFBQVcsQ0FBQ3JFLFNBQVosQ0FBc0J5RyxZQUF0QixHQUFxQyxVQUFVQyxNQUFWLEVBQWtCO0FBQ25ELFdBQU9wRixTQUFTLENBQUMsSUFBRCxFQUFPLEtBQUssQ0FBWixFQUFlLEtBQUssQ0FBcEIsRUFBdUIsWUFBWTtBQUMvQyxVQUFJcUUsUUFBSixFQUFjNUIsRUFBZDs7QUFDQSxhQUFPdEIsV0FBVyxDQUFDLElBQUQsRUFBTyxVQUFVbUQsRUFBVixFQUFjO0FBQ25DLGdCQUFRQSxFQUFFLENBQUNoRCxLQUFYO0FBQ0ksZUFBSyxDQUFMO0FBQ0ksaUJBQUswRCxVQUFMLENBQWdCLElBQWhCO0FBQ0FWLGNBQUUsQ0FBQ2hELEtBQUgsR0FBVyxDQUFYOztBQUNKLGVBQUssQ0FBTDtBQUNJZ0QsY0FBRSxDQUFDN0MsSUFBSCxDQUFRWSxJQUFSLENBQWEsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLENBQWI7O0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYzRDLGlEQUFBLENBQVcsc0JBQVgsRUFBbUNHLE1BQW5DLENBQWQsQ0FBUDs7QUFDSixlQUFLLENBQUw7QUFDSWYsb0JBQVEsR0FBR0MsRUFBRSxDQUFDL0MsSUFBSCxFQUFYO0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsY0FBYyxDQUFkLENBQVA7O0FBQ0osZUFBSyxDQUFMO0FBQ0lrQixjQUFFLEdBQUc2QixFQUFFLENBQUMvQyxJQUFILEVBQUw7QUFDQSxpQkFBS29ELFFBQUwsQ0FBY0MsUUFBZCxDQUF1QixLQUFLLEtBQUtDLEVBQUwsQ0FBUSxzQkFBUixDQUE1QjtBQUNBLG1CQUFPLENBQUM7QUFBRTtBQUFILGNBQWMsQ0FBZCxDQUFQOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLWixXQUFMO0FBQ0EsbUJBQU8sQ0FBQztBQUFFO0FBQUgsYUFBUDs7QUFDSixlQUFLLENBQUw7QUFBUSxtQkFBTyxDQUFDO0FBQUU7QUFBSCxhQUFQO0FBakJaO0FBbUJILE9BcEJpQixDQUFsQjtBQXFCSCxLQXZCZSxDQUFoQjtBQXdCSCxHQXpCRDs7QUEwQkEvRSxZQUFVLENBQUMsQ0FDUCtELE1BQU0sQ0FBQ29DLEtBREEsQ0FBRCxFQUVQdEMsV0FBVyxDQUFDckUsU0FGTCxFQUVnQixTQUZoQixFQUUyQixLQUFLLENBRmhDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQK0QsTUFBTSxDQUFDb0MsS0FEQSxDQUFELEVBRVB0QyxXQUFXLENBQUNyRSxTQUZMLEVBRWdCLFFBRmhCLEVBRTBCLEtBQUssQ0FGL0IsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1ArRCxNQUFNLENBQUNvQyxLQURBLENBQUQsRUFFUHRDLFdBQVcsQ0FBQ3JFLFNBRkwsRUFFZ0IsTUFGaEIsRUFFd0IsS0FBSyxDQUY3QixDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUCtELE1BQU0sQ0FBQ29DLEtBREEsQ0FBRCxFQUVQdEMsV0FBVyxDQUFDckUsU0FGTCxFQUVnQixXQUZoQixFQUU2QixLQUFLLENBRmxDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQK0QsTUFBTSxDQUFDb0MsS0FEQSxDQUFELEVBRVB0QyxXQUFXLENBQUNyRSxTQUZMLEVBRWdCLGdCQUZoQixFQUVrQyxLQUFLLENBRnZDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQK0QsTUFBTSxDQUFDTCxNQURBLENBQUQsRUFFUEcsV0FBVyxDQUFDckUsU0FGTCxFQUVnQixhQUZoQixFQUUrQixLQUFLLENBRnBDLENBQVY7O0FBR0FRLFlBQVUsQ0FBQyxDQUNQK0QsTUFBTSxDQUFDTCxNQURBLENBQUQsRUFFUEcsV0FBVyxDQUFDckUsU0FGTCxFQUVnQixnQkFGaEIsRUFFa0MsS0FBSyxDQUZ2QyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUCtELE1BQU0sQ0FBQ0wsTUFEQSxDQUFELEVBRVBHLFdBQVcsQ0FBQ3JFLFNBRkwsRUFFZ0IsaUJBRmhCLEVBRW1DLEtBQUssQ0FGeEMsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1ArRCxNQUFNLENBQUNMLE1BREEsQ0FBRCxFQUVQRyxXQUFXLENBQUNyRSxTQUZMLEVBRWdCLFlBRmhCLEVBRThCLEtBQUssQ0FGbkMsQ0FBVjs7QUFHQVEsWUFBVSxDQUFDLENBQ1BpRSxNQUFNLENBQUNrQyxLQURBLENBQUQsRUFFUHRDLFdBQVcsQ0FBQ3JFLFNBRkwsRUFFZ0IsT0FGaEIsRUFFeUIsS0FBSyxDQUY5QixDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUGlFLE1BQU0sQ0FBQ1AsTUFEQSxDQUFELEVBRVBHLFdBQVcsQ0FBQ3JFLFNBRkwsRUFFZ0IsY0FGaEIsRUFFZ0MsS0FBSyxDQUZyQyxDQUFWOztBQUdBUSxZQUFVLENBQUMsQ0FDUGlFLE1BQU0sQ0FBQ1AsTUFEQSxDQUFELEVBRVBHLFdBQVcsQ0FBQ3JFLFNBRkwsRUFFZ0IsZUFGaEIsRUFFaUMsS0FBSyxDQUZ0QyxDQUFWOztBQUdBcUUsYUFBVyxHQUFHN0QsVUFBVSxDQUFDLENBQ3JCMkQsaUVBQVMsQ0FBQztBQUNOQyxjQUFVLEVBQUU7QUFETixHQUFELENBRFksQ0FBRCxFQUlyQkMsV0FKcUIsQ0FBeEI7QUFLQSxTQUFPQSxXQUFQO0FBQ0gsQ0F4S2dDLENBd0svQkMsdURBeEsrQixDQUFqQzs7QUF5S0EsaUVBQWVELFdBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdk8rRjtBQUNwQztBQUNMOzs7QUFHdEQ7QUFDQSxDQUFtRztBQUNuRyxnQkFBZ0Isb0dBQVU7QUFDMUIsRUFBRSwwRUFBTTtBQUNSLEVBQUUsd0ZBQU07QUFDUixFQUFFLGlHQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsSUFBSSxLQUFVLEVBQUUsWUFpQmY7QUFDRDtBQUNBLGlFQUFlLGlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q2dHO0FBQ2hEO0FBQ0w7OztBQUcxRDtBQUNBLENBQXNHO0FBQ3RHLGdCQUFnQixvR0FBVTtBQUMxQixFQUFFLDhFQUFNO0FBQ1IsRUFBRSx3R0FBTTtBQUNSLEVBQUUsaUhBQWU7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxJQUFJLEtBQVUsRUFBRSxZQWlCZjtBQUNEO0FBQ0EsaUVBQWUsaUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QzJSLENBQUMsaUVBQWUsb1FBQUcsRUFBQyxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDQVAsQ0FBQyxpRUFBZSx3UUFBRyxFQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTNVO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssU0FBUyx5QkFBeUIsRUFBRTtBQUN6QztBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isc0JBQXNCO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLFNBQVMsWUFBWSxFQUFFO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLFNBQVMsb0JBQW9CLEVBQUU7QUFDMUQ7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLFNBQVMsb0JBQW9CLEVBQUU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDO0FBQ3RDLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsRUFBRTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiwyREFBMkQ7QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxhQUFhLFNBQVMsWUFBWSxFQUFFO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLFNBQVMsV0FBVyxFQUFFO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQztBQUN0Qyx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELEVBQUU7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixTQUFTLFdBQVcsRUFBRTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsOEJBQThCLFdBQVcsRUFBRTtBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLGVBQWU7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLDhCQUE4QixXQUFXLEVBQUU7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxlQUFlO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw4QkFBOEIsV0FBVyxFQUFFO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMseUJBQXlCO0FBQ3JFLHNDQUFzQyxnQ0FBZ0M7QUFDdEUsbUNBQW1DO0FBQ25DLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0Qix5QkFBeUI7QUFDckQsc0JBQXNCLHlDQUF5QztBQUMvRCxtQkFBbUI7QUFDbkIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIseUJBQXlCO0FBQ3JELHNCQUFzQix5Q0FBeUM7QUFDL0QsbUJBQW1CO0FBQ25CLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0Qix5QkFBeUI7QUFDckQsc0JBQXNCLGlDQUFpQztBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQix5Q0FBeUM7QUFDNUQsb0NBQW9DLDhCQUE4QjtBQUNsRTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxzQkFBc0I7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQix5QkFBeUI7QUFDekIsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsOEJBQThCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsRUFBRTtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyw2QkFBNkI7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxFQUFFO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLHNCQUFzQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixvQ0FBb0MsWUFBWSxFQUFFO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJqcy9yZXNvdXJjZXNfYXNzZXRzX3Z1ZV92aWV3c193YWxsZXRzX1dhbGxldHNfdnVlLmpzIiwic291cmNlc0NvbnRlbnQiOlsidmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2RlY29yYXRlID0gKHRoaXMgJiYgdGhpcy5fX2RlY29yYXRlKSB8fCBmdW5jdGlvbiAoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn07XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBBY3Rpb24gfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IFdhbGxldHNMaXN0IGZyb20gJy4vY29tcG9uZW50cy9XYWxsZXRzTGlzdC52dWUnO1xyXG52YXIgV2FsbGV0cyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhXYWxsZXRzLCBfc3VwZXIpO1xyXG4gICAgZnVuY3Rpb24gV2FsbGV0cygpIHtcclxuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XHJcbiAgICB9XHJcbiAgICBXYWxsZXRzLnByb3RvdHlwZS5jcmVhdGVkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRCYWNrVXJsKCcvJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldE1lbnUoW10pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICBBY3Rpb25cclxuICAgIF0sIFdhbGxldHMucHJvdG90eXBlLCBcInNldEJhY2tVcmxcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIEFjdGlvblxyXG4gICAgXSwgV2FsbGV0cy5wcm90b3R5cGUsIFwic2V0TWVudVwiLCB2b2lkIDApO1xyXG4gICAgV2FsbGV0cyA9IF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIENvbXBvbmVudCh7XHJcbiAgICAgICAgICAgIGNvbXBvbmVudHM6IHtcclxuICAgICAgICAgICAgICAgIFdhbGxldHNMaXN0OiBXYWxsZXRzTGlzdCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgXSwgV2FsbGV0cyk7XHJcbiAgICByZXR1cm4gV2FsbGV0cztcclxufShWdWUpKTtcclxuZXhwb3J0IGRlZmF1bHQgV2FsbGV0cztcclxuIiwidmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2RlY29yYXRlID0gKHRoaXMgJiYgdGhpcy5fX2RlY29yYXRlKSB8fCBmdW5jdGlvbiAoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn07XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIFZ1ZSB9IGZyb20gJ3Z1ZS1wcm9wZXJ0eS1kZWNvcmF0b3InO1xyXG5pbXBvcnQgeyBuYW1lc3BhY2UgfSBmcm9tICd2dWV4LWNsYXNzJztcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG52YXIgd1N0b3JlID0gbmFtZXNwYWNlKCd3YWxsZXRzJyk7XHJcbnZhciB1U3RvcmUgPSBuYW1lc3BhY2UoJ3VzZXJzJyk7XHJcbnZhciBXYWxsZXRzTGlzdCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhXYWxsZXRzTGlzdCwgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIFdhbGxldHNMaXN0KCkge1xyXG4gICAgICAgIHJldHVybiBfc3VwZXIgIT09IG51bGwgJiYgX3N1cGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgfHwgdGhpcztcclxuICAgIH1cclxuICAgIFdhbGxldHNMaXN0LnByb3RvdHlwZS5jcmVhdGVkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEodGhpcy53YWxsZXRzLmxlbmd0aCA9PSAwKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgNF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKHRoaXMuYWN0dWFsVXNlci50eXBlX2lkID09PSAyKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHRoaXMuZ2V0VXNlcldhbGxldHMoKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDRdO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjogcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRBbGxXYWxsZXRzKCldO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSA0OiByZXR1cm4gWzQgLyp5aWVsZCovLCB0aGlzLmdldFVzZXJTdGF0cygpXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoV2FsbGV0c0xpc3QucHJvdG90eXBlLCBcImFjdHVhbFVzZXJcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy4kc3RvcmUuc3RhdGUuYXV0aC51c2VyO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIFdhbGxldHNMaXN0LnByb3RvdHlwZS5nZXRBbGxXYWxsZXRzID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkV2FsbGV0cygpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBXYWxsZXRzTGlzdC5wcm90b3R5cGUuZ2V0VXNlcldhbGxldHMgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRVc2VyV2FsbGV0KCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIFdhbGxldHNMaXN0LnByb3RvdHlwZS5nZXRVc2VyU3RhdHMgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRVc2VyU3RhdHMoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgV2FsbGV0c0xpc3QucHJvdG90eXBlLnJlcXVlc3RXaXRoZHJhdyA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSwgX2E7XHJcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2IubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKHRoaXMuZm9ybS5hbW91bnQgPiB0aGlzLnN0YXRzLnRvdGFsX3VzZXJfZm91bmRzKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGJ2TW9kYWwubXNnQm94T2soJycgKyB0aGlzLiR0KCdlcnJvcnMubWF4X2Vycm9yJykpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA5XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKHRoaXMuZm9ybS5hY2NvdW50ID09PSAnJyB8fCB0aGlzLmZvcm0uYmFuayA9PT0gJycpKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kYnZNb2RhbC5tc2dCb3hPaygnJyArIHRoaXMuJHQoJ2Vycm9ycy5nZW5lcmljX2Vycm9yJykpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA5XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IubGFiZWwgPSAzO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IudHJ5cy5wdXNoKFszLCA1LCA2LCA5XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGF4aW9zLnBvc3QoJ3JlcXVlc3Qvd2l0aGRyYXcnLCB0aGlzLmZvcm0pXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA5XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hID0gX2Iuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRidk1vZGFsLm1zZ0JveE9rKCcnICsgdGhpcy4kdCgnZXJyb3JzLmdlbmVyaWNfZXJyb3InKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDldO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgNjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRVc2VyV2FsbGV0cygpXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDc6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9iLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5nZXRVc2VyU3RhdHMoKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSA4OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYi5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0TW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs3IC8qZW5kZmluYWxseSovXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDk6IHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgV2FsbGV0c0xpc3QucHJvdG90eXBlLmNoYW5nZVN0YXR1cyA9IGZ1bmN0aW9uICh3YWxsZXQpIHtcclxuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSwgX2E7XHJcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2IubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IubGFiZWwgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2IudHJ5cy5wdXNoKFsxLCAzLCA0LCA1XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGF4aW9zLnBvc3QoJ2FwcHJvdmUvdXNlci9yZXF1ZXN0Jywgd2FsbGV0KV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IF9iLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgNV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYSA9IF9iLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kYnZNb2RhbC5tc2dCb3hPaygnJyArIHRoaXMuJHQoJ2Vycm9ycy5nZW5lcmljX2Vycm9yJykpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA1XTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZFdhbGxldHMoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs3IC8qZW5kZmluYWxseSovXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDU6IHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgd1N0b3JlLlN0YXRlXHJcbiAgICBdLCBXYWxsZXRzTGlzdC5wcm90b3R5cGUsIFwid2FsbGV0c1wiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgd1N0b3JlLlN0YXRlXHJcbiAgICBdLCBXYWxsZXRzTGlzdC5wcm90b3R5cGUsIFwiZmllbGRzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB3U3RvcmUuU3RhdGVcclxuICAgIF0sIFdhbGxldHNMaXN0LnByb3RvdHlwZSwgXCJmb3JtXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB3U3RvcmUuU3RhdGVcclxuICAgIF0sIFdhbGxldHNMaXN0LnByb3RvdHlwZSwgXCJpc0xvYWRpbmdcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHdTdG9yZS5TdGF0ZVxyXG4gICAgXSwgV2FsbGV0c0xpc3QucHJvdG90eXBlLCBcImlzTW9kYWxWaXNpYmxlXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB3U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBXYWxsZXRzTGlzdC5wcm90b3R5cGUsIFwibG9hZFdhbGxldHNcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHdTdG9yZS5BY3Rpb25cclxuICAgIF0sIFdhbGxldHNMaXN0LnByb3RvdHlwZSwgXCJsb2FkVXNlcldhbGxldFwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgd1N0b3JlLkFjdGlvblxyXG4gICAgXSwgV2FsbGV0c0xpc3QucHJvdG90eXBlLCBcInNldE1vZGFsVmlzaWJsZVwiLCB2b2lkIDApO1xyXG4gICAgX19kZWNvcmF0ZShbXHJcbiAgICAgICAgd1N0b3JlLkFjdGlvblxyXG4gICAgXSwgV2FsbGV0c0xpc3QucHJvdG90eXBlLCBcInNldExvYWRpbmdcIiwgdm9pZCAwKTtcclxuICAgIF9fZGVjb3JhdGUoW1xyXG4gICAgICAgIHVTdG9yZS5TdGF0ZVxyXG4gICAgXSwgV2FsbGV0c0xpc3QucHJvdG90eXBlLCBcInN0YXRzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBXYWxsZXRzTGlzdC5wcm90b3R5cGUsIFwic2V0VXNlclN0YXRzXCIsIHZvaWQgMCk7XHJcbiAgICBfX2RlY29yYXRlKFtcclxuICAgICAgICB1U3RvcmUuQWN0aW9uXHJcbiAgICBdLCBXYWxsZXRzTGlzdC5wcm90b3R5cGUsIFwibG9hZFVzZXJTdGF0c1wiLCB2b2lkIDApO1xyXG4gICAgV2FsbGV0c0xpc3QgPSBfX2RlY29yYXRlKFtcclxuICAgICAgICBDb21wb25lbnQoe1xyXG4gICAgICAgICAgICBjb21wb25lbnRzOiB7fVxyXG4gICAgICAgIH0pXHJcbiAgICBdLCBXYWxsZXRzTGlzdCk7XHJcbiAgICByZXR1cm4gV2FsbGV0c0xpc3Q7XHJcbn0oVnVlKSk7XHJcbmV4cG9ydCBkZWZhdWx0IFdhbGxldHNMaXN0O1xyXG4iLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1dhbGxldHMudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTIyZjY1MzQ3Jmxhbmc9cHVnJlwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL1dhbGxldHMudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPXRzJlwiXG5leHBvcnQgKiBmcm9tIFwiLi9XYWxsZXRzLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcY2FyZGVcXFxcUHJvamVjdHNcXFxcaW5hZ2F2ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCcyMmY2NTM0NycpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCcyMmY2NTM0NycsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCcyMmY2NTM0NycsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vV2FsbGV0cy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MjJmNjUzNDcmbGFuZz1wdWcmXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGFwaS5yZXJlbmRlcignMjJmNjUzNDcnLCB7XG4gICAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgICBzdGF0aWNSZW5kZXJGbnM6IHN0YXRpY1JlbmRlckZuc1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG5jb21wb25lbnQub3B0aW9ucy5fX2ZpbGUgPSBcInJlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3dhbGxldHMvV2FsbGV0cy52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL1dhbGxldHNMaXN0LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD03MzgwY2EwMiZzY29wZWQ9dHJ1ZSZsYW5nPXB1ZyZcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9XYWxsZXRzTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCJcbmV4cG9ydCAqIGZyb20gXCIuL1dhbGxldHNMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIFwiNzM4MGNhMDJcIixcbiAgbnVsbFxuICBcbilcblxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgdmFyIGFwaSA9IHJlcXVpcmUoXCJDOlxcXFxVc2Vyc1xcXFxjYXJkZVxcXFxQcm9qZWN0c1xcXFxpbmFnYXZlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtaG90LXJlbG9hZC1hcGlcXFxcZGlzdFxcXFxpbmRleC5qc1wiKVxuICBhcGkuaW5zdGFsbChyZXF1aXJlKCd2dWUnKSlcbiAgaWYgKGFwaS5jb21wYXRpYmxlKSB7XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICAgIGlmICghYXBpLmlzUmVjb3JkZWQoJzczODBjYTAyJykpIHtcbiAgICAgIGFwaS5jcmVhdGVSZWNvcmQoJzczODBjYTAyJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfSBlbHNlIHtcbiAgICAgIGFwaS5yZWxvYWQoJzczODBjYTAyJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfVxuICAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9XYWxsZXRzTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NzM4MGNhMDImc2NvcGVkPXRydWUmbGFuZz1wdWcmXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGFwaS5yZXJlbmRlcignNzM4MGNhMDInLCB7XG4gICAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgICBzdGF0aWNSZW5kZXJGbnM6IHN0YXRpY1JlbmRlckZuc1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG5jb21wb25lbnQub3B0aW9ucy5fX2ZpbGUgPSBcInJlc291cmNlcy9hc3NldHMvdnVlL3ZpZXdzL3dhbGxldHMvY29tcG9uZW50cy9XYWxsZXRzTGlzdC52dWVcIlxuZXhwb3J0IGRlZmF1bHQgY29tcG9uZW50LmV4cG9ydHMiLCJpbXBvcnQgbW9kIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9XYWxsZXRzLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIjsgZXhwb3J0IGRlZmF1bHQgbW9kOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC01WzBdLnJ1bGVzWzBdLnVzZVswXSEuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHMtbG9hZGVyL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTIyWzBdLnJ1bGVzWzBdIS4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vV2FsbGV0cy52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCIiLCJpbXBvcnQgbW9kIGZyb20gXCItIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTVbMF0ucnVsZXNbMF0udXNlWzBdIS4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy90cy1sb2FkZXIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMjJbMF0ucnVsZXNbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9XYWxsZXRzTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9dHMmXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtNVswXS5ydWxlc1swXS51c2VbMF0hLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3RzLWxvYWRlci9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0yMlswXS5ydWxlc1swXSEuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL1dhbGxldHNMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz10cyZcIiIsInZhciByZW5kZXIgPSBmdW5jdGlvbigpIHtcbiAgdmFyIF92bSA9IHRoaXNcbiAgdmFyIF9oID0gX3ZtLiRjcmVhdGVFbGVtZW50XG4gIHZhciBfYyA9IF92bS5fc2VsZi5fYyB8fCBfaFxuICByZXR1cm4gX2MoXG4gICAgXCJiLWNvbnRhaW5lclwiLFxuICAgIHsgYXR0cnM6IHsgdGFnOiBcIm1haW5cIiwgZmx1aWQ6IFwiXCIgfSB9LFxuICAgIFtcbiAgICAgIF9jKFxuICAgICAgICBcImItcm93XCIsXG4gICAgICAgIFtfYyhcImItY29sXCIsIHsgc3RhdGljQ2xhc3M6IFwibXQtM1wiIH0sIFtfYyhcIldhbGxldHNMaXN0XCIpXSwgMSldLFxuICAgICAgICAxXG4gICAgICApXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiZGl2XCIsXG4gICAgW1xuICAgICAgX2MoXG4gICAgICAgIFwiYi1jb250YWluZXJcIixcbiAgICAgICAgeyBhdHRyczogeyBmbHVpZDogXCJcIiB9IH0sXG4gICAgICAgIFtcbiAgICAgICAgICBfYyhcbiAgICAgICAgICAgIFwiYi1yb3dcIixcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXCJiLWNvbFwiLCB7IGF0dHJzOiB7IG1kOiBcIjhcIiwgc206IFwiMTJcIiB9IH0sIFtcbiAgICAgICAgICAgICAgICBfYyhcImgyXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcIndhbGxldHMudGl0bGVcIikpKV0pXG4gICAgICAgICAgICAgIF0pLFxuICAgICAgICAgICAgICB0aGlzLmFjdHVhbFVzZXIudHlwZV9pZCA9PT0gMlxuICAgICAgICAgICAgICAgID8gX2MoXCJiLWNvbFwiLCB7IGF0dHJzOiB7IG1kOiBcIjRcIiwgc206IFwiMTJcIiB9IH0sIFtcbiAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNDbGFzczpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LWNlbnRlciBmb250LXdlaWdodC1ib2xkIHRleHQtaW5mbyBtb250c2VycmF0XCJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLl9zKF92bS4kdChcInN0cmluZ3MudG90YWxfd2FsbGV0X3VzZXJcIikpICsgXCI6XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgIFwicFwiLFxuICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImZvbnQtd2VpZ2h0LWJvbGQgdGV4dC1jZW50ZXIgdGV4dC1kYW5nZXIgbW9udHNlcnJhdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHsgXCJmb250LXNpemVcIjogXCIyZW1cIiB9XG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgICBfdm0uX3YoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiJFwiICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uX3MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uc3RhdHMudG90YWxfdXNlcl9mb3VuZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvRml4ZWQoMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcZCg/PShcXGR7M30pK1xcLikvZywgXCIkJixcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIiAoTVhOKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICAgIDogX3ZtLl9lKClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKVxuICAgICAgICBdLFxuICAgICAgICAxXG4gICAgICApLFxuICAgICAgX2MoXG4gICAgICAgIFwiYi1tb2RhbFwiLFxuICAgICAgICB7XG4gICAgICAgICAgYXR0cnM6IHsgXCJoaWRlLWhlYWRlci1jbG9zZVwiOiBcIlwiLCBjZW50ZXJlZDogXCJcIiwgXCJoaWRlLWZvb3RlclwiOiBcIlwiIH0sXG4gICAgICAgICAgb246IHtcbiAgICAgICAgICAgIGhpZGU6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICBfdm0uZm9ybS5hbW91bnQgPSAwXG4gICAgICAgICAgICAgIF92bS5mb3JtLmFjY291bnQgPSBcIlwiXG4gICAgICAgICAgICAgIF92bS5mb3JtLmJhbmsgPSBcIlwiXG4gICAgICAgICAgICAgIF92bS5zZXRNb2RhbFZpc2libGUoZmFsc2UpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBtb2RlbDoge1xuICAgICAgICAgICAgdmFsdWU6IF92bS5pc01vZGFsVmlzaWJsZSxcbiAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgX3ZtLmlzTW9kYWxWaXNpYmxlID0gJCR2XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJpc01vZGFsVmlzaWJsZVwiXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbXG4gICAgICAgICAgX2MoXG4gICAgICAgICAgICBcImItY29udGFpbmVyXCIsXG4gICAgICAgICAgICB7IGF0dHJzOiB7IGZsdWlkOiBcIlwiIH0gfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgXCJiLXJvd1wiLFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIF9jKFwiYi1jb2xcIiwgeyBhdHRyczogeyBtZDogXCIxMlwiIH0gfSwgW1xuICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICBcInRleHQtY2VudGVyIGZvbnQtd2VpZ2h0LWJvbGQgdGV4dC1pbmZvIG1vbnRzZXJyYXRcIlxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLl92KFxuICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy50b3RhbF93YWxsZXRfdXNlclwiKSkgKyBcIjpcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgXCJwXCIsXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiZm9udC13ZWlnaHQtYm9sZCB0ZXh0LWNlbnRlciB0ZXh0LWRhbmdlciBtb250c2VycmF0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0aWNTdHlsZTogeyBcImZvbnQtc2l6ZVwiOiBcIjJlbVwiIH1cbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCIkXCIgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF92bS5zdGF0cy50b3RhbF91c2VyX2ZvdW5kc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxkKD89KFxcZHszfSkrXFwuKS9nLCBcIiQmLFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiIChNWE4pXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIF0pLFxuICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgIFwiYi1jb2xcIixcbiAgICAgICAgICAgICAgICAgICAgeyBhdHRyczogeyBtZDogXCIxMlwiIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LWxlZnQgZm9udC13ZWlnaHQtYm9sZCB0ZXh0LWluZm8gbW9udHNlcnJhdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy5hbW91bnRcIikpICsgXCI6XCIpXVxuICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgX2MoXCJiLWZvcm0taW5wdXRcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJudW1iZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcDogXCIwLjAxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heDogX3ZtLnN0YXRzLnRvdGFsX3VzZXJfZm91bmRzXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLmFtb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6IGZ1bmN0aW9uKCQkdikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF92bS4kc2V0KF92bS5mb3JtLCBcImFtb3VudFwiLCAkJHYpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IFwiZm9ybS5hbW91bnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWNvbFwiLFxuICAgICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcIm10LTNcIiwgYXR0cnM6IHsgbWQ6IFwiMTJcIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidGV4dC1sZWZ0IGZvbnQtd2VpZ2h0LWJvbGQgdGV4dC1pbmZvIG1vbnRzZXJyYXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcIndhbGxldHMuYmFua1wiKSkgKyBcIjpcIildXG4gICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyczogeyB0eXBlOiBcInRleHRcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLmJhbmssXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJiYW5rXCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLmJhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWNvbFwiLFxuICAgICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcIm10LTNcIiwgYXR0cnM6IHsgbWQ6IFwiMTJcIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRpY0NsYXNzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidGV4dC1sZWZ0IGZvbnQtd2VpZ2h0LWJvbGQgdGV4dC1pbmZvIG1vbnRzZXJyYXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcIndhbGxldHMuYWNjb3VudFwiKSkgKyBcIjpcIildXG4gICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICBfYyhcImItZm9ybS1pbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyczogeyB0eXBlOiBcInRleHRcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IF92bS5mb3JtLmFjY291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiBmdW5jdGlvbigkJHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0uZm9ybSwgXCJhY2NvdW50XCIsICQkdilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJmb3JtLmFjY291bnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgICAgXCJiLWNvbFwiLFxuICAgICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcIm10LTNcIiwgYXR0cnM6IHsgbWQ6IFwiMTJcIiB9IH0sXG4gICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAhX3ZtLmlzTG9hZGluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBfYyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHsgXCJtYXJnaW4tYm90dG9tXCI6IFwiNXB4XCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7IHZhcmlhbnQ6IFwic3VjY2Vzc1wiLCBibG9jazogXCJcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb246IHsgY2xpY2s6IF92bS5yZXF1ZXN0V2l0aGRyYXcgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy5yZXF1ZXN0XCIpKSldXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogX2MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJiLWJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6IFwid2FybmluZ1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2s6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9jKFwiYi1zcGlubmVyXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzbWFsbDogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiBcImxpZ2h0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJncm93XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKVxuICAgICAgICBdLFxuICAgICAgICAxXG4gICAgICApLFxuICAgICAgX3ZtLmFjdHVhbFVzZXIudHlwZV9pZCA9PT0gMlxuICAgICAgICA/IF9jKFxuICAgICAgICAgICAgXCJiLWJ1dHRvblwiLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzdGF0aWNTdHlsZTogeyBcIm1hcmdpbi1ib3R0b21cIjogXCI1cHhcIiB9LFxuICAgICAgICAgICAgICBhdHRyczogeyBzaXplOiBcInNtXCIsIHZhcmlhbnQ6IFwib3V0bGluZS1wcmltYXJ5XCIgfSxcbiAgICAgICAgICAgICAgb246IHsgY2xpY2s6IF92bS5nZXRVc2VyV2FsbGV0cyB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy51cGRhdGVfdGFibGVcIikpKV1cbiAgICAgICAgICApXG4gICAgICAgIDogX2MoXG4gICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHN0YXRpY1N0eWxlOiB7IFwibWFyZ2luLWJvdHRvbVwiOiBcIjVweFwiIH0sXG4gICAgICAgICAgICAgIGF0dHJzOiB7IHNpemU6IFwic21cIiwgdmFyaWFudDogXCJvdXRsaW5lLXByaW1hcnlcIiB9LFxuICAgICAgICAgICAgICBvbjogeyBjbGljazogX3ZtLmdldEFsbFdhbGxldHMgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MudXBkYXRlX3RhYmxlXCIpKSldXG4gICAgICAgICAgKSxcbiAgICAgIF92bS5hY3R1YWxVc2VyLnR5cGVfaWQgPT09IDJcbiAgICAgICAgPyBfYyhcbiAgICAgICAgICAgIFwiYi1idXR0b25cIixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwibWwtMlwiLFxuICAgICAgICAgICAgICBzdGF0aWNTdHlsZTogeyBcIm1hcmdpbi1ib3R0b21cIjogXCI1cHhcIiB9LFxuICAgICAgICAgICAgICBhdHRyczogeyBzaXplOiBcInNtXCIsIHZhcmlhbnQ6IFwid2FybmluZ1wiIH0sXG4gICAgICAgICAgICAgIG9uOiB7XG4gICAgICAgICAgICAgICAgY2xpY2s6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgX3ZtLmZvcm0uYW1vdW50ID0gMFxuICAgICAgICAgICAgICAgICAgX3ZtLmZvcm0uYWNjb3VudCA9IFwiXCJcbiAgICAgICAgICAgICAgICAgIF92bS5mb3JtLmJhbmsgPSBcIlwiXG4gICAgICAgICAgICAgICAgICBfdm0uc2V0TW9kYWxWaXNpYmxlKHRydWUpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy5yZXF1ZXN0XCIpKSldXG4gICAgICAgICAgKVxuICAgICAgICA6IF92bS5fZSgpLFxuICAgICAgX2MoXCJiLXRhYmxlXCIsIHtcbiAgICAgICAgc3RhdGljQ2xhc3M6IFwiYnRhYmxlXCIsXG4gICAgICAgIHN0YXRpY1N0eWxlOiB7XG4gICAgICAgICAgXCJtYXgtaGVpZ2h0XCI6IFwiY2FsYygxMDB2aCAtIDE5MXB4KVwiLFxuICAgICAgICAgIFwiZm9udC1zaXplXCI6IFwiLjc1ZW1cIlxuICAgICAgICB9LFxuICAgICAgICBhdHRyczoge1xuICAgICAgICAgIHN0cmlwZWQ6IFwiXCIsXG4gICAgICAgICAgaG92ZXI6IFwiXCIsXG4gICAgICAgICAgcmVzcG9uc2l2ZTogXCJcIixcbiAgICAgICAgICBcInN0aWNreS1oZWFkZXJcIjogXCJcIixcbiAgICAgICAgICBcIm5vLWJvcmRlci1jb2xsYXBzZVwiOiBcIlwiLFxuICAgICAgICAgIGJvcmRlcmVkOiBcIlwiLFxuICAgICAgICAgIG91dGxpbmVkOiBcIlwiLFxuICAgICAgICAgIFwiaGVhZC12YXJpYW50XCI6IFwiZGFya1wiLFxuICAgICAgICAgIGJ1c3k6IF92bS5pc0xvYWRpbmcsXG4gICAgICAgICAgaXRlbXM6IF92bS53YWxsZXRzLFxuICAgICAgICAgIGZpZWxkczogX3ZtLmZpZWxkcyxcbiAgICAgICAgICBcInNlbGVjdC1tb2RlXCI6IFwic2luZ2xlXCIsXG4gICAgICAgICAgc21hbGw6IFwiXCJcbiAgICAgICAgfSxcbiAgICAgICAgc2NvcGVkU2xvdHM6IF92bS5fdShbXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcInRhYmxlLWJ1c3lcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBfYyhcbiAgICAgICAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICAgICAgICB7IHN0YXRpY0NsYXNzOiBcInRleHQtY2VudGVyIHRleHQtZGFuZ2VyXCIgfSxcbiAgICAgICAgICAgICAgICAgIFtfYyhcImItc3Bpbm5lclwiLCB7IHN0YXRpY0NsYXNzOiBcImFsaWduLW1pZGRsZVwiIH0pXSxcbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcm94eTogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQodXNlcl9uYW1lKVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy51c2VyX25hbWVcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoc3RhdHVzKVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy5zdGF0dXNcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoYW1vdW50KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy5hbW91bnRcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoYmFuaylcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbX2MoXCJzcGFuXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcIndhbGxldHMuYmFua1wiKSkpXSldXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBrZXk6IFwiaGVhZChhY2NvdW50KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwid2FsbGV0cy5hY2NvdW50XCIpKSldKV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJoZWFkKHR5cGUpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW19jKFwic3BhblwiLCBbX3ZtLl92KF92bS5fcyhfdm0uJHQoXCJ3YWxsZXRzLnR5cGVcIikpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoY3JlYXRlZF9hdClcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgX2MoXCJzcGFuXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MuY3JlYXRlZF9hdFwiKSkpXSlcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImhlYWQoZGV0YWlscylcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbX2MoXCJzcGFuXCIsIFtfdm0uX3YoX3ZtLl9zKF92bS4kdChcInN0cmluZ3MuZGV0YWlsc1wiKSkpXSldXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBrZXk6IFwiY2VsbCh1c2VyX25hbWUpXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFwic3BhblwiLCBbXG4gICAgICAgICAgICAgICAgICBfdm0uX3YoXG4gICAgICAgICAgICAgICAgICAgIF92bS5fcyhkYXRhLml0ZW0udXNlci5uYW1lKSArXG4gICAgICAgICAgICAgICAgICAgICAgXCIgXCIgK1xuICAgICAgICAgICAgICAgICAgICAgIF92bS5fcyhkYXRhLml0ZW0udXNlci5sYXN0bmFtZSlcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBrZXk6IFwiY2VsbChjcmVhdGVkX2F0KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBfYyhcInNwYW5cIiwgW1xuICAgICAgICAgICAgICAgICAgX3ZtLl92KFxuICAgICAgICAgICAgICAgICAgICBfdm0uX3MoXG4gICAgICAgICAgICAgICAgICAgICAgX3ZtLl9mKFwibW9tZW50XCIpKGRhdGEuaXRlbS5jcmVhdGVkX2F0LCBcIkQsIE1NTU0gWVlZWVwiKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImNlbGwoZGV0YWlscylcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXRpY1N0eWxlOiB7IFwiZm9udC1zaXplXCI6IFwiLjhlbVwiIH0sXG4gICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudDogXCJvdXRsaW5lLXByaW1hcnlcIixcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTpcbiAgICAgICAgICAgICAgICAgICAgICAgIChkYXRhLmRldGFpbHNTaG93aW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gX3ZtLiR0KFwic3RyaW5ncy5oaWRlXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogX3ZtLiR0KFwic3RyaW5ncy5zaG93XCIpKSArXG4gICAgICAgICAgICAgICAgICAgICAgICBcIiBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHQoXCJzdHJpbmdzLmRldGFpbHNcIilcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgb246IHsgY2xpY2s6IGRhdGEudG9nZ2xlRGV0YWlscyB9XG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICBfYyhcInNwYW5cIiwgW1xuICAgICAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5kZXRhaWxzU2hvd2luZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX3ZtLiR0KFwic3RyaW5ncy5oaWRlXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBfdm0uJHQoXCJzdHJpbmdzLnNob3dcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICBcIiBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fcyhfdm0uJHQoXCJzdHJpbmdzLmRldGFpbHNcIikpXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImNlbGwoYW1vdW50KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBkYXRhLml0ZW0udHlwZSA9PT0gXCJERVBPU0lUXCJcbiAgICAgICAgICAgICAgICAgID8gX2MoXCJzdHJvbmdcIiwgeyBzdGF0aWNDbGFzczogXCJ0ZXh0LXN1Y2Nlc3NcIiB9LCBbXG4gICAgICAgICAgICAgICAgICAgICAgX3ZtLl92KFxuICAgICAgICAgICAgICAgICAgICAgICAgXCIrICRcIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgIF92bS5fcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUludChkYXRhLml0ZW0uYW1vdW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvRml4ZWQoMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXGQoPz0oXFxkezN9KStcXC4pL2csIFwiJCYsXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICBcIiAoTVhOKVwiXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICAgICAgOiBfYyhcInN0cm9uZ1wiLCB7IHN0YXRpY0NsYXNzOiBcInRleHQtZGFuZ2VyXCIgfSwgW1xuICAgICAgICAgICAgICAgICAgICAgIF92bS5fdihcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiLSAkXCIgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uX3MoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VJbnQoZGF0YS5pdGVtLmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0ZpeGVkKDIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxkKD89KFxcZHszfSkrXFwuKS9nLCBcIiQmLFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICApICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCIgKE1YTilcIlxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcImNlbGwoYWN0aW9ucylcIixcbiAgICAgICAgICAgIGZuOiBmdW5jdGlvbihkYXRhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgX3ZtLmFjdHVhbFVzZXIudHlwZV9pZCAhPT0gMiAmJiBkYXRhLml0ZW0uc3RhdHVzID09PSBcIlBFTkRJTkdcIlxuICAgICAgICAgICAgICAgICAgPyBfYyhcbiAgICAgICAgICAgICAgICAgICAgICBcImItYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHsgXCJmb250LXNpemVcIjogXCIuOGVtXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBfdm0uJHQoXCJzdHJpbmdzLmVkaXRcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6IFwid2FybmluZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpY2s6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdm0uY2hhbmdlU3RhdHVzKGRhdGEuaXRlbSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgW192bS5fdihfdm0uX3MoX3ZtLiR0KFwic3RyaW5ncy5hcHByb3ZlXCIpKSldXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIDogX3ZtLl9lKClcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAga2V5OiBcInJvdy1kZXRhaWxzXCIsXG4gICAgICAgICAgICBmbjogZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgXCJiLWNvbnRhaW5lclwiLFxuICAgICAgICAgICAgICAgICAgeyBzdGF0aWNDbGFzczogXCJiZy1wcmltYXJ5XCIsIGF0dHJzOiB7IGZsdWlkOiBcIlwiIH0gfSxcbiAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgX2MoXG4gICAgICAgICAgICAgICAgICAgICAgXCJiLXJvd1wiLFxuICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9jKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImItY29sXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYyhcImItdGFibGVcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljQ2xhc3M6IFwibXQtMyBiZy13aGl0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGljU3R5bGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJtYXgtaGVpZ2h0XCI6IFwiY2FsYygxMDB2aCAtIDE5MXB4KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyaXBlZDogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaG92ZXI6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNpdmU6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwic3RpY2t5LWhlYWRlclwiOiBcIlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm5vLWJvcmRlci1jb2xsYXBzZVwiOiBcIlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJlZDogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc21hbGw6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiaGVhZC12YXJpYW50XCI6IFwiZGFya1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZGF0YS5pdGVtLnRyYW5zYWN0aW9uc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGtleTogXCJjZWxsKGluZGV4KVwiLFxuICAgICAgICAgICAgZm46IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFtfYyhcInNwYW5cIiwgW192bS5fdihfdm0uX3MoZGF0YS5pbmRleCArIDEpKV0pXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgXSlcbiAgICAgIH0pXG4gICAgXSxcbiAgICAxXG4gIClcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iXSwic291cmNlUm9vdCI6IiJ9